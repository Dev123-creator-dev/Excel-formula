@echo off
rem Starts Genomic Report Generation from the source code (no exe needed).
rem Requirement: Python 3.10 or newer. The first start installs the Python
rem libraries into %LOCALAPPDATA%\GenomicReportGeneration\venv (needs internet once).
rem A short fixed path avoids Windows path-length limits wherever the zip is unzipped.
setlocal
set "VENV=%LOCALAPPDATA%\GenomicReportGeneration\venv"
cd /d "%~dp0"
title Genomic Report Generation

if exist "%VENV%\Scripts\pythonw.exe" if exist "%VENV%\installed.ok" goto :start

echo.
echo  Genomic Report Generation - first-time setup
echo  ============================================
echo.

set "PY="
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1 && set "PY=py -3"
if not defined PY (
    python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo  Python 3.10 or newer was not found on this computer.
    echo.
    echo  Install it from https://www.python.org/downloads/windows/
    echo    - choose "Install for me only" ^(no admin rights needed^)
    echo    - tick "Add python.exe to PATH"
    echo  Then double-click this file again.
    goto :fail
)

echo  [1/2] Creating the Python environment...
if exist "%VENV%" rmdir /s /q "%VENV%"
%PY% -m venv "%VENV%" || goto :fail

echo  [2/2] Installing libraries ^(one time, about 1-2 minutes^)...
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check -q --retries 5 -r backend\requirements.txt
if errorlevel 1 (
    echo.
    echo  Installing the libraries failed ^(see the message above^).
    echo  Usually: no internet, or a company proxy blocks pypi.org.
    goto :fail
)
echo ok> "%VENV%\installed.ok"
echo.
echo  Setup complete.

:start
if not exist "backend\app\static\index.html" (
    echo  The user interface files are missing: backend\app\static
    goto :fail
)
start "" "%VENV%\Scripts\pythonw.exe" backend\launcher.py
exit /b 0

:fail
echo.
pause
exit /b 1

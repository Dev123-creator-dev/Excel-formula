"""Local-server hardening.

The API only listens on 127.0.0.1, but any web page open in the user's browser
can still *send* requests to localhost. To stop a malicious site from driving
the app (e.g. asking it to open or run files), every /api call must carry a
per-launch secret that only the app window receives:

* a random session token is generated at start-up and saved to a per-user file;
* the launcher opens the UI with the token in the URL fragment (never sent over
  the network, never logged); the UI keeps it in sessionStorage and sends it as
  the X-GRG-Token header - a custom header that cross-site pages cannot add
  without a CORS pre-flight, which this server never grants;
* Host headers other than 127.0.0.1/localhost are rejected (DNS rebinding), and
  so are requests whose Origin is not this server;
* strict security headers (CSP, no framing, no sniffing, no referrer) on every
  response.
"""
from __future__ import annotations

import hmac
import os
import secrets
from pathlib import Path

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from .config import app_data_dir

TOKEN_FILE = app_data_dir() / "session.token"
PUBLIC_API = {"/api/ping"}
ALLOWED_HOSTS = {"127.0.0.1", "localhost"}

CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data:; font-src 'self' data:; connect-src 'self'; "
    "object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
)
SECURITY_HEADERS = {
    "Content-Security-Policy": CSP,
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Cache-Control": "no-store",
}


def _new_token() -> str:
    token = os.environ.get("GRG_TOKEN") or secrets.token_urlsafe(32)
    TOKEN_FILE.write_text(token, encoding="utf-8")
    return token


SESSION_TOKEN = _new_token()


def read_token_file() -> str:
    try:
        return Path(TOKEN_FILE).read_text(encoding="utf-8").strip()
    except OSError:
        return ""


class SecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if host not in ALLOWED_HOSTS:
            return JSONResponse({"detail": "Invalid host"}, status_code=400)

        origin = request.headers.get("origin")
        if origin and origin.rstrip("/") not in {f"{request.url.scheme}://{request.headers.get('host')}"}:
            return JSONResponse({"detail": "Cross-origin requests are not allowed"}, status_code=403)

        path = request.url.path
        if path.startswith("/api/") and path not in PUBLIC_API:
            supplied = request.headers.get("x-grg-token", "")
            if not hmac.compare_digest(supplied.encode(), SESSION_TOKEN.encode()):
                return JSONResponse({"detail": "Session expired - please relaunch the application."},
                                    status_code=401)

        response = await call_next(request)
        for key, value in SECURITY_HEADERS.items():
            response.headers.setdefault(key, value)
        return response

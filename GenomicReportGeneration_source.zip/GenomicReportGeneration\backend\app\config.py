"""Application settings persisted as JSON under %LOCALAPPDATA%."""
from __future__ import annotations

import glob
import json
import os
import shutil
import sys
import threading
from pathlib import Path

from pydantic import BaseModel, Field, field_validator


def app_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    path = Path(base) / "GenomicReportGeneration"
    path.mkdir(parents=True, exist_ok=True)
    return path


def resource_dir() -> Path:
    """Directory holding bundled resources (works both frozen and from source)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def detect_rscript() -> str:
    """Find Rscript.exe: PATH, the R-core registry key, then Program Files."""
    found = shutil.which("Rscript")
    if found:
        return found
    try:
        import winreg

        for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(hive, r"SOFTWARE\R-core\R") as key:
                    install = Path(winreg.QueryValueEx(key, "InstallPath")[0])
                for candidate in (install / "bin" / "x64" / "Rscript.exe", install / "bin" / "Rscript.exe"):
                    if candidate.exists():
                        return str(candidate)
            except OSError:
                continue
    except ImportError:
        pass
    candidates = sorted(
        glob.glob(r"C:\Program Files\R\R-*\bin\x64\Rscript.exe")
        + glob.glob(r"C:\Program Files\R\R-*\bin\Rscript.exe")
        + glob.glob(os.path.expandvars(r"%LOCALAPPDATA%\Programs\R\R-*\bin\x64\Rscript.exe")),
        reverse=True,
    )
    return candidates[0] if candidates else ""


class Settings(BaseModel):
    root_path: str = "D:\\"
    # Last files used - pre-filled into new projects so they are selected only once.
    r_script_path: str = ""
    r_helper_path: str = ""
    rscript_exe: str = Field(default_factory=detect_rscript)
    r_auto_install_packages: bool = True
    r_timeout_minutes: int = 60
    oncopredictor_url: str = "https://automationtools-panlabsus.eurofinsdiscovery.net/"
    move_files: bool = True
    gprofiler_url: str = "https://biit.cs.ut.ee/gprofiler/gost"
    gprofiler_engine: str = "selenium"  # selenium | api
    gprofiler_headless: bool = False
    gprofiler_fallback_to_api: bool = True
    gprofiler_timeout_seconds: int = 180
    default_excel_template: str = ""
    default_word_template: str = ""
    port: int = 8765

    @field_validator("oncopredictor_url", "gprofiler_url")
    @classmethod
    def https_only(cls, v: str) -> str:
        if not v.lower().startswith("https://"):
            raise ValueError("Only https:// URLs are allowed")
        return v

    @field_validator("gprofiler_engine")
    @classmethod
    def engine(cls, v: str) -> str:
        if v not in ("selenium", "api"):
            raise ValueError("Engine must be 'selenium' or 'api'")
        return v

    @field_validator("r_timeout_minutes", "gprofiler_timeout_seconds")
    @classmethod
    def positive(cls, v: int) -> int:
        if not 1 <= int(v) <= 100000:
            raise ValueError("Must be a positive number")
        return int(v)


class SettingsStore:
    def __init__(self) -> None:
        self._path = app_data_dir() / "settings.json"
        self._lock = threading.Lock()
        self._settings = self._load()

    def _load(self) -> Settings:
        if self._path.exists():
            try:
                settings = Settings(**json.loads(self._path.read_text(encoding="utf-8")))
                if not settings.rscript_exe or not Path(settings.rscript_exe).exists():
                    settings.rscript_exe = detect_rscript()
                return settings
            except Exception:
                pass
        settings = Settings()
        self._write(settings)
        return settings

    def _write(self, settings: Settings) -> None:
        self._path.write_text(settings.model_dump_json(indent=2), encoding="utf-8")

    def get(self) -> Settings:
        with self._lock:
            return self._settings.model_copy(deep=True)

    def update(self, values: dict) -> Settings:
        with self._lock:
            merged = {**self._settings.model_dump(), **values}
            self._settings = Settings(**merged)
            self._write(self._settings)
            return self._settings.model_copy(deep=True)


settings_store = SettingsStore()

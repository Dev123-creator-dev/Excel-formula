import { Box, Button, Chip, Stack, Typography, alpha } from "@mui/material";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import StopRoundedIcon from "@mui/icons-material/StopRounded";
import FolderRoundedIcon from "@mui/icons-material/FolderRounded";
import ScienceRoundedIcon from "@mui/icons-material/ScienceRounded";
import EventRoundedIcon from "@mui/icons-material/EventRounded";
import PersonRoundedIcon from "@mui/icons-material/PersonRounded";
import { GlassCard, ProgressRing, ShimmerBar } from "./ui.jsx";
import { brand } from "../theme.js";
import { api, fmtTime } from "../api.js";
import { useAction } from "../context.jsx";

function Meta({ icon: Icon, label, value }) {
  return (
    <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
      <Icon sx={{ fontSize: 17, color: "text.secondary" }} />
      <Typography variant="body2" color="text.secondary" sx={{ whiteSpace: "nowrap" }}>{label}</Typography>
      <Typography variant="body2" sx={{ fontWeight: 650, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {value}
      </Typography>
    </Stack>
  );
}

export default function Hero({ project, onChanged }) {
  const act = useAction();
  const m = project.metrics;
  const allDone = m.completed_steps === m.total_steps;
  const run = async () => { await act(() => api.runAll(project.id), "Workflow started"); onChanged(); };
  const stop = async () => { await act(() => api.cancel(project.id), "Cancelling…"); onChanged(); };

  return (
    <GlassCard glow sx={{ p: { xs: 2.5, md: 3.5 } }} className="grg-rise">
      <Box sx={{
        position: "absolute", right: -80, top: -120, width: 360, height: 360, borderRadius: "50%",
        background: `radial-gradient(circle, ${alpha(brand.violet, 0.28)}, transparent 65%)`, pointerEvents: "none",
      }} />
      <Stack direction={{ xs: "column", md: "row" }} spacing={4} alignItems={{ md: "center" }} sx={{ position: "relative" }}>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 1.5 }} flexWrap="wrap" useFlexGap>
            <Chip size="small" label={`Project #${project.id}`}
              sx={{ background: brand.gradientSoft, color: "text.primary", border: `1px solid ${alpha(brand.teal, 0.3)}` }} />
            {project.running ? (
              <Chip size="small" label="Processing" color="info" variant="outlined" />
            ) : allDone ? (
              <Chip size="small" label="Deliverables ready" color="success" variant="outlined" />
            ) : null}
          </Stack>
          <Typography variant="h4" sx={{ mb: 0.5, overflow: "hidden", textOverflow: "ellipsis" }}>
            {project.study_name}
          </Typography>
          <Typography color="text.secondary" sx={{ mb: 2.5 }}>
            {allDone ? "All workflow steps are complete." : <>Current step · <b>{m.current_step}</b></>}
          </Typography>

          <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" }, gap: 1.25, mb: 3 }}>
            <Meta icon={FolderRoundedIcon} label="Folder" value={project.project_path} />
            <Meta icon={EventRoundedIcon} label="Created" value={fmtTime(project.created_at)} />
            {project.inputs?.report_compound && <Meta icon={ScienceRoundedIcon} label="Compound" value={project.inputs.report_compound} />}
            <Meta icon={PersonRoundedIcon} label="User" value={project.user_email} />
          </Box>

          <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2.5 }}>
            <Box sx={{ flex: 1 }}><ShimmerBar value={m.progress} active={project.running} /></Box>
            <Typography variant="body2" sx={{ fontWeight: 700, minWidth: 42, textAlign: "right" }}>{Math.round(m.progress)}%</Typography>
          </Stack>

          <Stack direction="row" spacing={1.25} flexWrap="wrap" useFlexGap>
            {project.running ? (
              <Button variant="outlined" color="error" startIcon={<StopRoundedIcon />} onClick={stop}>Stop</Button>
            ) : (
              <Button variant="contained" startIcon={<PlayArrowRoundedIcon />} onClick={run} disabled={allDone} size="large">
                {m.completed_steps === 0 ? "Start workflow" : allDone ? "Workflow complete" : "Resume workflow"}
              </Button>
            )}
            <Button variant="outlined" color="inherit" startIcon={<FolderRoundedIcon />}
              onClick={() => act(() => api.open(project.project_path))}>
              Open project folder
            </Button>
          </Stack>
        </Box>
        <Stack alignItems="center" spacing={1}>
          <ProgressRing value={m.progress} size={168} stroke={13} sublabel={`${m.completed_steps} of ${m.total_steps} steps`} />
        </Stack>
      </Stack>
    </GlassCard>
  );
}

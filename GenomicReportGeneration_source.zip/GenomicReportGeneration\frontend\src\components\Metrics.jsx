import { Box, Stack, Typography, alpha } from "@mui/material";
import AutoModeRoundedIcon from "@mui/icons-material/AutoModeRounded";
import TimerRoundedIcon from "@mui/icons-material/TimerRounded";
import InsertDriveFileRoundedIcon from "@mui/icons-material/InsertDriveFileRounded";
import ErrorOutlineRoundedIcon from "@mui/icons-material/ErrorOutlineRounded";
import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";
import { GlassCard } from "./ui.jsx";
import { brand } from "../theme.js";
import { fmtDuration } from "../api.js";

function Metric({ icon: Icon, label, value, color, caption, delay }) {
  return (
    <GlassCard sx={{ p: 2.25, animationDelay: `${delay}ms` }} className="grg-rise">
      <Stack direction="row" spacing={1.75} alignItems="center">
        <Box sx={{
          width: 44, height: 44, borderRadius: 3, display: "grid", placeItems: "center", flexShrink: 0,
          color, background: alpha(color, 0.13), boxShadow: `inset 0 0 0 1px ${alpha(color, 0.25)}`,
        }}>
          <Icon sx={{ fontSize: 22 }} />
        </Box>
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="overline" color="text.secondary" sx={{ lineHeight: 1.6, display: "block" }}>{label}</Typography>
          <Typography sx={{ fontWeight: 750, fontSize: 19, lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
            title={typeof value === "string" ? value : undefined}>
            {value}
          </Typography>
          {caption && <Typography variant="caption" color="text.secondary">{caption}</Typography>}
        </Box>
      </Stack>
    </GlassCard>
  );
}

export default function Metrics({ project }) {
  const m = project.metrics;
  return (
    <Box sx={{ display: "grid", gap: 2, gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", xl: "1.6fr 1fr 1fr 1fr 1fr" } }}>
      <Metric icon={AutoModeRoundedIcon} label="Current step" value={m.current_step} color={brand.blue} delay={0} />
      <Metric icon={TimerRoundedIcon} label="Execution time" value={fmtDuration(m.execution_time_s)} color={brand.teal} delay={60} />
      <Metric icon={InsertDriveFileRoundedIcon} label="Output files" value={m.output_files} color={brand.violet} delay={120} />
      <Metric icon={ErrorOutlineRoundedIcon} label="Errors" value={m.errors} color={m.errors ? brand.pink : "#64748B"} delay={180} />
      <Metric icon={WarningAmberRoundedIcon} label="Warnings" value={m.warnings} color={m.warnings ? brand.amber : "#64748B"} delay={240} />
    </Box>
  );
}

"""Step 7 - bundle every deliverable plus a manifest into a single zip."""
from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime
from pathlib import Path

from .. import APP_VERSION
from .common import StepContext

DELIVERABLE_KINDS = {
    "diffex_workbook": "DiffEx Processed Workbook",
    "gprofiler_sensitivity": "g:Profiler Sensitivity CSV",
    "gprofiler_resistance": "g:Profiler Resistance CSV",
    "clustering_output": "Clustering Output",
    "ranked_soc": "Ranked SOC Compound List",
    "word_report": "Final Word Report",
    "gene_list": "Gene List",
    "gprofiler_screenshot": "g:Profiler Screenshot",
    "log": "Execution Log",
}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(ctx: StepContext, files: list[dict]) -> dict:
    root = ctx.path
    items = [f for f in files if f["kind"] in DELIVERABLE_KINDS and Path(f["path"]).exists()]
    for log in (root / "Logs").glob("*.*"):
        if not any(Path(i["path"]) == log for i in items):
            items.append({"kind": "log", "path": str(log)})

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = root / "Reports" / f"{ctx.file_prefix}_Deliverables_{stamp}.zip"
    manifest = {
        "application": f"Genomic Report Generation {APP_VERSION}",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "project": {k: ctx.project[k] for k in ("study_name", "compound_name", "client_name",
                                                 "project_code", "user_email", "project_path")},
        "files": [],
    }
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for i, item in enumerate(items, start=1):
            ctx.check_cancel()
            path = Path(item["path"])
            try:
                arcname = path.relative_to(root).as_posix()
            except ValueError:
                arcname = path.name
            zf.write(path, arcname)
            manifest["files"].append({
                "type": DELIVERABLE_KINDS[item["kind"]], "path": arcname,
                "bytes": path.stat().st_size, "sha256": _sha256(path),
            })
            ctx.progress(10 + 80 * i / max(len(items), 1), f"Packaging {path.name}")
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))

    ctx.register_file("package", str(zip_path))
    ctx.success("Final deliverables packaged", f"{len(items)} files -> {zip_path}")
    return {"package": str(zip_path), "file_count": len(items), "summary": f"{len(items)} files packaged"}

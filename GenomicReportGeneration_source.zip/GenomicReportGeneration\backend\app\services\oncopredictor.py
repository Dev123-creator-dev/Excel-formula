"""Step 1 - import the DiffEx / Mutation reports the user selected from OncoPredictor."""
from __future__ import annotations

import re
import shutil
from pathlib import Path

import openpyxl

from .common import NeedsInput, StepContext, StepError, validate_file

DIFFEX_HEADERS = ["Genomic Feature", "Probe", "Fold Change", "P-Value", "Q-Value"]
EXCEL = (".xlsx", ".xlsm")


def validate_diffex(path: Path) -> dict:
    try:
        wb = openpyxl.load_workbook(path, read_only=True)
    except Exception as exc:
        raise StepError(f"Cannot open the DiffEx report: {path.name}", str(exc)) from exc
    try:
        ws = wb.worksheets[0]
        header = list(next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ()))
        if [str(h or "").strip() for h in header[:5]] != DIFFEX_HEADERS:
            raise StepError(
                f"{path.name} does not look like a DiffEx report.",
                f"Expected first columns {DIFFEX_HEADERS}, found {header[:5]}. "
                "Did you swap the DiffEx and Mutation files?",
            )
        return {"rows": (ws.max_row or 1) - 1}
    finally:
        wb.close()


def validate_mutation(path: Path) -> dict:
    try:
        wb = openpyxl.load_workbook(path, read_only=True)
    except Exception as exc:
        raise StepError(f"Cannot open the Mutation report: {path.name}", str(exc)) from exc
    try:
        if "OncoPanel Results" not in wb.sheetnames:
            raise StepError(
                f"{path.name} does not look like a Mutation report (no 'OncoPanel Results' sheet).",
                "Did you swap the DiffEx and Mutation files?",
            )
        ws = wb["OncoPanel Results"]
        measure = str(ws["D1"].value or "")
        # e.g. "Cell Count, IC50" -> "IC50"
        return {"cell_lines": (ws.max_row or 1) - 1,
                "analysis_parameter": measure.split(",")[-1].strip() if measure else ""}
    finally:
        wb.close()


def guess_compound(filename: str) -> str:
    """'Eurofins Discovery_Internal_SOC_ Vemurafenib_13FEB23-Diffex-PROD.xlsx' -> 'Vemurafenib'."""
    tokens = [t.strip() for t in re.split(r"[_\-]", Path(filename).stem) if t.strip()]
    for i, tok in enumerate(tokens):
        if re.fullmatch(r"\d{1,2}[A-Za-z]{3}\d{2,4}", tok) and i > 0:
            return tokens[i - 1]
    return ""


def _import(ctx: StepContext, source: Path, kind: str) -> Path:
    dest = ctx.path / "OncoPredictor" / source.name
    if source.resolve() == dest.resolve():
        return dest
    if dest.exists():
        dest.unlink()
    if ctx.settings.move_files:
        try:
            shutil.move(str(source), dest)
            ctx.info(f"{kind} report moved", f"{source} -> {dest}")
        except PermissionError:
            # Read-only sources (e.g. AppStream drives) can only be copied.
            shutil.copy2(source, dest)
            ctx.warn(f"{kind} report copied (source is read-only)", f"{source} -> {dest}")
    else:
        shutil.copy2(source, dest)
        ctx.info(f"{kind} report copied", f"{source} -> {dest}")
    ctx.register_file(f"oncopredictor_{kind.lower()}", str(dest))
    return dest


def run(ctx: StepContext) -> dict:
    diffex_in = ctx.inputs.get("diffex_path")
    mutation_in = ctx.inputs.get("mutation_path")
    if not diffex_in or not mutation_in:
        missing = " and ".join(n for n, v in (("DiffEx report", diffex_in), ("Mutation report", mutation_in)) if not v)
        raise NeedsInput(f"Select the {missing} downloaded from OncoPredictor.",
                         "diffex_path" if not diffex_in else "mutation_path")

    diffex = validate_file(diffex_in, "DiffEx report", EXCEL)
    mutation = validate_file(mutation_in, "Mutation report", EXCEL)
    if diffex.resolve() == mutation.resolve():
        raise StepError("The same file was selected for both DiffEx and Mutation reports.")
    ctx.progress(20, "Validating DiffEx report")
    diffex_meta = validate_diffex(diffex)
    ctx.success("DiffEx file found", f"{diffex.name} ({diffex_meta['rows']:,} probes)")
    ctx.progress(45, "Validating Mutation report")
    mutation_meta = validate_mutation(mutation)
    ctx.success("Mutation report found", f"{mutation.name} ({mutation_meta['cell_lines']} cell lines)")

    ctx.progress(75, "Importing files")
    diffex_dest = _import(ctx, diffex, "DiffEx")
    mutation_dest = _import(ctx, mutation, "Mutation")
    ctx.success("Files imported", str(diffex_dest.parent))

    return {
        "diffex_file": str(diffex_dest),
        "mutation_file": str(mutation_dest),
        "diffex_rows": diffex_meta["rows"],
        "cell_lines": mutation_meta["cell_lines"],
        "analysis_parameter": mutation_meta["analysis_parameter"],
        "compound_guess": guess_compound(diffex.name),
        "checks": {"diffex_found": True, "mutation_found": True, "imported": True},
        "summary": f"{diffex_meta['rows']:,} DiffEx probes, {mutation_meta['cell_lines']} cell lines imported",
    }

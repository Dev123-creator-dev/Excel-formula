import { Box, Button, IconButton, Stack, Tooltip, Typography, alpha } from "@mui/material";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import FolderCopyRoundedIcon from "@mui/icons-material/FolderCopyRounded";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import { EmptyState, GlassCard, ShimmerBar } from "../components/ui.jsx";
import { brand } from "../theme.js";
import { api, fmtTime } from "../api.js";
import { useAction } from "../context.jsx";

export default function ProjectsPage({ projects, onOpen, onNew, onChanged }) {
  const act = useAction();
  const remove = async (p) => {
    if (!window.confirm(`Remove "${p.study_name}" from the dashboard?\nFiles on disk are kept.`)) return;
    await act(() => api.deleteProject(p.id), "Project removed");
    onChanged();
  };
  if (!projects.length) {
    return (
      <GlassCard>
        <EmptyState icon={FolderCopyRoundedIcon} title="No projects yet"
          body="Create a project to generate the folder structure and start the automated reporting workflow."
          action={<Button variant="contained" startIcon={<AddRoundedIcon />} onClick={onNew}>New project</Button>} />
      </GlassCard>
    );
  }
  return (
    <Box sx={{ display: "grid", gap: 2.5, gridTemplateColumns: { xs: "1fr", md: "1fr 1fr", xl: "1fr 1fr 1fr" } }}>
      {projects.map((p, i) => {
        const pct = (p.completed_steps / p.total_steps) * 100;
        const status = p.running ? ["Running", brand.blue] : p.failed ? ["Attention", brand.pink]
          : pct === 100 ? ["Complete", brand.green] : ["In progress", brand.amber];
        return (
          <GlassCard key={p.id} className="grg-rise" sx={{
            cursor: "pointer", animationDelay: `${i * 50}ms`, transition: "transform .2s, box-shadow .2s",
            "&:hover": { transform: "translateY(-3px)", boxShadow: `0 24px 48px -24px ${alpha(brand.violet, 0.6)}` },
          }} onClick={() => onOpen(p.id)}>
            <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1.5 }}>
              <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: status[1], boxShadow: `0 0 0 4px ${alpha(status[1], 0.18)}` }} />
              <Typography variant="caption" sx={{ fontWeight: 700, color: status[1] }}>{status[0]}</Typography>
              <Box sx={{ flex: 1 }} />
              <Typography variant="caption" color="text.secondary">#{p.id}</Typography>
              <Tooltip title="Remove from dashboard">
                <IconButton size="small" onClick={(e) => { e.stopPropagation(); remove(p); }}>
                  <DeleteOutlineRoundedIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Stack>
            <Typography variant="h6" sx={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.study_name}</Typography>
            <Typography variant="body2" color="text.secondary" title={p.project_path}
              sx={{ mb: 2, fontFamily: '"Cascadia Code", Consolas, monospace', fontSize: 12.5,
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {p.project_path}
            </Typography>
            <ShimmerBar value={pct} active={p.running} />
            <Stack direction="row" alignItems="center" sx={{ mt: 1.5 }}>
              <Typography variant="caption" color="text.secondary" sx={{ flex: 1 }}>
                {p.completed_steps}/{p.total_steps} steps · updated {fmtTime(p.updated_at)}
              </Typography>
              <ArrowForwardRoundedIcon sx={{ fontSize: 18, color: brand.teal }} />
            </Stack>
          </GlassCard>
        );
      })}
    </Box>
  );
}

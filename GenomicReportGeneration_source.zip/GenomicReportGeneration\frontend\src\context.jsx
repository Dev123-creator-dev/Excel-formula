import { createContext, useCallback, useContext, useState } from "react";
import { Alert, Snackbar } from "@mui/material";

const ToastCtx = createContext(() => {});

export function ToastProvider({ children }) {
  const [toast, setToast] = useState(null);
  const notify = useCallback((message, severity = "success") => setToast({ message, severity, key: Date.now() }), []);
  return (
    <ToastCtx.Provider value={notify}>
      {children}
      <Snackbar
        key={toast?.key}
        open={!!toast}
        autoHideDuration={4500}
        onClose={() => setToast(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        {toast ? (
          <Alert variant="filled" severity={toast.severity} onClose={() => setToast(null)}
            sx={{ borderRadius: 3, fontWeight: 600, boxShadow: 8, maxWidth: 520 }}>
            {toast.message}
          </Alert>
        ) : undefined}
      </Snackbar>
    </ToastCtx.Provider>
  );
}

export const useToast = () => useContext(ToastCtx);

/** Wraps an async action with error toasts. */
export function useAction() {
  const notify = useToast();
  return useCallback(
    async (fn, success) => {
      try {
        const r = await fn();
        if (success) notify(success, "success");
        return r;
      } catch (e) {
        notify(e.hint ? `${e.message} — ${e.hint}` : e.message, "error");
        return undefined;
      }
    },
    [notify]
  );
}

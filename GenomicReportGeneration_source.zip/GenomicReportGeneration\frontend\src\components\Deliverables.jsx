import { Box, IconButton, Stack, Tooltip, Typography, alpha } from "@mui/material";
import Inventory2RoundedIcon from "@mui/icons-material/Inventory2Rounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import GridOnRoundedIcon from "@mui/icons-material/GridOnRounded";
import TableChartRoundedIcon from "@mui/icons-material/TableChartRounded";
import HubRoundedIcon from "@mui/icons-material/HubRounded";
import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";
import FolderZipRoundedIcon from "@mui/icons-material/FolderZipRounded";
import ImageRoundedIcon from "@mui/icons-material/ImageRounded";
import LaunchRoundedIcon from "@mui/icons-material/LaunchRounded";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";
import { GlassCard, SectionTitle } from "./ui.jsx";
import { brand } from "../theme.js";
import { api, basename, fmtBytes } from "../api.js";
import { useAction } from "../context.jsx";

const KINDS = {
  word_report: { label: "Final Word Report", icon: DescriptionRoundedIcon, color: brand.blue, order: 1 },
  package: { label: "Deliverables Package", icon: FolderZipRoundedIcon, color: brand.violet, order: 2 },
  diffex_workbook: { label: "DiffEx Processed Workbook", icon: GridOnRoundedIcon, color: brand.green, order: 3 },
  gprofiler_sensitivity: { label: "g:Profiler Sensitivity CSV", icon: TableChartRoundedIcon, color: brand.teal, order: 4 },
  gprofiler_resistance: { label: "g:Profiler Resistance CSV", icon: TableChartRoundedIcon, color: brand.pink, order: 5 },
  ranked_soc: { label: "Ranked SOC Compound List", icon: HubRoundedIcon, color: brand.amber, order: 6 },
  clustering_output: { label: "Clustering Output", icon: HubRoundedIcon, color: brand.amber, order: 7 },
  gene_list: { label: "Gene List", icon: ArticleRoundedIcon, color: "#94A3B8", order: 8 },
  gprofiler_screenshot: { label: "g:Profiler Snapshot", icon: ImageRoundedIcon, color: "#94A3B8", order: 9 },
  log: { label: "Execution Log", icon: ArticleRoundedIcon, color: "#94A3B8", order: 10 },
};

export default function Deliverables({ files }) {
  const act = useAction();
  const items = files
    .filter((f) => KINDS[f.kind])
    .sort((a, b) => KINDS[a.kind].order - KINDS[b.kind].order);
  return (
    <GlassCard>
      <SectionTitle icon={Inventory2RoundedIcon} title="Deliverables" subtitle={`${items.length} generated file${items.length === 1 ? "" : "s"}`} />
      {items.length === 0 && (
        <Typography variant="body2" color="text.secondary" sx={{ py: 3, textAlign: "center" }}>
          Outputs appear here as each step completes.
        </Typography>
      )}
      <Stack spacing={1}>
        {items.map((f) => {
          const k = KINDS[f.kind];
          const Icon = k.icon;
          return (
            <Stack key={f.id} direction="row" alignItems="center" spacing={1.5} className="grg-rise" sx={{
              p: 1.25, borderRadius: 3, border: "1px solid", borderColor: "divider", opacity: f.exists ? 1 : 0.5,
              transition: "all .2s", "&:hover": { borderColor: alpha(k.color, 0.5), bgcolor: alpha(k.color, 0.05) },
            }}>
              <Box sx={{ width: 36, height: 36, borderRadius: 2.5, display: "grid", placeItems: "center",
                bgcolor: alpha(k.color, 0.13), color: k.color, flexShrink: 0 }}>
                <Icon sx={{ fontSize: 19 }} />
              </Box>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="body2" sx={{ fontWeight: 650 }}>{k.label}</Typography>
                <Typography variant="caption" color="text.secondary" component="div" title={f.path}
                  sx={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {basename(f.path)} {f.size_bytes ? `· ${fmtBytes(f.size_bytes)}` : ""}
                </Typography>
              </Box>
              <Tooltip title="Open">
                <span><IconButton size="small" disabled={!f.exists} onClick={() => act(() => api.open(f.path))}>
                  <LaunchRoundedIcon fontSize="small" />
                </IconButton></span>
              </Tooltip>
              <Tooltip title="Show in folder">
                <span><IconButton size="small" disabled={!f.exists} onClick={() => act(() => api.reveal(f.path))}>
                  <FolderOpenRoundedIcon fontSize="small" />
                </IconButton></span>
              </Tooltip>
            </Stack>
          );
        })}
      </Stack>
    </GlassCard>
  );
}

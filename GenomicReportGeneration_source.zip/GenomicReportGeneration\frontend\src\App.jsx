import { useCallback, useEffect, useMemo, useState } from "react";
import { Box, Button, CssBaseline, MenuItem, Select, Stack, ThemeProvider, Typography } from "@mui/material";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import BiotechRoundedIcon from "@mui/icons-material/BiotechRounded";
import LockClockRoundedIcon from "@mui/icons-material/LockClockRounded";
import MenuBookRoundedIcon from "@mui/icons-material/MenuBookRounded";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";
import GuidePage from "./pages/GuidePage.jsx";
import { buildTheme, brand } from "./theme.js";
import { api, hasToken } from "./api.js";
import { ToastProvider } from "./context.jsx";
import Background from "./components/Background.jsx";
import Sidebar from "./components/Sidebar.jsx";
import Hero from "./components/Hero.jsx";
import Metrics from "./components/Metrics.jsx";
import Workflow from "./components/Workflow.jsx";
import ActivityFeed from "./components/ActivityFeed.jsx";
import Deliverables from "./components/Deliverables.jsx";
import NewProjectDialog from "./components/NewProjectDialog.jsx";
import { EmptyState, GlassCard } from "./components/ui.jsx";
import ProjectsPage from "./pages/ProjectsPage.jsx";
import LogsPage from "./pages/LogsPage.jsx";
import SettingsPage from "./pages/SettingsPage.jsx";

const TITLES = {
  dashboard: ["Dashboard", "Automated OncoPanel genomics reporting"],
  projects: ["Projects", "All studies processed on this workstation"],
  logs: ["Activity Log", "Complete audit trail"],
  guide: ["User Guide", "Step-by-step instructions"],
  settings: ["Settings", "Paths, automation engines and system health"],
};

function SessionExpired() {
  return (
    <Box sx={{ minHeight: "100vh", display: "grid", placeItems: "center", p: 3, position: "relative", zIndex: 1 }}>
      <GlassCard glow sx={{ maxWidth: 520 }}>
        <EmptyState icon={LockClockRoundedIcon} title="Session expired"
          body="For your security this window is no longer connected. Close it and start GenomicReportGeneration.exe again." />
      </GlassCard>
    </Box>
  );
}

const store = {
  get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
};

function Dashboard({ project, logs, settings, onChanged, onNew, onGuide, onPrevious, hasProjects }) {
  if (!project) {
    return (
      <GlassCard glow>
        <EmptyState icon={BiotechRoundedIcon} title="Welcome to Genomic Report Generation"
          body="Choose a folder and the project is set up for you. Then select the OncoPredictor files and the R script — the platform builds the DiffEx tables, runs g:Profiler and assembles the final report."
          action={
            <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5}>
              <Button variant="contained" size="large" startIcon={<AddRoundedIcon />} onClick={onNew}>Start a new project</Button>
              {hasProjects && (
                <Button variant="outlined" color="inherit" size="large" startIcon={<FolderOpenRoundedIcon />} onClick={onPrevious}>Open a previous project</Button>
              )}
              <Button variant="outlined" color="inherit" size="large" startIcon={<MenuBookRoundedIcon />} onClick={onGuide}>How it works</Button>
            </Stack>
          } />
      </GlassCard>
    );
  }
  return (
    <Stack spacing={2.5}>
      <Hero project={project} onChanged={onChanged} />
      <Metrics project={project} />
      <Box sx={{ display: "grid", gap: 2.5, gridTemplateColumns: { xs: "1fr", lg: "minmax(0,1.65fr) minmax(0,1fr)" }, alignItems: "start" }}>
        <Workflow project={project} settings={settings} onChanged={onChanged} />
        <Stack spacing={2.5} sx={{ position: { lg: "sticky" }, top: 96 }}>
          <ActivityFeed logs={logs} running={project.running} />
          <Deliverables files={project.files} />
        </Stack>
      </Box>
    </Stack>
  );
}

export default function App() {
  const [mode, setMode] = useState(() => store.get("grg-theme", "dark"));
  const theme = useMemo(() => buildTheme(mode), [mode]);
  const [page, setPage] = useState("dashboard");
  const [projects, setProjects] = useState([]);
  // Every launch starts fresh; earlier projects stay available on the Projects page.
  const [projectId, setProjectId] = useState(null);
  const [project, setProject] = useState(null);
  const [logs, setLogs] = useState([]);
  const [settings, setSettings] = useState(null);
  const [health, setHealth] = useState(null);
  const [newOpen, setNewOpen] = useState(false);
  const [expired, setExpired] = useState(!hasToken());
  useEffect(() => {
    const onUnauthorized = () => setExpired(true);
    window.addEventListener("grg-unauthorized", onUnauthorized);
    return () => window.removeEventListener("grg-unauthorized", onUnauthorized);
  }, []);

  const toggleMode = () => { const m = mode === "dark" ? "light" : "dark"; setMode(m); store.set("grg-theme", m); };

  const loadProjects = useCallback(async () => {
    const list = await api.projects().catch(() => []);
    setProjects(list);
    setProjectId((cur) => (cur && list.some((p) => p.id === cur) ? cur : null));
  }, []);

  const loadProject = useCallback(async () => {
    if (!projectId) { setProject(null); setLogs([]); return; }
    try {
      const [p, l] = await Promise.all([api.project(projectId), api.logs(projectId)]);
      setProject(p); setLogs(l);
    } catch { setProject(null); }
  }, [projectId]);

  const loadMeta = useCallback(() => {
    api.settings().then(setSettings).catch(() => {});
    api.health().then(setHealth).catch(() => {});
  }, []);

  useEffect(() => { loadProjects(); loadMeta(); }, [loadProjects, loadMeta]);

  // Heartbeat: the server shuts down when no window has called it for a while,
  // so keep calling even when nothing else is polling (e.g. no projects yet).
  useEffect(() => {
    const t = setInterval(() => api.health().then(setHealth).catch(() => {}), 20000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => { loadProject(); }, [projectId, loadProject]);

  // Poll fast while work is running, slowly otherwise.
  const running = project?.running;
  useEffect(() => {
    const t = setInterval(loadProject, running ? 1000 : 4000);
    return () => clearInterval(t);
  }, [loadProject, running]);
  useEffect(() => { if (!running) loadProjects(); }, [running, loadProjects]);

  const onCreated = (p) => { setNewOpen(false); loadProjects(); setProjectId(p.id); setPage("dashboard"); };
  const refresh = () => { loadProject(); loadProjects(); };
  const [title, subtitle] = TITLES[page];

  if (expired) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Background />
        <SessionExpired />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <ToastProvider>
        <Background />
        <Box sx={{ display: "flex", minHeight: "100vh", position: "relative", zIndex: 1 }}>
          <Sidebar page={page} onNavigate={setPage} mode={mode} onToggleMode={toggleMode} health={health} />
          <Box component="main" sx={{ flex: 1, minWidth: 0, overflowX: "clip" }}>
            <Box sx={{
              position: "sticky", top: 0, zIndex: 5, px: { xs: 2, md: 4 }, py: 2,
              backdropFilter: "blur(16px)", borderBottom: "1px solid", borderColor: "divider",
              background: theme.custom.dark ? "rgba(6,10,20,.55)" : "rgba(238,242,248,.6)",
            }}>
              <Stack direction="row" alignItems="center" spacing={2}>
                <Box sx={{ flex: 1, minWidth: 0, display: { xs: page === "dashboard" && projects.length ? "none" : "block", sm: "block" } }}>
                  <Typography variant="h5" noWrap sx={{ lineHeight: 1.2 }}>{title}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ display: { xs: "none", sm: "block" } }}>{subtitle}</Typography>
                </Box>
                {projects.length > 0 && page === "dashboard" && (
                  <Select size="small" displayEmpty value={projectId || ""} onChange={(e) => setProjectId(e.target.value)}
                    sx={{ flex: { xs: 1, sm: "none" }, minWidth: { xs: 0, md: 280 }, maxWidth: 360, borderRadius: 3, fontWeight: 600 }}
                    renderValue={(v) => {
                      const p = projects.find((x) => x.id === v);
                      return p ? (
                        <Stack direction="row" spacing={1} alignItems="center">
                          <Box sx={{ width: 8, height: 8, borderRadius: "50%", background: brand.gradient, flexShrink: 0 }} />
                          <Box component="span" sx={{ overflow: "hidden", textOverflow: "ellipsis" }}>{p.study_name}</Box>
                        </Stack>
                      ) : <Box component="span" sx={{ color: "text.secondary", fontWeight: 500 }}>Open a previous project…</Box>;
                    }}>
                    {projects.map((p) => (
                      <MenuItem key={p.id} value={p.id}>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 650 }}>{p.study_name}</Typography>
                          <Typography variant="caption" color="text.secondary">{p.completed_steps}/{p.total_steps} steps · {p.project_path}</Typography>
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                )}
                <Button variant="contained" startIcon={<AddRoundedIcon />} onClick={() => setNewOpen(true)}
                  sx={{ whiteSpace: "nowrap", flexShrink: 0 }}>
                  <Box component="span" sx={{ display: { xs: "none", sm: "inline" } }}>New project</Box>
                </Button>
              </Stack>
            </Box>
            <Box sx={{ p: { xs: 2, md: 4 }, maxWidth: 1680, mx: "auto" }}>
              {page === "dashboard" && (
                <Dashboard project={project} logs={logs} settings={settings} onChanged={refresh}
                  onNew={() => setNewOpen(true)} onGuide={() => setPage("guide")}
                  onPrevious={() => setPage("projects")} hasProjects={projects.length > 0} />
              )}
              {page === "guide" && <GuidePage />}
              {page === "projects" && (
                <ProjectsPage projects={projects} onNew={() => setNewOpen(true)} onChanged={loadProjects}
                  onOpen={(id) => { setProjectId(id); setPage("dashboard"); }} />
              )}
              {page === "logs" && <LogsPage />}
              {page === "settings" && <SettingsPage health={health} onSaved={loadMeta} />}
            </Box>
          </Box>
        </Box>
        <NewProjectDialog open={newOpen} onClose={() => setNewOpen(false)} onCreated={onCreated} defaultRoot={settings?.root_path} />
      </ToastProvider>
    </ThemeProvider>
  );
}

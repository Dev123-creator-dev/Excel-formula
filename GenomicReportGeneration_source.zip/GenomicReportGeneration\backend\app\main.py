"""FastAPI application: REST API + the compiled React UI."""
from __future__ import annotations

import getpass
import os
import platform
import subprocess
import threading
import time
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import APP_NAME, APP_VERSION
from .config import app_data_dir, detect_rscript, resource_dir, settings_store
from .db import db
from .security import SecurityMiddleware
from .services.common import StepError, create_project_folders, resolve_project_folder
from .workflow import STEP_KEYS, STEPS, engine, log_event

STARTED_AT = time.time()
USER = getpass.getuser()

# No interactive API docs in a shipped desktop app.
app = FastAPI(title=APP_NAME, version=APP_VERSION, docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(SecurityMiddleware)
db.mark_interrupted()
last_request_at = time.time()  # read by the launcher's idle-shutdown watchdog


@app.middleware("http")
async def track_activity(request, call_next):
    global last_request_at
    if request.url.path.startswith("/api/"):
        last_request_at = time.time()
    return await call_next(request)


@app.exception_handler(StepError)
async def step_error_handler(_, exc: StepError):
    return JSONResponse(status_code=409, content={"detail": str(exc), "hint": exc.hint})


# --------------------------------------------------------------------------- models
class ProjectIn(BaseModel):
    folder: str = Field(min_length=2, max_length=240)


class InputsIn(BaseModel):
    values: dict[str, str]


class PickIn(BaseModel):
    kind: str = "file"            # file | folder
    title: str = Field("Select file", max_length=120)
    extensions: list[str] = []    # e.g. [".xlsx"]
    initial: str = Field("", max_length=400)


class PathIn(BaseModel):
    path: str = Field(max_length=400)


ALLOWED_INPUTS = {
    "excel_template", "word_template", "diffex_path", "mutation_path", "clustering_input_path",
    "r_script_path", "r_helper_path", "analysis_parameter", "report_compound", "report_client", "report_order_id",
}
# Files the user picks once and that should be pre-filled for the next project.
REMEMBERED = {"r_script_path": "r_script_path", "r_helper_path": "r_helper_path",
              "excel_template": "default_excel_template", "word_template": "default_word_template"}
# Never hand these to the shell, even if they sit inside a project folder.
BLOCKED_EXTENSIONS = {".exe", ".com", ".bat", ".cmd", ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse", ".wsf",
                      ".wsh", ".msi", ".msp", ".scr", ".pif", ".lnk", ".hta", ".cpl", ".jar", ".reg", ".dll",
                      ".url", ".appref-ms", ".r", ".py", ".pyw"}


def _project_or_404(project_id: int) -> dict:
    project = db.get_project(project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


def _project_view(project: dict) -> dict:
    steps = engine.state(project["id"])
    files = db.list_files(project["id"])
    done = sum(1 for s in steps if s["status"] in ("completed", "skipped"))
    current = next((s for s in steps if s["status"] == "running"), None) or \
        next((s for s in steps if s["status"] not in ("completed", "skipped")), None)
    errors = db.one("SELECT COUNT(*) n FROM audit_log WHERE project_id=? AND level='error'", (project["id"],))["n"]
    warnings = db.one("SELECT COUNT(*) n FROM audit_log WHERE project_id=? AND level='warning'", (project["id"],))["n"]
    exec_time = sum(s["duration_s"] or 0 for s in steps if s["status"] == "completed")
    running = next((s for s in steps if s["status"] == "running"), None)
    progress = (done + (running["progress"] / 100 if running else 0)) / len(steps) * 100
    return {
        **project,
        "steps": steps,
        "files": [{**f, "exists": os.path.exists(f["path"])} for f in files],
        "running": engine.is_running(project["id"]),
        "metrics": {
            "completed_steps": done,
            "total_steps": len(steps),
            "progress": round(progress, 1),
            "current_step": current["title"] if current else "All steps complete",
            "current_status": current["status"] if current else "completed",
            "execution_time_s": round(exec_time, 1),
            "output_files": len([f for f in files if not f["kind"].startswith(("oncopredictor_", "clustering_input"))]),
            "errors": errors,
            "warnings": warnings,
        },
    }


def _inside_projects(path: Path) -> bool:
    """True when path is (inside) a folder of a project this app manages."""
    try:
        target = path.resolve()
    except OSError:
        return False
    for p in db.list_projects():
        root = Path(p["project_path"]).resolve()
        if target == root or root in target.parents:
            return True
    return False


# --------------------------------------------------------------------------- system
@app.get("/api/ping")
def ping():
    """Unauthenticated liveness probe used by the launcher (reveals nothing)."""
    return {"app": APP_NAME}


@app.get("/api/health")
def health():
    s = settings_store.get()
    rscript = s.rscript_exe if s.rscript_exe and Path(s.rscript_exe).exists() else detect_rscript()
    browsers = (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
                r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe")
    browser = next((b for b in browsers if Path(b).exists()), "")
    return {
        "app": APP_NAME,
        "version": APP_VERSION,
        "uptime_s": round(time.time() - STARTED_AT),
        "machine": platform.node(),
        "user": USER,
        "python": platform.python_version(),
        "data_dir": str(app_data_dir()),
        "checks": {
            "rscript_exe": {"ok": bool(rscript), "detail": rscript or "R not installed - only needed for Step 2"},
            "browser": {"ok": bool(browser), "detail": Path(browser).stem.replace("msedge", "Microsoft Edge")
                        .replace("chrome", "Google Chrome") if browser else "Chrome / Edge not found"},
            "root_path": {"ok": Path(s.root_path).exists(), "detail": s.root_path},
        },
    }


@app.get("/api/settings")
def get_settings():
    return settings_store.get().model_dump()


@app.put("/api/settings")
def put_settings(values: dict):
    values.pop("port", None)
    try:
        updated = settings_store.update(values)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    log_event(None, "info", "Settings updated", ", ".join(sorted(values)), actor=USER)
    return updated.model_dump()


_pick_lock = threading.Lock()


@app.post("/api/system/pick")
def pick_path(req: PickIn):
    """Native Windows file/folder dialog (the browser cannot reveal full paths)."""
    import tkinter as tk
    from tkinter import filedialog

    exts = [e for e in req.extensions if e.startswith(".") and e[1:].isalnum() and len(e) <= 6]
    with _pick_lock:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        try:
            initial = req.initial if req.initial and os.path.isdir(req.initial) else (
                os.path.dirname(req.initial) if req.initial else "")
            if req.kind == "folder":
                path = filedialog.askdirectory(title=req.title, initialdir=initial or None, parent=root)
            else:
                types = [("Allowed files", " ".join(f"*{e}" for e in exts))] if exts else []
                path = filedialog.askopenfilename(title=req.title, initialdir=initial or None,
                                                  filetypes=types + [("All files", "*.*")], parent=root)
        finally:
            root.destroy()
    return {"path": os.path.normpath(path) if path else ""}


@app.post("/api/system/open")
def open_path(req: PathIn):
    path = Path(req.path)
    if not path.exists():
        raise HTTPException(404, f"Path not found: {path}")
    if not _inside_projects(path):
        raise HTTPException(403, "Only files inside a project folder can be opened.")
    if path.is_file() and path.suffix.lower() in BLOCKED_EXTENSIONS:
        raise HTTPException(403, f"Opening {path.suffix} files is blocked for safety. Use 'Show in folder'.")
    os.startfile(str(path))  # noqa: S606 - validated above, user-initiated
    return {"ok": True}


@app.post("/api/system/reveal")
def reveal_path(req: PathIn):
    path = Path(req.path)
    if not path.exists():
        raise HTTPException(404, f"Path not found: {path}")
    if not _inside_projects(path):
        raise HTTPException(403, "Only files inside a project folder can be shown.")
    args = ["explorer", f"/select,{path}"] if path.is_file() else ["explorer", str(path)]
    subprocess.Popen(args)  # noqa: S603 - fixed program, validated path argument
    return {"ok": True}


@app.post("/api/system/oncopredictor")
def open_oncopredictor():
    """Open the configured OncoPredictor site (https only, validated in settings)."""
    import webbrowser
    webbrowser.open(settings_store.get().oncopredictor_url)
    return {"ok": True}


# --------------------------------------------------------------------------- projects
@app.get("/api/projects")
def list_projects():
    out = []
    for p in db.list_projects():
        steps = engine.state(p["id"])
        done = sum(1 for s in steps if s["status"] in ("completed", "skipped"))
        failed = any(s["status"] == "failed" for s in steps)
        out.append({**p, "completed_steps": done, "total_steps": len(steps),
                    "failed": failed, "running": engine.is_running(p["id"])})
    return out


@app.post("/api/projects/preview")
def preview_project(body: ProjectIn):
    path = resolve_project_folder(body.folder)
    existing = db.find_project_by_path(str(path))
    return {"project_path": str(path), "name": path.name, "exists": bool(existing), "reopen": path.exists()}


@app.post("/api/projects")
def create_project(body: ProjectIn):
    project_path = resolve_project_folder(body.folder)
    existing = db.find_project_by_path(str(project_path))
    if existing:
        create_project_folders(project_path)
        log_event(existing, "info", "Project reopened", str(project_path), actor=USER)
        return _project_view(existing)
    try:
        created = create_project_folders(project_path)
    except OSError as exc:
        raise HTTPException(400, f"Could not create the project folders: {exc}") from exc
    name = project_path.name
    pid = db.create_project({
        "name": name, "study_name": name, "compound_name": "", "client_name": "", "project_code": "",
        "user_email": USER, "root_path": str(project_path.parent), "project_path": str(project_path),
    })
    project = db.get_project(pid)
    for key in STEP_KEYS:
        db.upsert_step(pid, key)
    log_event(project, "success", "Project created", str(project_path), actor=USER)
    log_event(project, "info", "Folder structure created", f"{len(created)} folders", actor=USER)
    s = settings_store.get()
    remembered = {k: getattr(s, attr) for k, attr in REMEMBERED.items()
                  if getattr(s, attr) and os.path.isfile(getattr(s, attr))}
    if remembered:
        db.update_inputs(pid, remembered)
    settings_store.update({"root_path": str(project_path.parent)})
    return _project_view(db.get_project(pid))


@app.get("/api/projects/{project_id}")
def get_project(project_id: int):
    return _project_view(_project_or_404(project_id))


@app.delete("/api/projects/{project_id}")
def delete_project(project_id: int):
    project = _project_or_404(project_id)
    if engine.is_running(project_id):
        raise HTTPException(409, "Stop the running workflow first.")
    db.delete_project(project_id)
    log_event(None, "warning", "Project removed from dashboard",
              f"{project['study_name']} (files kept at {project['project_path']})", actor=USER)
    return {"ok": True}


@app.patch("/api/projects/{project_id}/inputs")
def update_inputs(project_id: int, body: InputsIn):
    project = _project_or_404(project_id)
    unknown = set(body.values) - ALLOWED_INPUTS
    if unknown:
        raise HTTPException(400, f"Unknown inputs: {', '.join(sorted(unknown))}")
    if any(len(v) > 400 for v in body.values.values()):
        raise HTTPException(400, "Value too long")
    values = {k: v.strip().strip('"') for k, v in body.values.items()}
    inputs = db.update_inputs(project_id, values)
    remember = {REMEMBERED[k]: v for k, v in values.items() if k in REMEMBERED and v}
    if remember:
        settings_store.update(remember)
    for k, v in values.items():
        log_event(project, "info", "Input updated", f"{k} = {v}", actor=USER)
    return inputs


@app.post("/api/projects/{project_id}/run")
def run_all(project_id: int):
    _project_or_404(project_id)
    engine.start(project_id, None, USER)
    return {"ok": True}


@app.post("/api/projects/{project_id}/cancel")
def cancel(project_id: int):
    _project_or_404(project_id)
    engine.cancel(project_id, USER)
    return {"ok": True}


@app.post("/api/projects/{project_id}/steps/{key}/{action}")
def step_action(project_id: int, key: str, action: str):
    _project_or_404(project_id)
    if key not in STEP_KEYS:
        raise HTTPException(404, "Unknown step")
    if action == "run":
        engine.start(project_id, [key], USER)
    elif action == "skip":
        engine.skip(project_id, key, USER)
    elif action == "reset":
        engine.reset(project_id, key, USER)
    else:
        raise HTTPException(404, "Unknown action")
    return {"ok": True}


@app.get("/api/projects/{project_id}/logs")
def project_logs(project_id: int, after_id: int = 0, limit: int = 300):
    _project_or_404(project_id)
    return db.list_audit(project_id, after_id, min(max(limit, 1), 2000))


@app.get("/api/logs")
def all_logs(limit: int = 1000):
    return db.query(
        "SELECT a.*, p.study_name FROM audit_log a LEFT JOIN projects p ON p.id=a.project_id "
        "ORDER BY a.id DESC LIMIT ?", (min(max(limit, 1), 5000),))


@app.get("/api/steps")
def step_catalog():
    return STEPS


# --------------------------------------------------------------------------- UI
STATIC_DIR = (resource_dir() / "app" / "static").resolve()
if (STATIC_DIR / "assets").exists():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")


@app.get("/{full_path:path}", include_in_schema=False)
def spa(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(404, "Not found")
    target = (STATIC_DIR / full_path).resolve()
    # Path traversal guard: only files inside the bundled UI folder.
    if full_path and target.is_file() and STATIC_DIR in target.parents:
        return FileResponse(target)
    index = STATIC_DIR / "index.html"
    if index.exists():
        return FileResponse(index)
    return JSONResponse({"detail": "UI not built. Run: cd frontend && npm run build"}, status_code=503)

# Builds dist\GenomicReportGeneration.exe - ONE self-contained file to hand to users.
#   1. installs Python deps into .venv   2. builds the React UI   3. packages with PyInstaller
# Usage (PowerShell):  .\build.ps1
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Set-Location $root

if (-not (Test-Path "$root\.venv\Scripts\python.exe")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Cyan
    python -m venv .venv
}
$py = "$root\.venv\Scripts\python.exe"
& $py -m pip install --disable-pip-version-check -q -r backend\requirements.txt "pyinstaller>=6.10"
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

Write-Host "Building UI..." -ForegroundColor Cyan
Push-Location frontend
if (-not (Test-Path node_modules)) { npm ci --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { npm install --no-audit --no-fund } }
npm run build
if ($LASTEXITCODE -ne 0) { Pop-Location; throw "UI build failed" }
Pop-Location

Write-Host "Packaging executable..." -ForegroundColor Cyan
Push-Location backend
& $py -m PyInstaller --noconfirm --clean --windowed --onefile `
    --name GenomicReportGeneration `
    --icon "$root\backend\assets\app.ico" `
    --distpath "$root\dist" --workpath "$root\build" --specpath "$root\build" `
    --add-data "$root\backend\app\static;app\static" `
    --add-data "$root\R\GenerateClusteringFile.R;R" `
    --collect-submodules uvicorn `
    --collect-data selenium `
    --collect-submodules selenium.webdriver.chrome `
    --hidden-import docx --hidden-import openpyxl --hidden-import defusedxml `
    --exclude-module pandas --exclude-module numpy --exclude-module matplotlib `
    launcher.py
if ($LASTEXITCODE -ne 0) { Pop-Location; throw "PyInstaller failed" }
Pop-Location

Write-Host ""
Write-Host "Done: dist\GenomicReportGeneration.exe  (single file - share just this)" -ForegroundColor Green

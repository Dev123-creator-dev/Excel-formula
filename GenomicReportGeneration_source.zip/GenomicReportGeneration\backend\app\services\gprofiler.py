"""Step 5 - g:Profiler g:GOSt pathway analysis (Selenium, with REST API fallback).

Selenium drives the public g:GOSt page exactly as an analyst would:
paste genes -> Homo sapiens -> Ordered query -> Run -> Detailed Results -> CSV.
If the query returns "No results." the run is repeated with
Advanced options -> "All results" ticked.

Sensitivity and resistance queries run in parallel in separate Chrome sessions.
"""
from __future__ import annotations

import csv
import math
import re
import shutil
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests

from .common import Cancelled, StepContext, StepError, csv_safe

GENE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-/@]{0,49}$")


def clean_genes(genes: list[str]) -> list[str]:
    """Only well-formed gene symbols are sent to the website / API."""
    return [g.strip() for g in genes if isinstance(g, str) and GENE_RE.match(g.strip())]

API_URL = "https://biit.cs.ut.ee/gprofiler/api/gost/profile/"
CSV_COLUMNS = ["source", "term_name", "term_id", "highlighted", "adjusted_p_value",
               "negative_log10_of_adjusted_p_value", "term_size", "query_size",
               "intersection_size", "effective_domain_size", "intersections"]

QUERIES = {
    # name: (gene list key, highlight driver terms)
    "Sensitivity": ("top60_sensitive", True),
    "Resistance": ("top60_resistant", False),
}


# --------------------------------------------------------------------------- Selenium
class GostBrowser:
    def __init__(self, url: str, download_dir: Path, headless: bool, timeout: int, ctx: StepContext):
        from selenium import webdriver

        self.url, self.download_dir, self.timeout, self.ctx = url, download_dir, timeout, ctx

        def options(cls):
            opts = cls()
            if headless:
                opts.add_argument("--headless=new")
            opts.add_argument("--window-size=1500,1000")
            opts.add_argument("--disable-notifications")
            opts.add_experimental_option("excludeSwitches", ["enable-logging"])
            opts.add_experimental_option("prefs", {
                "download.default_directory": str(download_dir),
                "download.prompt_for_download": False,
                "download.directory_upgrade": True,
                "safebrowsing.enabled": True,
            })
            return opts

        # Chrome first; Microsoft Edge ships with every Windows 10/11 machine.
        try:
            self.driver = webdriver.Chrome(options=options(webdriver.ChromeOptions))
        except Exception as chrome_error:  # noqa: BLE001
            try:
                self.driver = webdriver.Edge(options=options(webdriver.EdgeOptions))
                ctx.info("Chrome unavailable - using Microsoft Edge", str(chrome_error).splitlines()[0][:200])
            except Exception:
                raise chrome_error

    # -- helpers ------------------------------------------------------------
    def _wait(self, predicate, timeout: float | None = None, poll: float = 0.5):
        end = time.time() + (timeout or self.timeout)
        while time.time() < end:
            self.ctx.check_cancel()
            try:
                result = predicate()
                if result:
                    return result
            except Exception:
                pass
            time.sleep(poll)
        raise StepError("Timed out waiting for the g:Profiler page to respond.")

    def _click(self, element) -> None:
        self.driver.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", element)

    def set_checkbox(self, label: str, checked: bool) -> None:
        box = self._wait(lambda: self.driver.execute_script(
            "const l=[...document.querySelectorAll('label')].find(x=>x.innerText.trim()===arguments[0]);"
            "return l ? l.querySelector('input[type=checkbox]') : null;", label), timeout=20)
        if box.is_selected() != checked:
            self._click(box)

    def _body_text(self) -> str:
        from selenium.webdriver.common.by import By
        return self.driver.find_element(By.TAG_NAME, "body").text

    # -- workflow -----------------------------------------------------------
    def open(self) -> None:
        from selenium.webdriver.common.by import By
        self.driver.get(self.url)
        self._wait(lambda: self.driver.find_element(By.CSS_SELECTOR, "textarea.querybox").is_displayed(), 60)

    def ensure_human(self) -> None:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        if "Homo sapiens" in self._body_text().split("Highlight driver")[0]:
            return
        box = self.driver.find_element(By.CSS_SELECTOR, ".vue3-treeselect__input")
        self._click(box)
        box.send_keys("Homo sapiens")
        time.sleep(1.5)
        box.send_keys(Keys.ENTER)
        self._wait(lambda: "Homo sapiens" in self._body_text(), 15)

    def run_query(self, genes: list[str]) -> bool:
        """Returns True when significant results are shown."""
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        area = self.driver.find_element(By.CSS_SELECTOR, "textarea.querybox")
        area.send_keys(Keys.CONTROL, "a")
        area.send_keys(Keys.DELETE)
        area.send_keys("\n".join(genes))
        run_btn = self.driver.find_element(By.XPATH, "//button[normalize-space()='Run query']")
        self._click(run_btn)
        time.sleep(2)

        def outcome():
            text = self._body_text()
            if "No results." in text:
                return "empty"
            tabs = self.driver.find_elements(By.CSS_SELECTOR, "li.tab-button")
            if any(t.is_displayed() and t.text.strip() == "Detailed Results" for t in tabs):
                return "results"
            return None

        return self._wait(outcome) == "results"

    def enable_all_results(self) -> None:
        from selenium.webdriver.common.by import By
        link = self.driver.find_element(By.XPATH, "//a[normalize-space()='Advanced options']")
        self._click(link)
        time.sleep(1)
        self.set_checkbox("All results", True)

    def download_csv(self, target: Path) -> Path:
        from selenium.webdriver.common.by import By
        before = set(self.download_dir.glob("*.csv"))
        tab = self.driver.find_element(By.XPATH, "//li[contains(@class,'tab-button')][normalize-space()='Detailed Results']")
        self._click(tab)
        btn = self._wait(lambda: next((b for b in self.driver.find_elements(By.XPATH, "//button[normalize-space()='CSV']")
                                       if b.is_displayed()), None), 30)
        self._click(btn)

        def finished():
            new = [p for p in self.download_dir.glob("*.csv") if p not in before]
            pending = list(self.download_dir.glob("*.crdownload"))
            return new[0] if new and not pending else None

        downloaded = self._wait(finished, 60)
        if target.exists():
            target.unlink()
        shutil.move(str(downloaded), target)
        return target

    def screenshot(self, target: Path) -> None:
        try:
            self.driver.save_screenshot(str(target))
        except Exception:
            pass

    def close(self) -> None:
        try:
            self.driver.quit()
        except Exception:
            pass


def _run_selenium(ctx: StepContext, name: str, genes: list[str], highlight: bool, out_dir: Path) -> dict:
    s = ctx.settings
    tmp = out_dir / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    browser = GostBrowser(s.gprofiler_url, tmp, s.gprofiler_headless, s.gprofiler_timeout_seconds, ctx)
    try:
        ctx.info(f"{name}: opening g:GOSt", s.gprofiler_url)
        browser.open()
        browser.ensure_human()
        browser.set_checkbox("Ordered query", True)
        browser.set_checkbox("Highlight driver terms in GO", highlight)
        ctx.info(f"{name}: running query", f"{len(genes)} genes, Homo sapiens, ordered, highlight={highlight}")
        all_results = False
        if not browser.run_query(genes):
            ctx.warn(f"{name}: no significant results", "Re-running with Advanced options -> All results")
            browser.enable_all_results()
            all_results = True
            if not browser.run_query(genes):
                raise StepError(f"{name}: g:Profiler returned no results even with 'All results'.")
        target = out_dir / f"{ctx.file_prefix}_gProfiler_{name}.csv"
        browser.download_csv(target)
        browser.screenshot(out_dir / f"{ctx.file_prefix}_gProfiler_{name}.png")
        return {"csv": str(target), "all_results": all_results, "engine": "selenium"}
    finally:
        browser.close()
        shutil.rmtree(tmp, ignore_errors=True)


# --------------------------------------------------------------------------- REST API
def _run_api(ctx: StepContext, name: str, genes: list[str], highlight: bool, out_dir: Path) -> dict:
    def query(all_results: bool) -> dict:
        resp = requests.post(API_URL, json={
            "organism": "hsapiens", "query": genes, "ordered": True,
            "all_results": all_results, "no_evidences": False,
            "highlight": highlight, "user_threshold": 0.05,
        }, timeout=ctx.settings.gprofiler_timeout_seconds)
        resp.raise_for_status()
        return resp.json()

    payload = query(False)
    all_results = False
    if not payload.get("result"):
        ctx.warn(f"{name}: no significant results (API)", "Re-running with all_results")
        payload, all_results = query(True), True

    meta = payload.get("meta", {}).get("genes_metadata", {})
    ensgs = (meta.get("query", {}).get("query_1", {}) or {}).get("ensgs", [])
    ensg_to_name: dict[str, str] = {}
    for gene, ids in (meta.get("query", {}).get("query_1", {}).get("mapping", {}) or {}).items():
        for eid in ids:
            ensg_to_name.setdefault(eid, gene)

    target = out_dir / f"{ctx.file_prefix}_gProfiler_{name}.csv"
    with open(target, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh, quoting=csv.QUOTE_ALL)
        writer.writerow(CSV_COLUMNS)
        for r in payload.get("result", []):
            inter = [ensg_to_name.get(ensgs[i], ensgs[i]) for i, ev in enumerate(r.get("intersections", []))
                     if ev and i < len(ensgs)]
            p = r.get("p_value") or 0
            writer.writerow([
                csv_safe(r.get("source")), csv_safe(r.get("name")), csv_safe(r.get("native")),
                str(bool(r.get("highlighted"))).lower(),
                p, (-math.log10(p) if p > 0 else ""), r.get("term_size"), r.get("query_size"),
                r.get("intersection_size"), r.get("effective_domain_size"), csv_safe(",".join(inter)),
            ])
    return {"csv": str(target), "all_results": all_results, "engine": "api",
            "terms": len(payload.get("result", []))}


# --------------------------------------------------------------------------- step
def _one(ctx: StepContext, name: str, genes: list[str], highlight: bool) -> dict:
    out_dir = ctx.path / "GProfiler" / name
    out_dir.mkdir(parents=True, exist_ok=True)
    s = ctx.settings
    if s.gprofiler_engine == "selenium":
        try:
            return _run_selenium(ctx, name, genes, highlight, out_dir)
        except Cancelled:
            raise
        except Exception as exc:  # noqa: BLE001 - surfaced to the user below
            if not s.gprofiler_fallback_to_api:
                raise StepError(f"{name}: browser automation failed - {exc}") from exc
            ctx.warn(f"{name}: browser automation failed, using g:Profiler API", str(exc)[:300])
    return _run_api(ctx, name, genes, highlight, out_dir)


def run(ctx: StepContext) -> dict:
    genes = ctx.step_data("genes")
    if not genes.get("top60_sensitive"):
        raise StepError("Gene lists are missing - run step 4 first.")

    ctx.progress(10, "Launching sensitivity & resistance queries in parallel")
    results: dict[str, dict] = {}
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="gprofiler") as pool:
        futures = {name: pool.submit(_one, ctx, name, clean_genes(genes[key]), hl) for name, (key, hl) in QUERIES.items()}
        for i, (name, fut) in enumerate(futures.items(), start=1):
            results[name] = fut.result()
            ctx.register_file(f"gprofiler_{name.lower()}", results[name]["csv"])
            png = Path(results[name]["csv"]).with_suffix(".png")
            if png.exists():
                ctx.register_file("gprofiler_screenshot", str(png))
            with open(results[name]["csv"], encoding="utf-8") as fh:
                results[name]["terms"] = max(sum(1 for _ in fh) - 1, 0)
            ctx.success(f"g:Profiler {name} CSV saved",
                        f"{results[name]['terms']} terms via {results[name]['engine']} -> {results[name]['csv']}")
            ctx.progress(10 + 45 * i, f"{name} complete")

    return {
        "sensitivity": results["Sensitivity"],
        "resistance": results["Resistance"],
        "summary": f"Sensitivity {results['Sensitivity']['terms']} terms, Resistance {results['Resistance']['terms']} terms",
    }

"""Workflow orchestration: ordering, gating, background execution, resume, audit."""
from __future__ import annotations

import os
import threading
import time
import traceback
from typing import Callable

from .config import settings_store
from .db import db, now_iso
from .services import clustering, diffex, gprofiler, oncopredictor, packaging, report
from .services.common import Cancelled, NeedsInput, StepContext, StepError, write_activity_line

STEPS: list[dict] = [
    {"key": "import", "title": "OncoPredictor Output Collection",
     "description": "Select the DiffEx & Mutation reports - they are validated and moved into the project.", "skippable": False},
    {"key": "clustering", "title": "Clustering Script Execution",
     "description": "Select the R script, helper and assay data - paths are updated and R runs automatically.", "skippable": True},
    {"key": "diffex", "title": "DiffEx Table Generation",
     "description": "Copy DiffEx A:P into 'Table 3 for DiffEx' and generate formulas.", "skippable": False},
    {"key": "genes", "title": "Sensitivity Gene Extraction",
     "description": "Collect top-60 sensitivity (AE) and resistance (AF) genes.", "skippable": False},
    {"key": "gprofiler", "title": "g:Profiler Pathway Analysis",
     "description": "Run g:GOSt for sensitivity & resistance genes and download CSVs.", "skippable": True},
    {"key": "report", "title": "Word Report Generation",
     "description": "Populate Table 3, placeholders and the summary gene lists.", "skippable": False},
    {"key": "package", "title": "Final Report Packaging",
     "description": "Bundle all deliverables with a checksum manifest.", "skippable": False},
]
STEP_KEYS = [s["key"] for s in STEPS]
DONE = {"completed", "skipped"}


def _runner(key: str) -> Callable[[StepContext], dict]:
    return {
        "import": oncopredictor.run,
        "clustering": clustering.run,
        "diffex": diffex.run_table,
        "genes": diffex.run_genes,
        "gprofiler": gprofiler.run,
        "report": report.run,
        "package": lambda ctx: packaging.run(ctx, db.list_files(ctx.project["id"])),
    }[key]


def log_event(project: dict | None, level: str, action: str, detail: str = "",
              step_key: str | None = None, actor: str = "system") -> dict:
    entry = db.audit(project["id"] if project else None, level, action, detail, step_key, actor)
    if project:
        write_activity_line(project["project_path"], level, action, detail)
    return entry


class WorkflowEngine:
    def __init__(self) -> None:
        self._threads: dict[int, threading.Thread] = {}
        self._cancel: dict[int, threading.Event] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ state
    def is_running(self, project_id: int) -> bool:
        t = self._threads.get(project_id)
        return bool(t and t.is_alive())

    def state(self, project_id: int) -> list[dict]:
        stored = db.get_steps(project_id)
        out = []
        for i, step in enumerate(STEPS):
            s = stored.get(step["key"], {})
            out.append({
                **step,
                "index": i + 1,
                "status": s.get("status", "pending"),
                "message": s.get("message", ""),
                "progress": s.get("progress", 0),
                "started_at": s.get("started_at"),
                "finished_at": s.get("finished_at"),
                "duration_s": s.get("duration_s"),
                "attempts": s.get("attempts", 0),
                "data": s.get("data", {}),
                "error": s.get("error"),
            })
        return out

    def blocked_by(self, project_id: int, key: str) -> str | None:
        stored = db.get_steps(project_id)
        for prev in STEP_KEYS[: STEP_KEYS.index(key)]:
            if stored.get(prev, {}).get("status") not in DONE:
                return prev
        return None

    # ---------------------------------------------------------------- control
    def start(self, project_id: int, keys: list[str] | None, actor: str) -> None:
        with self._lock:
            if self.is_running(project_id):
                raise StepError("A step is already running for this project.")
            if keys:
                blocker = self.blocked_by(project_id, keys[0])
                if blocker:
                    title = next(s["title"] for s in STEPS if s["key"] == blocker)
                    raise StepError(f"Complete '{title}' first.")
            cancel = threading.Event()
            self._cancel[project_id] = cancel
            thread = threading.Thread(target=self._run, args=(project_id, keys, actor, cancel),
                                      name=f"workflow-{project_id}", daemon=True)
            self._threads[project_id] = thread
            thread.start()

    def cancel(self, project_id: int, actor: str) -> None:
        event = self._cancel.get(project_id)
        if event and self.is_running(project_id):
            event.set()
            clustering.cancel(project_id)
            log_event(db.get_project(project_id), "warning", "Cancellation requested", actor=actor)

    def skip(self, project_id: int, key: str, actor: str) -> None:
        step = next(s for s in STEPS if s["key"] == key)
        if not step["skippable"]:
            raise StepError(f"'{step['title']}' is required and cannot be skipped.")
        if self.is_running(project_id):
            raise StepError("Wait for the running step to finish.")
        db.upsert_step(project_id, key, status="skipped", message="Skipped by user",
                       finished_at=now_iso(), progress=100)
        log_event(db.get_project(project_id), "warning", f"{step['title']} skipped", step_key=key, actor=actor)

    def reset(self, project_id: int, key: str, actor: str) -> None:
        """Re-open a step and everything after it."""
        if self.is_running(project_id):
            raise StepError("Wait for the running step to finish.")
        for later in STEP_KEYS[STEP_KEYS.index(key):]:
            db.upsert_step(project_id, later, status="pending", message="", progress=0, error=None)
        log_event(db.get_project(project_id), "info", "Workflow reset", f"from step '{key}'", key, actor)

    # ---------------------------------------------------------------- runner
    def _run(self, project_id: int, keys: list[str] | None, actor: str, cancel: threading.Event) -> None:
        run_all = keys is None
        if run_all:
            stored = db.get_steps(project_id)
            keys = [k for k in STEP_KEYS if stored.get(k, {}).get("status") not in DONE]
            if keys:
                log_event(db.get_project(project_id), "info", "Workflow run started",
                          f"{len(keys)} step(s) remaining", actor=actor)
        for key in keys:
            if cancel.is_set():
                break
            ok = self._run_step(project_id, key, actor, cancel)
            if not ok:
                break
        else:
            if run_all and keys:
                log_event(db.get_project(project_id), "success", "Workflow completed", actor=actor)

    def _run_step(self, project_id: int, key: str, actor: str, cancel: threading.Event) -> bool:
        project = db.get_project(project_id)
        step = next(s for s in STEPS if s["key"] == key)
        stored = db.get_steps(project_id)
        attempts = stored.get(key, {}).get("attempts", 0) + 1
        started = time.time()
        db.upsert_step(project_id, key, status="running", message="Starting...", progress=2,
                       started_at=now_iso(), finished_at=None, duration_s=None, error=None, attempts=attempts)
        db.clear_files(project_id, key)
        log_event(project, "info", f"{step['title']} started", f"attempt {attempts}", key, actor)

        last_write = [0.0]

        def progress(pct: float, message: str) -> None:
            if time.time() - last_write[0] > 0.4 or pct >= 100:
                last_write[0] = time.time()
                db.upsert_step(project_id, key, progress=round(min(pct, 99), 1), message=message)

        def register(kind: str, path: str) -> None:
            try:
                size = os.path.getsize(path)
            except OSError:
                size = None
            db.add_file(project_id, key, kind, path, size)

        ctx = StepContext(
            project=project, step_key=key, settings=settings_store.get(), cancel_event=cancel,
            log=lambda level, action, detail="": log_event(project, level, action, detail, key, actor),
            progress=progress, register_file=register, previous=stored,
        )
        try:
            data = _runner(key)(ctx) or {}
        except NeedsInput as exc:
            db.upsert_step(project_id, key, status="waiting_input", message=str(exc), progress=0,
                           data={"needs": exc.field_name})
            log_event(project, "warning", f"{step['title']} needs input", str(exc), key, actor)
            return False
        except Cancelled:
            db.upsert_step(project_id, key, status="interrupted", message="Cancelled - ready to resume",
                           finished_at=now_iso(), duration_s=round(time.time() - started, 1))
            log_event(project, "warning", f"{step['title']} cancelled", step_key=key, actor=actor)
            return False
        except StepError as exc:
            self._fail(project, key, step, started, str(exc), exc.hint, actor)
            return False
        except Exception as exc:  # noqa: BLE001 - unexpected: keep full trace in the audit log
            self._fail(project, key, step, started, f"Unexpected error: {exc}",
                       traceback.format_exc(limit=6), actor)
            return False

        if key == "import":
            # The originals were moved: point the inputs at the project copies so re-runs still work.
            db.update_inputs(project_id, {"diffex_path": data["diffex_file"], "mutation_path": data["mutation_file"]})
        duration = round(time.time() - started, 1)
        db.upsert_step(project_id, key, status="completed", message=data.get("summary", "Completed"),
                       progress=100, finished_at=now_iso(), duration_s=duration, data=data)
        db.touch_project(project_id)
        log_event(project, "success", f"{step['title']} completed", f"{duration}s", key, actor)
        return True

    def _fail(self, project, key, step, started, message, hint, actor) -> None:
        db.upsert_step(project["id"], key, status="failed", message=message, error=hint or message,
                       finished_at=now_iso(), duration_s=round(time.time() - started, 1))
        log_event(project, "error", f"{step['title']} failed", f"{message}\n{hint}".strip(), key, actor)


engine = WorkflowEngine()

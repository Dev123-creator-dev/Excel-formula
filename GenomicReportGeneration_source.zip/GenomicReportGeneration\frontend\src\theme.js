import { alpha, createTheme } from "@mui/material/styles";

export const brand = {
  teal: "#19E3C5",
  violet: "#7C5CFF",
  blue: "#3BA4FF",
  pink: "#FF5C8A",
  amber: "#FFB547",
  green: "#2BD99F",
  gradient: "linear-gradient(135deg, #19E3C5 0%, #3BA4FF 50%, #7C5CFF 100%)",
  gradientSoft: "linear-gradient(135deg, rgba(25,227,197,.18) 0%, rgba(124,92,255,.18) 100%)",
};

export const statusColor = {
  completed: brand.green,
  skipped: "#94A3B8",
  running: brand.blue,
  failed: brand.pink,
  waiting_input: brand.amber,
  interrupted: brand.amber,
  pending: "#64748B",
};

export function buildTheme(mode) {
  const dark = mode === "dark";
  const text = dark ? "#E6EAF2" : "#0F172A";
  const muted = dark ? "#8A94A8" : "#5B6478";
  const glass = dark ? "rgba(17, 24, 39, 0.55)" : "rgba(255, 255, 255, 0.68)";
  const border = dark ? "rgba(148, 163, 184, 0.14)" : "rgba(15, 23, 42, 0.08)";

  return createTheme({
    palette: {
      mode,
      primary: { main: dark ? brand.teal : "#0EA5A0", contrastText: "#04131A" },
      secondary: { main: brand.violet },
      error: { main: brand.pink },
      warning: { main: brand.amber },
      success: { main: brand.green },
      info: { main: brand.blue },
      background: { default: dark ? "#060A14" : "#EEF2F8", paper: glass },
      text: { primary: text, secondary: muted },
      divider: border,
    },
    // sx `borderRadius: n` multiplies this base, so 4 keeps n=3 -> 12px, n=5 -> 20px.
    shape: { borderRadius: 4 },
    typography: {
      fontFamily: '"Inter Variable", "Segoe UI Variable", "Segoe UI", system-ui, sans-serif',
      h4: { fontWeight: 750, letterSpacing: "-0.02em" },
      h5: { fontWeight: 700, letterSpacing: "-0.015em" },
      h6: { fontWeight: 650, letterSpacing: "-0.01em" },
      subtitle1: { fontWeight: 600 },
      subtitle2: { fontWeight: 600, letterSpacing: "0.01em" },
      overline: { fontWeight: 700, letterSpacing: "0.14em", fontSize: "0.68rem" },
      button: { textTransform: "none", fontWeight: 650, letterSpacing: "0.01em" },
    },
    custom: { glass, border, dark },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: { backgroundColor: dark ? "#060A14" : "#EEF2F8" },
          "*::-webkit-scrollbar": { width: 10, height: 10 },
          "*::-webkit-scrollbar-thumb": {
            background: dark ? "rgba(148,163,184,.22)" : "rgba(15,23,42,.18)",
            borderRadius: 10, border: "3px solid transparent", backgroundClip: "content-box",
          },
          "::selection": { background: alpha(brand.violet, 0.35) },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            backgroundImage: "none",
            backgroundColor: glass,
            backdropFilter: "blur(18px) saturate(140%)",
            border: `1px solid ${border}`,
          },
        },
      },
      MuiButton: {
        styleOverrides: {
          root: { borderRadius: 12, paddingInline: 18 },
          containedPrimary: {
            background: brand.gradient,
            color: "#fff",
            boxShadow: `0 8px 24px -8px ${alpha(brand.violet, 0.6)}`,
            "&:hover": { boxShadow: `0 10px 30px -6px ${alpha(brand.violet, 0.75)}`, filter: "brightness(1.08)" },
            "&.Mui-disabled": { background: dark ? "rgba(148,163,184,.15)" : "rgba(15,23,42,.08)" },
          },
          outlined: { borderColor: border, "&:hover": { borderColor: alpha(brand.teal, 0.6) } },
        },
      },
      MuiTextField: { defaultProps: { size: "small", fullWidth: true } },
      MuiOutlinedInput: {
        styleOverrides: {
          root: {
            borderRadius: 12,
            backgroundColor: dark ? "rgba(2,6,23,.35)" : "rgba(255,255,255,.75)",
            "& fieldset": { borderColor: border },
          },
        },
      },
      MuiChip: { styleOverrides: { root: { fontWeight: 600, borderRadius: 9 } } },
      MuiAlert: { styleOverrides: { root: { borderRadius: 12 } } },
      MuiMenu: { styleOverrides: { paper: { borderRadius: 12, backgroundColor: dark ? "rgba(11,16,32,.96)" : "rgba(255,255,255,.98)" } } },
      MuiToggleButton: { styleOverrides: { root: { borderColor: border } } },
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            backgroundColor: dark ? "#111827" : "#0F172A", border: `1px solid ${border}`,
            fontSize: 12, borderRadius: 8, padding: "6px 10px",
          },
        },
      },
      MuiDialog: {
        styleOverrides: {
          paper: { backgroundColor: dark ? "rgba(11,16,32,.92)" : "rgba(255,255,255,.95)", borderRadius: 20 },
        },
      },
      MuiLinearProgress: { styleOverrides: { root: { borderRadius: 99, height: 8 } } },
    },
  });
}

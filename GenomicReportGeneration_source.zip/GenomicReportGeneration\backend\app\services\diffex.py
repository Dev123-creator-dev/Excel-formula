"""Steps 3 & 4 - populate 'Table 3 for DiffEx' and extract the ranked gene lists.

Template layout ('Table 3 for DiffEx'):
  A:P      raw DiffEx report (header in row 1)
  Q        '""' spacer for every data row
  R:W      top-60 summary table (=A2.. / drug response), rows 2-61
  Y:AB     running sensitive/resistant ranks, one row per data row
  AD:AH    rank 1-60 and VLOOKUPs -> Top 60 / Top 10 sensitive & resistant

openpyxl writes formulas but cannot evaluate them, so the gene lists are also
computed here with exactly the same rules as the sheet formulas:
  sensitive  <=> Fold Change < 1   (column AA)
  resistant  <=> Fold Change > 1   (column AB)
ranked in DiffEx row order (rows are p-value ordered).
"""
from __future__ import annotations

import json
from pathlib import Path

import openpyxl

from .common import NeedsInput, StepContext, StepError, is_formula_like, output_path, validate_file

SHEET = "Table 3 for DiffEx"
TOP_N = 60
SUMMARY_N = 10


def _read_diffex(path: Path) -> list[tuple]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb.worksheets[0]
        rows = [tuple(r[:16]) for r in ws.iter_rows(min_row=1, max_col=16, values_only=True)]
    finally:
        wb.close()
    while rows and all(v is None for v in rows[-1]):
        rows.pop()
    if len(rows) < 2:
        raise StepError(f"DiffEx file has no data rows: {path.name}")
    return rows


def _as_float(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def rank_genes(rows: list[tuple]) -> dict:
    """rows exclude the header. Mirrors the template formulas."""
    sensitive, resistant, table = [], [], []
    for r in rows:
        gene, fc = r[0], _as_float(r[2])
        if gene is None or fc is None:
            continue
        if fc < 1:
            sensitive.append(str(gene))
        if fc > 1:
            resistant.append(str(gene))
    for r in rows[:TOP_N]:
        fc = _as_float(r[2])
        table.append({
            "gene": r[0], "probe": r[1], "fold_change": fc,
            "p_value": _as_float(r[3]), "q_value": _as_float(r[4]),
            "drug_response": "Sensitive" if (fc is not None and fc < 0) else "Resistant",
        })
    return {
        "top60_sensitive": sensitive[:TOP_N],
        "top60_resistant": resistant[:TOP_N],
        "top10_sensitive": sensitive[:SUMMARY_N],
        "top10_resistant": resistant[:SUMMARY_N],
        "table3": table,
        "sensitive_total": len(sensitive),
        "resistant_total": len(resistant),
    }


def populate_workbook(template: Path, rows: list[tuple], dest: Path, ctx: StepContext | None = None) -> int:
    wb = openpyxl.load_workbook(template)
    if SHEET not in wb.sheetnames:
        raise StepError(f"Template has no '{SHEET}' sheet.", f"Sheets found: {', '.join(wb.sheetnames)}")
    ws = wb[SHEET]
    n = len(rows) - 1                # data rows
    last = n + 1                     # last data row number
    old_max = ws.max_row

    for r_idx, row in enumerate(rows, start=1):
        for c_idx in range(16):
            value = row[c_idx] if c_idx < len(row) else None
            cell = ws.cell(row=r_idx, column=c_idx + 1, value=value)
            if is_formula_like(value):
                cell.data_type = "s"  # store as text: never execute input data as a formula
        if ctx and r_idx % 4000 == 0:
            ctx.check_cancel()
            ctx.progress(30 + 40 * r_idx / len(rows), f"Copying DiffEx rows {r_idx:,}/{len(rows):,}")

    # Per-row helper formulas (Q, Y:AB) sized to this dataset.
    for r in range(2, last + 1):
        ws[f"Q{r}"] = '""'
        ws[f"Y{r}"] = "=IF(LEN(AA2)>0,1,0)" if r == 2 else f"=IF(LEN(AA{r})>0,1+MAX(Y$2:Y{r - 1}),0)"
        ws[f"Z{r}"] = "=IF(LEN(AB2)>0,1,0)" if r == 2 else f"=IF(LEN(AB{r})>0,1+MAX(Z$2:Z{r - 1}),0)"
        ws[f"AA{r}"] = f'=IF(C{r}<1,A{r},"")'
        ws[f"AB{r}"] = f'=IF(C{r}>1,A{r},"")'

    # Clear leftovers when this dataset is shorter than the template's.
    for r in range(last + 1, old_max + 1):
        for col in list(range(1, 18)) + [25, 26, 27, 28]:
            ws.cell(row=r, column=col).value = None

    # Top-60 summary block (R:W, AD:AH) for rows 2-61.
    for i in range(TOP_N):
        r = i + 2
        ws[f"R{r}"], ws[f"S{r}"], ws[f"T{r}"] = f"=A{r}", f"=B{r}", f"=C{r}"
        ws[f"U{r}"], ws[f"V{r}"] = f"=D{r}", f"=E{r}"
        ws[f"W{r}"] = f'=IF(T{r}<0,"Sensitive","Resistant")'
        ws[f"AD{r}"] = i + 1
        for col, key in (("AE", "Y"), ("AF", "Z"), ("AG", "Y"), ("AH", "Z")):
            if col in ("AG", "AH") and i >= SUMMARY_N:
                ws[f"{col}{r}"] = None
                continue
            val_col = "AA" if key == "Y" else "AB"
            ws[f"{col}{r}"] = f"=IFERROR(VLOOKUP($AD{r},{key}$2:{val_col}${last},3,FALSE),\"\")"

    wb.calculation.fullCalcOnLoad = True   # Excel recalculates on open
    if ctx:
        ctx.progress(75, "Saving workbook")
    dest.parent.mkdir(parents=True, exist_ok=True)
    wb.save(dest)
    return n


def run_table(ctx: StepContext) -> dict:
    template_path = ctx.inputs.get("excel_template") or ctx.settings.default_excel_template
    if not template_path:
        raise NeedsInput("Select the Mutations & Hotspots Excel template to continue.", "excel_template")
    template = validate_file(template_path, "Excel template", (".xlsx", ".xlsm"))
    diffex = validate_file(ctx.step_data("import").get("diffex_file"), "Imported DiffEx file", (".xlsx", ".xlsm"))

    ctx.info("Reading DiffEx output", diffex.name)
    ctx.progress(10, "Reading DiffEx file")
    rows = _read_diffex(diffex)
    ctx.check_cancel()

    dest = output_path(ctx.path / "DiffEx", template.name, ctx.file_prefix, "DiffEx_Tables")
    ctx.info("Copying DiffEx A:P into 'Table 3 for DiffEx'", f"{len(rows) - 1:,} rows")
    n = populate_workbook(template, rows, dest, ctx)
    ctx.register_file("diffex_workbook", str(dest))
    ctx.success("DiffEx workbook generated", str(dest))

    ranked = rank_genes(rows[1:])
    cache = ctx.path / "DiffEx" / "ranked_genes.json"
    cache.write_text(json.dumps(ranked, indent=2, default=str), encoding="utf-8")
    return {
        "workbook": str(dest),
        "rows": n,
        "template": str(template),
        "ranked_cache": str(cache),
        "summary": f"{n:,} rows written, formulas generated for rows 2-{n + 1}",
    }


def _read_cached_column(ws, col: str, start: int, end: int) -> list[str]:
    values = [ws[f"{col}{r}"].value for r in range(start, end + 1)]
    return [str(v) for v in values if v not in (None, "", 0)]


def run_genes(ctx: StepContext) -> dict:
    data = ctx.step_data("diffex")
    workbook = validate_file(data.get("workbook"), "DiffEx workbook", (".xlsx", ".xlsm"))
    ctx.progress(30, "Reading AE2:AE61 / AF2:AF61")

    # If the workbook has been recalculated by Excel, trust its cached values.
    wb = openpyxl.load_workbook(workbook, read_only=True, data_only=True)
    try:
        ws = wb[SHEET]
        cached = {
            "top60_sensitive": _read_cached_column(ws, "AE", 2, 61),
            "top60_resistant": _read_cached_column(ws, "AF", 2, 61),
        }
    finally:
        wb.close()

    cache_path = Path(data.get("ranked_cache", ""))
    if cache_path.exists():
        ranked = json.loads(cache_path.read_text(encoding="utf-8"))
    else:
        ranked = rank_genes(_read_diffex(workbook)[1:])

    source = "computed (formula-equivalent)"
    if cached["top60_sensitive"]:
        source = "workbook cached values"
        ranked["top60_sensitive"] = cached["top60_sensitive"]
        ranked["top60_resistant"] = cached["top60_resistant"]
        ranked["top10_sensitive"] = cached["top60_sensitive"][:SUMMARY_N]
        ranked["top10_resistant"] = cached["top60_resistant"][:SUMMARY_N]

    if not ranked["top60_sensitive"]:
        raise StepError("No sensitivity genes found (no rows with Fold Change < 1).")
    if len(ranked["top60_sensitive"]) < TOP_N:
        ctx.warn("Fewer than 60 sensitivity genes", f"{len(ranked['top60_sensitive'])} found")
    if len(ranked["top60_resistant"]) < TOP_N:
        ctx.warn("Fewer than 60 resistance genes", f"{len(ranked['top60_resistant'])} found")

    out_dir = ctx.path / "DiffEx"
    for key, fname in (("top60_sensitive", "Top60_Sensitivity_Genes.txt"),
                       ("top60_resistant", "Top60_Resistance_Genes.txt")):
        path = out_dir / fname
        path.write_text("\n".join(ranked[key]) + "\n", encoding="utf-8")
        ctx.register_file("gene_list", str(path))

    ctx.success("Sensitivity genes extracted",
                f"{len(ranked['top60_sensitive'])} sensitive / {len(ranked['top60_resistant'])} resistant ({source})")
    return {
        **{k: ranked[k] for k in ("top60_sensitive", "top60_resistant", "top10_sensitive", "top10_resistant")},
        "table3": ranked["table3"],
        "source": source,
        "summary": f"Top {len(ranked['top60_sensitive'])} sensitive, top {len(ranked['top60_resistant'])} resistant genes",
    }

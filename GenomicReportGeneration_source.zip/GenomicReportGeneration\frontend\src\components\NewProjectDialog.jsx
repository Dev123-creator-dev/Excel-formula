import { useEffect, useState } from "react";
import { Box, Button, Dialog, DialogActions, DialogContent, Stack, Typography, alpha, useTheme } from "@mui/material";
import RocketLaunchRoundedIcon from "@mui/icons-material/RocketLaunchRounded";
import FolderRoundedIcon from "@mui/icons-material/FolderRounded";
import { PathField } from "./ui.jsx";
import { brand } from "../theme.js";
import { api } from "../api.js";
import { useAction } from "../context.jsx";

// [name, depth, branch glyph]
const TREE = [
  ["OncoPredictor", 0, "├─"], ["Clustering", 0, "├─"], ["DiffEx", 0, "├─"], ["GProfiler", 0, "├─"],
  ["Sensitivity", 1, "├─"], ["Resistance", 1, "└─"], ["Reports", 0, "├─"], ["Logs", 0, "└─"],
];

export default function NewProjectDialog({ open, onClose, onCreated, defaultRoot }) {
  const theme = useTheme();
  const act = useAction();
  const [folder, setFolder] = useState("");
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (open) { setFolder(defaultRoot || ""); setPreview(null); setError(""); } }, [open, defaultRoot]);

  // Live preview of the folder the project will actually use.
  useEffect(() => {
    if (!open || !folder.trim()) { setPreview(null); setError(""); return undefined; }
    const t = setTimeout(() => {
      api.previewProject(folder).then((p) => { setPreview(p); setError(""); })
        .catch((e) => { setPreview(null); setError(e.message); });
    }, 300);
    return () => clearTimeout(t);
  }, [folder, open]);

  const submit = async () => {
    setBusy(true);
    const p = await act(() => api.createProject(folder), preview?.exists ? "Project reopened" : "Project created — folder structure ready");
    setBusy(false);
    if (p) onCreated(p);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <Box sx={{ p: 3.5, pb: 0, position: "relative", overflow: "hidden" }}>
        <Box sx={{ position: "absolute", right: -60, top: -100, width: 280, height: 280, borderRadius: "50%",
          background: `radial-gradient(circle, ${alpha(brand.teal, 0.25)}, transparent 65%)` }} />
        <Typography variant="overline" sx={{ color: brand.teal }}>New analysis</Typography>
        <Typography variant="h5">Create project</Typography>
        <Typography color="text.secondary" variant="body2">
          Just choose where the project should live — everything else is set up automatically.
        </Typography>
      </Box>
      <DialogContent sx={{ p: 3.5 }}>
        <Stack direction={{ xs: "column", md: "row" }} spacing={3.5}>
          <Stack spacing={2} sx={{ flex: 1.1 }}>
            <PathField label="Project location" kind="folder" value={folder} onChange={setFolder} required
              helperText="Click the folder icon to browse, e.g. D:\ or K:\Projects" />
            <Box sx={{ p: 2, borderRadius: 3, bgcolor: alpha(brand.blue, 0.06), border: `1px solid ${alpha(brand.blue, 0.2)}` }}>
              <Typography variant="body2" sx={{ fontWeight: 650, mb: 0.75 }}>How the folder is chosen</Typography>
              <Typography variant="body2" color="text.secondary" component="div" sx={{ "& li": { mb: 0.4 } }}>
                <ul style={{ margin: 0, paddingLeft: 18 }}>
                  <li><b>Empty folder</b> → used as the project folder</li>
                  <li><b>Drive or folder with files</b> → a new <code>GenomicReport_&lt;date-time&gt;</code> folder is created inside it</li>
                  <li><b>Existing project folder</b> → the project is reopened and resumed</li>
                </ul>
              </Typography>
            </Box>
          </Stack>
          <Box sx={{ flex: 1, p: 2.5, borderRadius: 4, border: `1px solid ${theme.palette.divider}`,
            bgcolor: theme.custom.dark ? "rgba(2,6,23,.5)" : "rgba(15,23,42,.03)", minHeight: 300 }}>
            <Typography variant="overline" color="text.secondary">Project folder</Typography>
            {error && <Typography variant="body2" color="error" sx={{ mt: 1.5 }}>{error}</Typography>}
            {!error && !preview && <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5 }}>Choose a location to see the preview.</Typography>}
            {preview && (
              <Box sx={{ mt: 1.5, fontFamily: '"Cascadia Code", Consolas, monospace', fontSize: 13 }}>
                <Stack direction="row" spacing={1} alignItems="flex-start" sx={{ mb: 1 }}>
                  <FolderRoundedIcon sx={{ fontSize: 18, color: brand.amber, mt: "1px" }} />
                  <Box component="span" sx={{ fontWeight: 700, wordBreak: "break-all" }}>{preview.project_path}\</Box>
                </Stack>
                {TREE.map(([name, depth, glyph], i) => (
                  <Stack key={name} direction="row" spacing={1} alignItems="center" sx={{ pl: 1.5, py: 0.35, color: "text.secondary",
                    animation: "grg-rise .4s both", animationDelay: `${i * 40}ms` }}>
                    <Box component="span" sx={{ opacity: 0.45, whiteSpace: "pre" }}>{depth ? `│  ${glyph}` : glyph}</Box>
                    <FolderRoundedIcon sx={{ fontSize: 16, color: alpha(depth ? brand.violet : brand.teal, 0.85) }} />
                    <Box component="span">{name}</Box>
                  </Stack>
                ))}
                {preview.exists && (
                  <Typography variant="caption" sx={{ display: "block", mt: 1.5, color: brand.green, fontFamily: "inherit" }}>
                    Existing project — it will be reopened.
                  </Typography>
                )}
              </Box>
            )}
          </Box>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3.5, pb: 3 }}>
        <Button color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" startIcon={<RocketLaunchRoundedIcon />} disabled={!preview || busy} onClick={submit}>
          {preview?.exists ? "Open project" : "Create project"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The production bundle is emitted straight into the backend so FastAPI can
// serve it (and PyInstaller can bundle it) without a separate web server.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "../backend/app/static",
    emptyOutDir: true,
    chunkSizeWarningLimit: 1500,
  },
  server: {
    port: 5173,
    proxy: { "/api": "http://127.0.0.1:8765" },
  },
});

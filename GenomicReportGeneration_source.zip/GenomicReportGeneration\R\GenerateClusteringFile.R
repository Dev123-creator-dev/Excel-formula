# =====================================================================================
#  GenerateClusteringFile.R  --  DUMMY / DEMO IMPLEMENTATION
# -------------------------------------------------------------------------------------
#  Stand-in for K:/LabOperations/Oncopanel/QC support files/GenerateClusteringFile.R
#  until the real helper is available. It has the same interface:
#
#      GenerateClusteringFile(client_data_fn)
#
#  It reads the tab-delimited assay data file and writes its outputs next to it
#  (the project's Clustering folder):
#
#      <name>_Clustering_Data.csv        cell-line response matrix + cluster assignment
#      <name>_Ranked_SOC_Compounds.csv   reference (SOC) agents ranked by similarity
#      <name>_Clustering_Dendrogram.png  hierarchical clustering dendrogram
#
#  Similarity scores are SIMULATED (deterministic, seeded from the data) and are
#  NOT scientifically meaningful. Replace this file with the real helper.
# =====================================================================================

GenerateClusteringFile <- function(client_data_fn) {
  if (!file.exists(client_data_fn)) stop("Assay data file not found: ", client_data_fn)

  out_dir <- dirname(client_data_fn)
  base <- tools::file_path_sans_ext(basename(client_data_fn))
  sep <- if (grepl("\\.csv$", client_data_fn, ignore.case = TRUE)) "," else "\t"
  data <- utils::read.delim(client_data_fn, sep = sep, check.names = FALSE, stringsAsFactors = FALSE)
  if (nrow(data) < 3) stop("Assay data needs at least 3 rows, found ", nrow(data))

  # Identify the cell-line label and the numeric response columns.
  numeric_cols <- names(data)[vapply(data, is.numeric, logical(1))]
  numeric_cols <- setdiff(numeric_cols, c("Rank", "rank"))
  if (length(numeric_cols) == 0) stop("No numeric response columns found in ", basename(client_data_fn))
  label_col <- names(data)[!vapply(data, is.numeric, logical(1))][1]
  labels <- if (is.na(label_col)) paste0("Line_", seq_len(nrow(data))) else as.character(data[[label_col]])

  # Response vector: prefer a log-scale column, else log10 of the first numeric column.
  log_col <- grep("log", numeric_cols, ignore.case = TRUE, value = TRUE)[1]
  response <- if (!is.na(log_col)) data[[log_col]] else log10(pmax(data[[numeric_cols[1]]], 1e-9))
  response[!is.finite(response)] <- NA
  keep <- !is.na(response)
  response <- response[keep]
  labels <- labels[keep]

  z <- as.numeric(scale(response))
  hc <- stats::hclust(stats::dist(z), method = "average")
  k <- min(4, length(z) - 1)
  cluster <- stats::cutree(hc, k = k)

  clustering <- data.frame(
    CellLine = labels,
    Response = round(response, 5),
    ZScore = round(z, 4),
    Cluster = cluster,
    DendrogramOrder = match(seq_along(z), hc$order),
    check.names = FALSE
  )
  clustering <- clustering[order(clustering$DendrogramOrder), ]
  utils::write.csv(clustering, file.path(out_dir, paste0(base, "_Clustering_Data.csv")), row.names = FALSE)

  # Simulated similarity of the test agent to standard-of-care reference agents.
  soc <- c("Vemurafenib", "Dabrafenib", "Trametinib", "Cobimetinib", "Selumetinib", "Erlotinib",
           "Gefitinib", "Lapatinib", "Imatinib", "Sorafenib", "Sunitinib", "Paclitaxel",
           "Docetaxel", "Cisplatin", "Carboplatin", "Gemcitabine", "Doxorubicin", "Etoposide",
           "5-Fluorouracil", "Bortezomib")
  set.seed(sum(round(abs(response) * 1000)) %% .Machine$integer.max)
  similarity <- round(sort(stats::runif(length(soc), 0.05, 0.95), decreasing = TRUE), 3)
  ranked <- data.frame(
    Rank = seq_along(soc),
    Compound = sample(soc),
    PearsonSimilarity = similarity,
    Note = "DUMMY - simulated by placeholder GenerateClusteringFile.R",
    check.names = FALSE
  )
  utils::write.csv(ranked, file.path(out_dir, paste0(base, "_Ranked_SOC_Compounds.csv")), row.names = FALSE)

  grDevices::png(file.path(out_dir, paste0(base, "_Clustering_Dendrogram.png")), width = 1600, height = 900, res = 130)
  plot(hc, labels = labels, main = paste("Clustering dendrogram (DUMMY) -", base), xlab = "", sub = "", cex = 0.45)
  stats::rect.hclust(hc, k = k, border = 2:(k + 1))
  grDevices::dev.off()

  message("GenerateClusteringFile (dummy): ", nrow(clustering), " cell lines, ", k, " clusters -> ", out_dir)
  invisible(clustering)
}

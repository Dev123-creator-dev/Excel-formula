"""Shared helpers for workflow services: folders, errors, the step context."""
from __future__ import annotations

import re
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

PROJECT_FOLDERS = [
    "OncoPredictor",
    "Clustering",
    "DiffEx",
    "GProfiler",
    "GProfiler/Sensitivity",
    "GProfiler/Resistance",
    "Reports",
    "Logs",
]


class StepError(Exception):
    """A step failed in a way the user should see (message is shown verbatim)."""

    def __init__(self, message: str, hint: str = "") -> None:
        super().__init__(message)
        self.hint = hint


class NeedsInput(Exception):
    """A step cannot proceed until the user supplies an input."""

    def __init__(self, message: str, field_name: str) -> None:
        super().__init__(message)
        self.field_name = field_name


class Cancelled(Exception):
    pass


def safe_name(value: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", value.strip())
    cleaned = re.sub(r"\s+", "_", cleaned).strip("._")
    return cleaned[:60] or "Project"


MAX_PATH = 250  # Windows MAX_PATH (260) minus headroom for Office lock files


def output_path(folder: Path, template_name: str, prefix: str, short_label: str) -> Path:
    """Name an output after its template, keeping the path under MAX_PATH.

    '..._Client_Study_Report_Template_25Jan2023.docx' -> '..._<prefix>_Report_02Nov2026.docx',
    or '<prefix>_<short_label>_02Nov2026.docx' when that would be too long.
    """
    stamp = datetime.now().strftime("%d%b%Y")
    name = template_name.replace("_Template", "").replace("Client_Study", prefix)
    name, n = re.subn(r"_\d{1,2}[A-Za-z]{3}\d{4}(?=\.[^.]+$)", f"_{stamp}", name)
    if not n:
        stem, dot, ext = name.rpartition(".")
        name = f"{stem}_{stamp}{dot}{ext}"
    path = folder / name
    if len(str(path)) > MAX_PATH:
        path = folder / f"{prefix}_{short_label}_{stamp}{Path(template_name).suffix}"
    if len(str(path)) > MAX_PATH:
        raise StepError(
            f"Output path is too long for Windows ({len(str(path))} characters).",
            "Use a shorter root folder or study name.",
        )
    return path


def is_project_folder(path: Path) -> bool:
    return all((path / sub).is_dir() for sub in ("OncoPredictor", "Clustering", "Reports"))


def resolve_project_folder(selected: str) -> Path:
    """Turn the folder the user picked into the project folder.

    * an existing project folder          -> re-opened as-is
    * an empty folder                     -> used as the project folder
    * a drive root or a non-empty folder  -> a new GenomicReport_<timestamp> folder inside it
    """
    raw = selected.strip().strip('"')
    if re.fullmatch(r"[A-Za-z]:", raw):
        raw += "\\"  # "D:" means "current directory on D:" to Windows
    path = Path(raw)
    if not path.is_absolute():
        raise StepError("Select a full folder path, e.g. D:\\Projects")
    if not path.exists():
        raise StepError(f"Folder not found: {path}", "Check the drive is connected / mapped.")
    if not path.is_dir():
        raise StepError(f"Not a folder: {path}")
    if is_project_folder(path):
        return path
    is_root = path.parent == path
    if not is_root and not any(path.iterdir()):
        return path
    return path / f"GenomicReport_{datetime.now():%Y%m%d_%H%M%S}"


def create_project_folders(project_path: Path) -> list[str]:
    created = []
    for sub in PROJECT_FOLDERS:
        target = project_path / sub
        if not target.exists():
            target.mkdir(parents=True, exist_ok=True)
            created.append(str(target))
    return created


def write_activity_line(project_path: str, level: str, action: str, detail: str = "") -> None:
    """Append a human-readable line to <project>/Logs/activity_log.txt."""
    log_dir = Path(project_path) / "Logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{stamp}  [{level.upper():7}]  {action}"
        if detail:
            line += f"  |  {detail}"
        with open(log_dir / "activity_log.txt", "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass  # the SQLite audit trail still records the event


@dataclass
class StepContext:
    project: dict
    step_key: str
    settings: Any
    cancel_event: threading.Event
    log: Callable[[str, str, str], None]
    progress: Callable[[float, str], None]
    register_file: Callable[[str, str], None]
    previous: dict[str, dict] = field(default_factory=dict)

    @property
    def path(self) -> Path:
        return Path(self.project["project_path"])

    @property
    def inputs(self) -> dict:
        return self.project.get("inputs", {})

    @property
    def file_prefix(self) -> str:
        return safe_name(self.project["study_name"])

    def info(self, action: str, detail: str = "") -> None:
        self.log("info", action, detail)

    def warn(self, action: str, detail: str = "") -> None:
        self.log("warning", action, detail)

    def success(self, action: str, detail: str = "") -> None:
        self.log("success", action, detail)

    def check_cancel(self) -> None:
        if self.cancel_event.is_set():
            raise Cancelled()

    def step_data(self, key: str) -> dict:
        return (self.previous.get(key) or {}).get("data") or {}


MAX_INPUT_BYTES = 1024 * 1024 * 1024  # 1 GB - rejects runaway / corrupt inputs


def validate_file(path: str | None, label: str, suffixes: tuple[str, ...]) -> Path:
    if not path:
        raise StepError(f"{label} path is empty.")
    p = Path(path.strip().strip('"'))
    if not p.is_absolute():
        raise StepError(f"{label} must be a full path: {p}")
    if not p.exists():
        raise StepError(f"{label} not found: {p}", "Check the path or that the network drive is mapped.")
    if not p.is_file():
        raise StepError(f"{label} is not a file: {p}")
    if p.suffix.lower() not in suffixes:
        raise StepError(f"{label} must be one of {', '.join(suffixes)} (got {p.suffix or 'no extension'}).")
    size = p.stat().st_size
    if size == 0:
        raise StepError(f"{label} is empty: {p}")
    if size > MAX_INPUT_BYTES:
        raise StepError(f"{label} is larger than 1 GB: {p}")
    return p  # not resolve(): that rewrites mapped drives (K:\) to UNC paths


FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def is_formula_like(value) -> bool:
    """Text that Excel would execute as a formula (CSV/Excel injection)."""
    if not isinstance(value, str) or not value.startswith(FORMULA_PREFIXES):
        return False
    try:
        float(value)  # "-1.5" is a number, not a formula
        return False
    except ValueError:
        return True


def csv_safe(value):
    return "'" + value if is_formula_like(value) else value

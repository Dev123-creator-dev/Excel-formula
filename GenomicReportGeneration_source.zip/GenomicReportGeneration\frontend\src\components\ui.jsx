import { useState } from "react";
import {
  Box, Button, Chip, IconButton, InputAdornment, Paper, Stack, TextField, Tooltip, Typography, alpha, useTheme,
} from "@mui/material";
import CheckRoundedIcon from "@mui/icons-material/CheckRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";
import PauseRoundedIcon from "@mui/icons-material/PauseRounded";
import RedoRoundedIcon from "@mui/icons-material/RedoRounded";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";
import { brand, statusColor } from "../theme.js";
import { api } from "../api.js";

export function GlassCard({ children, sx, glow, ...rest }) {
  const theme = useTheme();
  return (
    <Paper
      elevation={0}
      {...rest}
      sx={{
        borderRadius: 5, p: { xs: 2, md: 2.75 }, position: "relative", overflow: "hidden",
        boxShadow: theme.custom.dark
          ? "0 1px 0 0 rgba(255,255,255,.04) inset, 0 24px 48px -24px rgba(0,0,0,.6)"
          : "0 1px 0 0 rgba(255,255,255,.8) inset, 0 24px 48px -28px rgba(15,23,42,.25)",
        ...(glow && {
          "&::after": {
            content: '""', position: "absolute", inset: 0, borderRadius: "inherit", padding: "1px",
            background: `linear-gradient(135deg, ${alpha(brand.teal, 0.55)}, transparent 40%, ${alpha(brand.violet, 0.55)})`,
            WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
            WebkitMaskComposite: "xor", maskComposite: "exclude", pointerEvents: "none",
          },
        }),
        ...sx,
      }}
    >
      {children}
    </Paper>
  );
}

export function SectionTitle({ icon: Icon, title, subtitle, action }) {
  return (
    <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2 }}>
      {Icon && (
        <Box sx={{
          width: 34, height: 34, borderRadius: 2.5, display: "grid", placeItems: "center",
          background: brand.gradientSoft, color: brand.teal,
        }}>
          <Icon sx={{ fontSize: 19 }} />
        </Box>
      )}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography variant="subtitle1" sx={{ lineHeight: 1.25 }}>{title}</Typography>
        {subtitle && <Typography variant="caption" color="text.secondary">{subtitle}</Typography>}
      </Box>
      {action}
    </Stack>
  );
}

const STATUS_LABEL = {
  completed: "Completed", skipped: "Skipped", running: "Running", failed: "Failed",
  waiting_input: "Needs input", interrupted: "Interrupted", pending: "Waiting",
};

export function StatusChip({ status, size = "small" }) {
  const c = statusColor[status] || statusColor.pending;
  return (
    <Chip
      size={size}
      label={STATUS_LABEL[status] || status}
      icon={status === "running" ? (
        <Box sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: c, ml: "8px !important",
          animation: "grg-blink 1.2s ease-in-out infinite" }} />
      ) : undefined}
      sx={{ color: c, bgcolor: alpha(c, 0.12), border: `1px solid ${alpha(c, 0.28)}`, height: 24, fontSize: 12 }}
    />
  );
}

/** Circular node for the workflow stepper; animated ring while running. */
export function StepNode({ status, index }) {
  const c = statusColor[status] || statusColor.pending;
  const icon = {
    completed: <CheckRoundedIcon sx={{ fontSize: 20 }} />,
    failed: <CloseRoundedIcon sx={{ fontSize: 20 }} />,
    waiting_input: <PriorityHighRoundedIcon sx={{ fontSize: 20 }} />,
    interrupted: <PauseRoundedIcon sx={{ fontSize: 20 }} />,
    skipped: <RedoRoundedIcon sx={{ fontSize: 18 }} />,
  }[status];
  const running = status === "running";
  return (
    <Box sx={{ position: "relative", width: 40, height: 40, flexShrink: 0 }}>
      {running && (
        <Box sx={{
          position: "absolute", inset: -4, borderRadius: "50%",
          background: `conic-gradient(from 0deg, ${brand.teal}, ${brand.violet}, transparent 70%)`,
          animation: "grg-spin 1.1s linear infinite",
          WebkitMask: "radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 3px))",
          mask: "radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 3px))",
        }} />
      )}
      <Box sx={{
        width: 40, height: 40, borderRadius: "50%", display: "grid", placeItems: "center",
        fontWeight: 800, fontSize: 14,
        color: status === "completed" ? "#04131A" : c,
        background: status === "completed" ? `linear-gradient(135deg, ${brand.green}, ${brand.teal})` : alpha(c, 0.12),
        border: `1.5px solid ${alpha(c, status === "pending" ? 0.35 : 0.6)}`,
        animation: running ? "grg-pulse 2s infinite" : undefined,
        transition: "all .3s",
      }}>
        {icon || index}
      </Box>
    </Box>
  );
}

export function ProgressRing({ value, size = 132, stroke = 11, label, sublabel }) {
  const theme = useTheme();
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  return (
    <Box sx={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <defs>
          <linearGradient id="grg-ring" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={brand.teal} />
            <stop offset="1" stopColor={brand.violet} />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke}
          stroke={theme.custom.dark ? "rgba(148,163,184,.12)" : "rgba(15,23,42,.08)"} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} strokeLinecap="round"
          stroke="url(#grg-ring)" strokeDasharray={circ}
          strokeDashoffset={circ * (1 - Math.min(value, 100) / 100)}
          style={{ transition: "stroke-dashoffset .8s cubic-bezier(.2,.8,.2,1)", filter: "drop-shadow(0 0 6px rgba(124,92,255,.5))" }} />
      </svg>
      <Box sx={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", textAlign: "center" }}>
        <Box>
          <Typography sx={{ fontSize: size * 0.22, fontWeight: 800, lineHeight: 1, letterSpacing: "-0.03em" }}>
            {label ?? `${Math.round(value)}%`}
          </Typography>
          {sublabel && <Typography variant="caption" color="text.secondary">{sublabel}</Typography>}
        </Box>
      </Box>
    </Box>
  );
}

export function ShimmerBar({ value, active }) {
  const theme = useTheme();
  return (
    <Box sx={{ height: 8, borderRadius: 99, overflow: "hidden",
      bgcolor: theme.custom.dark ? "rgba(148,163,184,.12)" : "rgba(15,23,42,.07)" }}>
      <Box sx={{
        height: "100%", width: `${Math.max(2, Math.min(value, 100))}%`, borderRadius: 99,
        transition: "width .7s cubic-bezier(.2,.8,.2,1)",
        background: active
          ? `linear-gradient(90deg, ${brand.teal}, ${brand.blue}, ${brand.violet}, ${brand.blue}, ${brand.teal})`
          : brand.gradient,
        backgroundSize: active ? "200% 100%" : undefined,
        animation: active ? "grg-shimmer 2.2s linear infinite" : undefined,
        boxShadow: `0 0 14px ${alpha(brand.violet, 0.45)}`,
      }} />
    </Box>
  );
}

/** Path input with a native Windows "Browse" dialog (served by the backend). */
export function PathField({ label, value, onChange, onCommit, kind = "file", extensions = [], helperText, readOnly, required }) {
  const [busy, setBusy] = useState(false);
  const browse = async () => {
    setBusy(true);
    try {
      const { path } = await api.pick({ kind, title: label, extensions, initial: value || "" });
      if (path) { onChange?.(path); onCommit?.(path); }
    } finally { setBusy(false); }
  };
  return (
    <TextField
      label={label}
      value={value || ""}
      required={required}
      onChange={(e) => onChange?.(e.target.value)}
      onBlur={(e) => onCommit?.(e.target.value)}
      helperText={helperText}
      slotProps={{
        input: {
          readOnly,
          sx: { fontFamily: '"Cascadia Code", Consolas, monospace', fontSize: 13 },
          endAdornment: !readOnly && (
            <InputAdornment position="end">
              <Tooltip title={kind === "folder" ? "Browse for folder" : "Browse for file"}>
                <span>
                  <IconButton size="small" onClick={browse} disabled={busy} edge="end">
                    <FolderOpenRoundedIcon fontSize="small" />
                  </IconButton>
                </span>
              </Tooltip>
            </InputAdornment>
          ),
        },
      }}
    />
  );
}

export function EmptyState({ icon: Icon, title, body, action }) {
  return (
    <Stack alignItems="center" spacing={1.5} sx={{ py: 8, textAlign: "center" }}>
      <Box sx={{ width: 76, height: 76, borderRadius: 5, display: "grid", placeItems: "center",
        background: brand.gradientSoft, color: brand.teal }}>
        <Icon sx={{ fontSize: 38 }} />
      </Box>
      <Typography variant="h6">{title}</Typography>
      <Typography color="text.secondary" sx={{ maxWidth: 440 }}>{body}</Typography>
      {action}
    </Stack>
  );
}

export function GradientButton(props) {
  return <Button variant="contained" color="primary" {...props} />;
}

import { useEffect, useState } from "react";
import {
  Box, Button, FormControlLabel, MenuItem, Stack, Switch, TextField, Typography, alpha,
} from "@mui/material";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";
import MonitorHeartRoundedIcon from "@mui/icons-material/MonitorHeartRounded";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import ErrorRoundedIcon from "@mui/icons-material/ErrorRounded";
import SaveRoundedIcon from "@mui/icons-material/SaveRounded";
import { GlassCard, PathField, SectionTitle } from "../components/ui.jsx";
import { brand } from "../theme.js";
import { api } from "../api.js";
import { useAction } from "../context.jsx";

const CHECK_LABEL = {
  root_path: "Default project location", rscript_exe: "R (for Step 2)", browser: "Browser (for g:Profiler)",
};

function Group({ title, children }) {
  return (
    <Box>
      <Typography variant="overline" color="text.secondary" sx={{ display: "block", mb: 1.5 }}>{title}</Typography>
      <Stack spacing={2}>{children}</Stack>
    </Box>
  );
}

export default function SettingsPage({ health, onSaved }) {
  const act = useAction();
  const [s, setS] = useState(null);
  useEffect(() => { api.settings().then(setS); }, []);
  if (!s) return null;
  const set = (k) => (v) => setS({ ...s, [k]: v?.target ? (v.target.type === "checkbox" ? v.target.checked : v.target.value) : v });
  const save = async () => { const r = await act(() => api.saveSettings(s), "Settings saved"); if (r) { setS(r); onSaved(); } };

  return (
    <Box sx={{ display: "grid", gap: 2.5, gridTemplateColumns: { xs: "1fr", lg: "1.6fr 1fr" }, alignItems: "start" }}>
      <GlassCard>
        <SectionTitle icon={TuneRoundedIcon} title="Configuration" subtitle="Stored locally in %LOCALAPPDATA%\GenomicReportGeneration"
          action={<Button variant="contained" startIcon={<SaveRoundedIcon />} onClick={save}>Save</Button>} />
        <Stack spacing={3.5}>
          <Group title="Folders">
            <PathField label="Default project location" kind="folder" value={s.root_path} onChange={set("root_path")} />
            <FormControlLabel control={<Switch checked={s.move_files} onChange={set("move_files")} />}
              label="Move the selected OncoPredictor files into the project (off = copy)" />
          </Group>

          <Group title="Clustering (R) — last used files are pre-filled in new projects">
            <PathField label="Clustering R script" value={s.r_script_path} onChange={set("r_script_path")} extensions={[".r"]} />
            <PathField label="GenerateClusteringFile.R helper" value={s.r_helper_path} onChange={set("r_helper_path")} extensions={[".r"]} />
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
              <PathField label="Rscript.exe (auto-detected)" value={s.rscript_exe} onChange={set("rscript_exe")} extensions={[".exe"]} />
              <TextField label="Timeout (minutes)" type="number" value={s.r_timeout_minutes} onChange={set("r_timeout_minutes")} sx={{ maxWidth: 180 }} />
            </Stack>
            <FormControlLabel control={<Switch checked={s.r_auto_install_packages} onChange={set("r_auto_install_packages")} />}
              label="Install missing R packages automatically (e.g. dplyr)" />
          </Group>

          <Group title="g:Profiler">
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
              <TextField select label="Engine" value={s.gprofiler_engine} onChange={set("gprofiler_engine")} sx={{ maxWidth: 260 }}>
                <MenuItem value="selenium">Selenium (browser automation)</MenuItem>
                <MenuItem value="api">g:Profiler REST API</MenuItem>
              </TextField>
              <TextField label="Timeout (seconds)" type="number" value={s.gprofiler_timeout_seconds} onChange={set("gprofiler_timeout_seconds")} sx={{ maxWidth: 180 }} />
            </Stack>
            <FormControlLabel control={<Switch checked={s.gprofiler_headless} onChange={set("gprofiler_headless")} />} label="Run the browser hidden (headless)" />
            <FormControlLabel control={<Switch checked={s.gprofiler_fallback_to_api} onChange={set("gprofiler_fallback_to_api")} />}
              label="Fall back to the official API if browser automation fails" />
          </Group>

          <Group title="Default templates (pre-filled for new projects)">
            <PathField label="Excel template" value={s.default_excel_template} onChange={set("default_excel_template")} extensions={[".xlsx", ".xlsm"]} />
            <PathField label="Word template" value={s.default_word_template} onChange={set("default_word_template")} extensions={[".docx"]} />
          </Group>

          <Group title="Links">
            <TextField label="OncoPredictor URL" value={s.oncopredictor_url} onChange={set("oncopredictor_url")} />
            <TextField label="g:GOSt URL" value={s.gprofiler_url} onChange={set("gprofiler_url")} />
          </Group>
        </Stack>
      </GlassCard>

      <GlassCard sx={{ position: { lg: "sticky" }, top: 96 }}>
        <SectionTitle icon={MonitorHeartRoundedIcon} title="System health" subtitle={health ? `${health.machine} · Python ${health.python}` : ""} />
        <Stack spacing={1.25}>
          {health && Object.entries(health.checks).map(([k, c]) => (
            <Stack key={k} direction="row" spacing={1.5} alignItems="center" sx={{
              p: 1.5, borderRadius: 3, border: "1px solid", borderColor: alpha(c.ok ? brand.green : brand.amber, 0.25),
              bgcolor: alpha(c.ok ? brand.green : brand.amber, 0.05),
            }}>
              {c.ok ? <CheckCircleRoundedIcon sx={{ color: brand.green }} /> : <ErrorRoundedIcon sx={{ color: brand.amber }} />}
              <Box sx={{ minWidth: 0 }}>
                <Typography variant="body2" sx={{ fontWeight: 650 }}>{CHECK_LABEL[k] || k}</Typography>
                <Typography variant="caption" color="text.secondary" component="div" title={c.detail}
                  sx={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.detail}</Typography>
              </Box>
            </Stack>
          ))}
          {health && (
            <Typography variant="caption" color="text.secondary" sx={{ pt: 1 }}>
              Audit database & settings: {health.data_dir}
            </Typography>
          )}
        </Stack>
      </GlassCard>
    </Box>
  );
}

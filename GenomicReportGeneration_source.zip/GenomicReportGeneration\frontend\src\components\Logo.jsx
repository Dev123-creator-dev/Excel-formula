import { Box } from "@mui/material";

export default function Logo({ size = 40 }) {
  return (
    <Box
      sx={{
        width: size, height: size, borderRadius: "30%", flexShrink: 0,
        display: "grid", placeItems: "center",
        background: "linear-gradient(145deg, #0E1530, #0A0F22)",
        boxShadow: "0 10px 30px -10px rgba(124,92,255,.8), inset 0 0 0 1px rgba(255,255,255,.08)",
      }}
    >
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 40 40" fill="none">
        <defs>
          <linearGradient id="grg-logo" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#19E3C5" />
            <stop offset="1" stopColor="#7C5CFF" />
          </linearGradient>
        </defs>
        <path d="M12 3c0 10 16 10 16 17S12 27 12 37" stroke="url(#grg-logo)" strokeWidth="3.4" strokeLinecap="round" />
        <path d="M28 3c0 10-16 10-16 17s16 7 16 17" stroke="url(#grg-logo)" strokeWidth="3.4" strokeLinecap="round" opacity=".5" />
        <path d="M14.5 9h11M14.5 31h11M17 20h6" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" opacity=".9" />
      </svg>
    </Box>
  );
}

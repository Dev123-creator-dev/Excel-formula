"""Entry point for GenomicReportGeneration.exe.

Starts the local API/UI server on 127.0.0.1 and opens it as an app window in
Chrome (or Microsoft Edge, which every Windows 10/11 machine has). A second
launch just re-opens the window of the already running instance.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.config import app_data_dir, settings_store  # noqa: E402

BROWSERS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]
IDLE_SHUTDOWN_SECONDS = 300


def already_running(url: str) -> bool:
    try:
        with urllib.request.urlopen(f"{url}/api/ping", timeout=1.5) as resp:
            return json.load(resp).get("app") == "Genomic Report Generation"
    except Exception:
        return False


def port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def current_token() -> str:
    try:
        return (app_data_dir() / "session.token").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def open_ui(url: str) -> None:
    # The token travels in the URL fragment: never sent over HTTP, never logged.
    target = f"{url}/#token={current_token()}"
    browser = next((p for p in BROWSERS if Path(p).exists()), None)
    if browser:
        profile = app_data_dir() / "browser-profile"
        subprocess.Popen([browser, f"--app={target}", f"--user-data-dir={profile}",
                          "--window-size=1500,950", "--no-first-run", "--no-default-browser-check"])
    else:
        webbrowser.open(target)


def wait_until_up(url: str, timeout: float = 30) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if already_running(url):
            return True
        time.sleep(0.3)
    return False


def idle_watchdog() -> None:
    """Exit once the UI has been closed for a while and nothing is running.

    Every open window sends a heartbeat at least every 20 s (Chrome throttles
    hidden tabs to ~1/min), so 5 minutes of silence means every window is closed.
    """
    from app import main as server
    from app.workflow import engine

    while True:
        time.sleep(15)
        idle = time.time() - server.last_request_at
        busy = any(engine.is_running(pid) for pid in list(engine._threads))
        if idle > IDLE_SHUTDOWN_SECONDS and not busy:
            os._exit(0)


def redirect_output() -> None:
    """A windowed (no-console) exe has no stdout/stderr; send them to a log file."""
    if sys.stdout is None or sys.stderr is None:
        log = open(app_data_dir() / "server.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log


def message_box(text: str) -> None:
    import ctypes
    ctypes.windll.user32.MessageBoxW(None, text, "Genomic Report Generation", 0x10)


def main() -> None:
    redirect_output()
    port = settings_store.get().port
    url = f"http://127.0.0.1:{port}"
    if already_running(url):
        open_ui(url)
        return
    if not port_free(port):
        message_box(f"Port {port} is in use by another program.\n\nChange \"port\" in:\n{app_data_dir() / 'settings.json'}")
        sys.exit(1)

    import uvicorn
    from app.main import app  # generates this session's token

    if "--no-browser" not in sys.argv:
        threading.Thread(target=lambda: wait_until_up(url) and open_ui(url), daemon=True).start()
    if "--keep-alive" not in sys.argv:
        threading.Thread(target=idle_watchdog, daemon=True).start()
    print(f"Genomic Report Generation running at {url}")
    try:
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning", log_config=None,
                    server_header=False, date_header=False)
    except Exception as exc:  # noqa: BLE001
        message_box(f"The application could not start:\n\n{exc}")
        raise


if __name__ == "__main__":
    main()

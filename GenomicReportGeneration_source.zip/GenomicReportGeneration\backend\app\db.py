"""SQLite persistence: projects, step state (for resume), files and audit trail."""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from typing import Any

from .config import app_data_dir

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    study_name    TEXT NOT NULL,
    compound_name TEXT NOT NULL,
    client_name   TEXT NOT NULL,
    project_code  TEXT NOT NULL,
    user_email    TEXT NOT NULL,
    root_path     TEXT NOT NULL,
    project_path  TEXT NOT NULL UNIQUE,
    inputs_json   TEXT NOT NULL DEFAULT '{}',
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS step_state (
    project_id   INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    step_key     TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'pending',
    message      TEXT NOT NULL DEFAULT '',
    progress     REAL NOT NULL DEFAULT 0,
    started_at   TEXT,
    finished_at  TEXT,
    duration_s   REAL,
    attempts     INTEGER NOT NULL DEFAULT 0,
    data_json    TEXT NOT NULL DEFAULT '{}',
    error        TEXT,
    PRIMARY KEY (project_id, step_key)
);

CREATE TABLE IF NOT EXISTS files (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    step_key    TEXT NOT NULL,
    kind        TEXT NOT NULL,
    path        TEXT NOT NULL,
    size_bytes  INTEGER,
    created_at  TEXT NOT NULL,
    UNIQUE (project_id, path)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    ts          TEXT NOT NULL,
    level       TEXT NOT NULL,
    step_key    TEXT,
    action      TEXT NOT NULL,
    detail      TEXT,
    actor       TEXT NOT NULL DEFAULT 'system'
);
CREATE INDEX IF NOT EXISTS ix_audit_project ON audit_log(project_id, id);
"""


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


class Database:
    def __init__(self) -> None:
        self.path = app_data_dir() / "audit.db"
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return cur

    def query(self, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def one(self, sql: str, params: tuple = ()) -> dict[str, Any] | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    # --- projects ---------------------------------------------------------
    def create_project(self, data: dict) -> int:
        ts = now_iso()
        cur = self.execute(
            """INSERT INTO projects (name, study_name, compound_name, client_name, project_code,
                   user_email, root_path, project_path, inputs_json, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                data["name"], data["study_name"], data["compound_name"], data["client_name"],
                data["project_code"], data["user_email"], data["root_path"], data["project_path"],
                json.dumps(data.get("inputs", {})), ts, ts,
            ),
        )
        return int(cur.lastrowid)

    def get_project(self, project_id: int) -> dict | None:
        row = self.one("SELECT * FROM projects WHERE id=?", (project_id,))
        if row:
            row["inputs"] = json.loads(row.pop("inputs_json") or "{}")
        return row

    def find_project_by_path(self, path: str) -> dict | None:
        row = self.one("SELECT id FROM projects WHERE lower(project_path)=lower(?)", (path,))
        return self.get_project(row["id"]) if row else None

    def list_projects(self) -> list[dict]:
        rows = self.query("SELECT * FROM projects ORDER BY updated_at DESC")
        for row in rows:
            row["inputs"] = json.loads(row.pop("inputs_json") or "{}")
        return rows

    def update_inputs(self, project_id: int, values: dict) -> dict:
        project = self.get_project(project_id)
        inputs = {**(project or {}).get("inputs", {}), **values}
        self.execute(
            "UPDATE projects SET inputs_json=?, updated_at=? WHERE id=?",
            (json.dumps(inputs), now_iso(), project_id),
        )
        return inputs

    def delete_project(self, project_id: int) -> None:
        self.execute("DELETE FROM projects WHERE id=?", (project_id,))

    def touch_project(self, project_id: int) -> None:
        self.execute("UPDATE projects SET updated_at=? WHERE id=?", (now_iso(), project_id))

    # --- step state -------------------------------------------------------
    def get_steps(self, project_id: int) -> dict[str, dict]:
        rows = self.query("SELECT * FROM step_state WHERE project_id=?", (project_id,))
        out = {}
        for row in rows:
            row["data"] = json.loads(row.pop("data_json") or "{}")
            out[row["step_key"]] = row
        return out

    def upsert_step(self, project_id: int, step_key: str, **fields: Any) -> None:
        if "data" in fields:
            fields["data_json"] = json.dumps(fields.pop("data"), default=str)
        existing = self.one(
            "SELECT 1 FROM step_state WHERE project_id=? AND step_key=?", (project_id, step_key)
        )
        if not existing:
            self.execute(
                "INSERT INTO step_state (project_id, step_key) VALUES (?, ?)", (project_id, step_key)
            )
        if fields:
            cols = ", ".join(f"{k}=?" for k in fields)
            self.execute(
                f"UPDATE step_state SET {cols} WHERE project_id=? AND step_key=?",
                (*fields.values(), project_id, step_key),
            )

    def mark_interrupted(self) -> None:
        """Steps left 'running' by a crash/close become resumable."""
        self.execute(
            "UPDATE step_state SET status='interrupted', message='Interrupted - ready to resume' "
            "WHERE status='running'"
        )

    # --- files ------------------------------------------------------------
    def add_file(self, project_id: int, step_key: str, kind: str, path: str, size: int | None) -> None:
        self.execute(
            """INSERT INTO files (project_id, step_key, kind, path, size_bytes, created_at)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(project_id, path) DO UPDATE SET
                   kind=excluded.kind, step_key=excluded.step_key,
                   size_bytes=excluded.size_bytes, created_at=excluded.created_at""",
            (project_id, step_key, kind, path, size, now_iso()),
        )

    def list_files(self, project_id: int) -> list[dict]:
        return self.query("SELECT * FROM files WHERE project_id=? ORDER BY id", (project_id,))

    def clear_files(self, project_id: int, step_key: str) -> None:
        self.execute("DELETE FROM files WHERE project_id=? AND step_key=?", (project_id, step_key))

    # --- audit ------------------------------------------------------------
    def audit(self, project_id: int | None, level: str, action: str, detail: str = "",
              step_key: str | None = None, actor: str = "system") -> dict:
        ts = now_iso()
        cur = self.execute(
            "INSERT INTO audit_log (project_id, ts, level, step_key, action, detail, actor) "
            "VALUES (?,?,?,?,?,?,?)",
            (project_id, ts, level, step_key, action, detail, actor),
        )
        return {"id": cur.lastrowid, "ts": ts, "level": level, "step_key": step_key,
                "action": action, "detail": detail, "actor": actor}

    def list_audit(self, project_id: int | None, after_id: int = 0, limit: int = 500) -> list[dict]:
        if project_id is None:
            return self.query(
                "SELECT * FROM audit_log WHERE id>? ORDER BY id DESC LIMIT ?", (after_id, limit)
            )
        return self.query(
            "SELECT * FROM audit_log WHERE project_id=? AND id>? ORDER BY id DESC LIMIT ?",
            (project_id, after_id, limit),
        )


db = Database()

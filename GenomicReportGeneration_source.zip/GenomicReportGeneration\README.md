# Genomic Report Generation

A local Windows application that turns the manual OncoPanel genomics reporting workflow into a guided, mostly one-click pipeline.

**To use it, share and double-click one file:** `dist\GenomicReportGeneration.exe` (≈40 MB). Nothing needs to be installed.
The app opens in Google Chrome, or in Microsoft Edge, which every Windows 10/11 PC already has.

| Needs | Why | If missing |
|---|---|---|
| R (free, [cran.r-project.org](https://cran.r-project.org/bin/windows/base/)) | Step 2 runs your R script | Step 2 shows a clear message; you can **Skip** it. R packages such as `dplyr` are installed automatically. |
| Internet | Step 5 queries g:Profiler | Step 5 fails with a message; everything else works offline |

The first start takes about 10 s while the exe unpacks itself. Windows SmartScreen may warn about an unknown publisher the first time; code-signing the exe removes that warning.

---

## Step-by-step: how to use it

1. **Create a project.** Click **New project** and choose a location (e.g. `D:\`), then click **Create project**.
   - An **empty folder** is used as the project folder.
   - A **drive, or a folder that already has files**, gets a new `GenomicReport_<date-time>` folder inside it.
   - An **existing project folder** is re-opened and resumed.

   The sub-folders are created for you:
   ```
   <project>\OncoPredictor  Clustering  DiffEx  GProfiler\Sensitivity  GProfiler\Resistance  Reports  Logs
   ```
2. **Step 1: OncoPredictor files.**
   1. Run OncoPredictor (the **Launch OncoPredictor** button) and download the reports.
   2. Select the **DiffEx** report and the **Mutation** report.
   3. Click **Import files**. Both are validated (headers and sheet names, so swapped files are caught), then **moved** into `OncoPredictor\`.
3. **Step 2: clustering.**
   1. Select the **clustering R script**, the **GenerateClusteringFile.R** helper, and the **assay data (.tab)** file.
   2. Click **Run R script**. The app writes a copy of your script with:
      - `working_directory` and `client_data_fn` pointing at the project,
      - the fixed `source("K:/LabOperations/.../GenerateClusteringFile.R")` replaced by the helper you selected,
      - a few lines that install any missing R packages.
   3. R runs, and its outputs are saved in `Clustering\`. The console output goes to `Logs\clustering_R_console.log`.
4. **Click Resume workflow.** The rest runs by itself, pausing only once to ask for each template:
   - **Step 3:** select the Excel template. DiffEx `A:P` goes into *Table 3 for DiffEx*, and the formulas are generated.
   - **Step 4:** the top-60 sensitivity (AE) and resistance (AF) genes are extracted.
   - **Step 5:** g:Profiler runs for both gene lists in parallel and saves the CSVs.
   - **Step 6:** select the Word template. The app fills Table 3, the top-10 gene summaries, and the report details.
   - **Step 7:** everything is zipped with a SHA-256 manifest into `Reports\`.
5. **Get your files.** Everything appears under **Deliverables**; click to open a file or show it in its folder.
   - If a step fails, read the red message, fix the problem, then click **Retry**. Finished steps are never repeated.

Your R files and templates are remembered and pre-filled for the next project. The same guide is built into the app (**User Guide** in the sidebar).

### Report details (Step 6, all optional)

| Field | Placeholder it fills | If left blank |
|---|---|---|
| Compound | `CLIENTTESTAGENT` | Guessed from the DiffEx file name (e.g. *Vemurafenib*) |
| Analysis parameter | `ANALYSISPARAMETER` | Read from the Mutation report (e.g. *IC50*) |
| Client | `CLIENTNAME` | The placeholder is left in the report for manual editing |
| Order ID | `STUDYNUMBER`, `US034-000xxxx` | The placeholder is left in the report for manual editing |

The date placeholder (`MONTH DAY, YEAR`) is always set to today.

### The dummy `GenerateClusteringFile.R`

`R\GenerateClusteringFile.R` is a **placeholder** with the same interface as the real helper: `GenerateClusteringFile(client_data_fn)`. Select the real file instead once it's available. The dummy writes three files next to the data:
- `<name>_Clustering_Data.csv`: z-scored responses and hierarchical clusters,
- `<name>_Ranked_SOC_Compounds.csv`: **simulated** similarity to standard-of-care agents, marked DUMMY,
- `<name>_Clustering_Dendrogram.png`.

`samples\Vemurafenib_13FEB23_assay_data.tab` is a sample assay file for testing. It was built from the Mutation report's *OncoPanel Results* sheet.

---

## Security

The app is designed to be safe on a shared corporate PC:

| Threat | Protection |
|---|---|
| Other computers reaching the app | The server listens on `127.0.0.1` only. It is never exposed to the network. |
| A malicious website in the same browser calling the local API (CSRF) | A random **per-launch session token** is required on every API call. The launcher hands it to the window in the URL fragment, which is never sent over the network or logged, and it is sent back in a custom header that other sites cannot add. |
| DNS rebinding | Requests whose `Host` is not `127.0.0.1` / `localhost` are rejected. Cross-origin `Origin` headers are rejected. |
| Script injection / clickjacking | Strict Content-Security-Policy (no inline or remote scripts), `X-Frame-Options: DENY`, `nosniff`, `no-referrer`, COOP/CORP |
| Opening or running arbitrary files | "Open" and "Show in folder" only work inside project folders. Executables and scripts (`.exe .bat .ps1 .vbs .js .lnk .msi .r` …) are never opened. |
| Path traversal | UI files are served only from the bundled folder |
| Excel / CSV formula injection | Input cells that start with `= + - @` are stored as text, never as formulas. Exported CSV values are escaped. |
| Malicious XML in .xlsx / .docx | Files are parsed with `defusedxml` / python-docx with entity resolution disabled |
| Oversized or bogus inputs | Full paths only, extension checks, a 1 GB size cap, and content checks (headers, sheets) before anything is processed |
| Command injection | Programs are started with argument lists (never through a shell). Values written into the R script are checked for unsafe characters, and R package names are validated. |
| Information disclosure | No API docs or OpenAPI schema, no `Server` header, and the unauthenticated endpoint (`/api/ping`) returns only the app name |
| Configuration tampering | Settings are validated: https-only URLs, allowed values, numeric ranges |
| Audit | Every action is recorded with the Windows user name, in SQLite (`%LOCALAPPDATA%\GenomicReportGeneration\audit.db`) and in `<project>\Logs\activity_log.txt` |

By design, the app runs the R script **you select**. Only select scripts you trust.

---

## Architecture

```
GenomicReportGeneration.exe  (PyInstaller one-file, windowed)
└─ launcher.py  single instance · session token · opens Chrome/Edge --app · idle shutdown (5 min after the window closes)
   └─ FastAPI on 127.0.0.1:8765  (app/main.py, app/security.py)
      ├─ React + MUI UI (built by Vite into app/static)
      ├─ WorkflowEngine (app/workflow.py): gating, background thread per project, cancel, resume
      ├─ services/  oncopredictor · clustering · diffex · gprofiler · report · packaging
      └─ SQLite (WAL): projects, step_state (resume), files, audit_log
```

**API** (all routes except `/api/ping` need the session token):
- **Projects:**
  - `POST /api/projects/preview`, `POST /api/projects`: create a project from a folder.
  - `GET /api/projects[/{id}]`: list projects, or one project.
  - `PATCH /api/projects/{id}/inputs`: set the selected files and report details.
- **Workflow:**
  - `POST /api/projects/{id}/run`: run the remaining steps (resume).
  - `POST /api/projects/{id}/cancel`: stop.
  - `POST /api/projects/{id}/steps/{key}/{run|skip|reset}`: control one step.
- **Logs and settings:** `GET /api/projects/{id}/logs`, `GET /api/logs`, `GET|PUT /api/settings`, `GET /api/health`.
- **System:** `POST /api/system/{pick|open|reveal|oncopredictor}`.

## Building from source

Requires Python 3.11+ and Node 18+:

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1   # -> dist\GenomicReportGeneration.exe
```

`Start-GenomicReport.bat` runs the app from source, without building the exe.

## Verified

The full pipeline was tested on the Vemurafenib sample files, end to end in about 57 s:
- the real clustering R script with the dummy helper (`dplyr` was installed automatically),
- 18,824 DiffEx rows,
- live g:Profiler (47 sensitivity / 11 resistance terms),
- the Word report filled,
- 13 files packaged.

Also checked:
- The Excel-recalculated gene lists match the app's lists exactly.
- The security checks: missing or wrong token, forged Host, foreign Origin, path traversal, opening executables, invalid settings.
- The single exe, run from an empty folder with a fresh profile.

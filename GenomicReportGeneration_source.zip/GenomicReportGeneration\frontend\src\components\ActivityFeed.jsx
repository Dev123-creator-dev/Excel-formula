import { Box, Stack, Typography, alpha, useTheme } from "@mui/material";
import TerminalRoundedIcon from "@mui/icons-material/TerminalRounded";
import { GlassCard, SectionTitle } from "./ui.jsx";
import { brand } from "../theme.js";

export const LEVEL_COLOR = { success: brand.green, info: brand.blue, warning: brand.amber, error: brand.pink };

export default function ActivityFeed({ logs, running }) {
  const theme = useTheme();
  return (
    <GlassCard sx={{ display: "flex", flexDirection: "column", minHeight: 0 }}>
      <SectionTitle
        icon={TerminalRoundedIcon}
        title="Live activity"
        subtitle="Every action is written to the audit trail and Logs folder"
        action={running && (
          <Stack direction="row" spacing={0.75} alignItems="center">
            <Box sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: brand.green, animation: "grg-blink 1s infinite" }} />
            <Typography variant="caption" sx={{ fontWeight: 700, color: brand.green }}>LIVE</Typography>
          </Stack>
        )}
      />
      <Box sx={{
        flex: 1, overflowY: "auto", maxHeight: 520, borderRadius: 3, p: 1.5,
        bgcolor: theme.custom.dark ? "rgba(2,6,23,.55)" : "rgba(15,23,42,.035)",
        border: `1px solid ${theme.palette.divider}`,
        fontFamily: '"Cascadia Code", "JetBrains Mono", Consolas, monospace', fontSize: 12.5,
      }}>
        {logs.length === 0 && (
          <Typography variant="body2" color="text.secondary" sx={{ p: 2, textAlign: "center" }}>
            No activity yet. Start the workflow to see events here.
          </Typography>
        )}
        {logs.map((l) => {
          const c = LEVEL_COLOR[l.level] || brand.blue;
          return (
            <Stack key={l.id} direction="row" spacing={1.25} sx={{
              py: 0.75, px: 1, borderRadius: 1.5, alignItems: "flex-start",
              "&:hover": { bgcolor: alpha(c, 0.06) },
            }}>
              <Typography component="span" sx={{ font: "inherit", color: "text.secondary", flexShrink: 0, opacity: 0.8 }}>
                {l.ts.slice(11, 19)}
              </Typography>
              <Box sx={{ width: 6, height: 6, borderRadius: "50%", bgcolor: c, mt: "7px", flexShrink: 0,
                boxShadow: `0 0 8px ${alpha(c, 0.8)}` }} />
              <Box sx={{ minWidth: 0 }}>
                <Typography component="div" sx={{ font: "inherit", fontWeight: 650, color: l.level === "error" ? c : "text.primary" }}>
                  {l.action}
                </Typography>
                {l.detail && (
                  <Typography component="div" sx={{
                    font: "inherit", fontSize: 11.5, color: "text.secondary", wordBreak: "break-all",
                    whiteSpace: "pre-wrap", display: "-webkit-box", WebkitLineClamp: 4, WebkitBoxOrient: "vertical", overflow: "hidden",
                  }}>
                    {l.detail}
                  </Typography>
                )}
              </Box>
            </Stack>
          );
        })}
      </Box>
    </GlassCard>
  );
}

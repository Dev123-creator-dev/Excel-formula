"""Step 6 - populate the Word report template.

* Placeholders (CLIENTNAME, STUDYNUMBER, CLIENTTESTAGENT, ANALYSISPARAMETER,
  MONTH DAY, YEAR) are replaced everywhere, including headers/footers, even
  when Word has split them across several runs.
* Table 3 (header + 60 rows: Gene | Probe | Fold change | P-value | Q-value |
  Drug Response) receives R2:W61 of the DiffEx workbook.
* The Conclusions 'XXXX' lines under the sensitive / resistant differential
  expression bullets receive the top-10 genes (AG2:AG11 / AH2:AH11).
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document

from .common import NeedsInput, StepContext, StepError, output_path, validate_file

TABLE3_HEADER = ["Gene", "Probe", "Fold change", "P-value", "Q-value", "Drug Response"]


def replace_in_paragraph(paragraph, mapping: dict[str, str]) -> int:
    """Replace placeholders that may span multiple runs, preserving run formatting."""
    count = 0
    for key, value in mapping.items():
        search_from = 0
        while True:
            runs = paragraph.runs
            texts = [r.text for r in runs]
            full = "".join(texts)
            idx = full.find(key, search_from)
            if idx < 0:
                break
            end_idx = idx + len(key)
            pos = 0
            start_run = end_run = None
            start_off = end_off = 0
            for i, t in enumerate(texts):
                if start_run is None and idx < pos + len(t):
                    start_run, start_off = i, idx - pos
                if start_run is not None and end_idx <= pos + len(t):
                    end_run, end_off = i, end_idx - pos
                    break
                pos += len(t)
            if start_run is None or end_run is None:
                break
            if start_run == end_run:
                t = texts[start_run]
                runs[start_run].text = t[:start_off] + value + t[end_off:]
            else:
                runs[start_run].text = texts[start_run][:start_off] + value
                for j in range(start_run + 1, end_run):
                    runs[j].text = ""
                runs[end_run].text = texts[end_run][end_off:]
            search_from = idx + len(value)
            count += 1
    return count


def _iter_paragraphs(container):
    for p in container.paragraphs:
        yield p
    for table in container.tables:
        for row in table.rows:
            for cell in row.cells:
                yield from _iter_paragraphs(cell)


def _all_paragraphs(doc):
    yield from _iter_paragraphs(doc)
    for section in doc.sections:
        for part in (section.header, section.footer, section.first_page_header,
                     section.first_page_footer, section.even_page_header, section.even_page_footer):
            if part is not None and not part.is_linked_to_previous:
                yield from _iter_paragraphs(part)


def _set_cell(cell, text: str) -> None:
    para = cell.paragraphs[0]
    if para.runs:
        para.runs[0].text = text
        for extra in para.runs[1:]:
            extra.text = ""
    else:
        para.add_run(text)


def _fmt_fc(v) -> str:
    return "" if v is None else f"{v:.2f}"


def _fmt_p(v) -> str:
    return "" if v is None else f"{v:.2E}"


def find_table3(doc):
    for table in doc.tables:
        header = [c.text.strip() for c in table.rows[0].cells]
        if header[:6] == TABLE3_HEADER and len(table.rows) >= 61:
            return table
    raise StepError("Could not find Table 3 (Gene | Probe | Fold change | P-value | Q-value | Drug Response) in the template.")


def fill_summary(doc, top_sensitive: list[str], top_resistant: list[str]) -> int:
    """Fill the 'XXXX' line that follows each differential-expression conclusion."""
    filled = 0
    pending = None
    for p in doc.paragraphs:
        text = p.text.strip()
        if "relative upregulation" in text and "sensitive" in text:
            pending = top_sensitive
            continue
        if "elevated expression associating with resistance" in text:
            pending = top_resistant
            continue
        if pending is not None and text == "XXXX":
            replace_in_paragraph(p, {"XXXX": ", ".join(pending)})
            filled += 1
            pending = None
    return filled


def build_report(template: Path, dest: Path, details: dict, genes: dict) -> dict:
    """details: compound, client, order_id, analysis_parameter - blank values keep their placeholder."""
    doc = Document(str(template))
    today = datetime.now()
    mapping = {
        "CLIENTTESTAGENT": details.get("compound", ""),
        "CLIENTNAME": details.get("client", ""),
        "STUDYNUMBER": details.get("order_id", ""),
        "ANALYSISPARAMETER": details.get("analysis_parameter", ""),
        "MONTH DAY, YEAR": f"{today:%B} {today.day}, {today.year}",
        "US034-000xxxx": details.get("order_id", ""),
    }
    mapping = {k: v.strip() for k, v in mapping.items() if v and v.strip()}
    replaced = sum(replace_in_paragraph(p, mapping) for p in _all_paragraphs(doc))

    table = find_table3(doc)
    rows = genes.get("table3", [])
    for i, row in enumerate(rows[:60], start=1):
        cells = table.rows[i].cells
        values = [str(row["gene"] or ""), str(row["probe"] or ""), _fmt_fc(row["fold_change"]),
                  _fmt_p(row["p_value"]), _fmt_p(row["q_value"]), row["drug_response"]]
        for c, v in zip(cells, values):
            _set_cell(c, v)

    summary_filled = fill_summary(doc, genes["top10_sensitive"], genes["top10_resistant"])
    dest.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(dest))
    return {"placeholders_replaced": replaced, "table3_rows": min(len(rows), 60),
            "summary_sections_filled": summary_filled}


def run(ctx: StepContext) -> dict:
    template_path = ctx.inputs.get("word_template") or ctx.settings.default_word_template
    if not template_path:
        raise NeedsInput("Select the Word report template to continue.", "word_template")
    template = validate_file(template_path, "Word template", (".docx",))
    genes = ctx.step_data("genes")
    if not genes.get("table3"):
        raise StepError("DiffEx gene data missing - run steps 3 and 4 first.")

    imported = ctx.step_data("import")
    details = {
        "compound": ctx.inputs.get("report_compound") or imported.get("compound_guess", ""),
        "client": ctx.inputs.get("report_client", ""),
        "order_id": ctx.inputs.get("report_order_id", ""),
        "analysis_parameter": ctx.inputs.get("analysis_parameter") or imported.get("analysis_parameter") or "IC50",
    }
    dest = output_path(ctx.path / "Reports", template.name, ctx.file_prefix, "Report")
    ctx.progress(30, "Populating report")
    ctx.info("Populating Word report", f"template={template.name}, " + ", ".join(f"{k}={v or '-'}" for k, v in details.items()))
    blank = [label for key, label in (("compound", "CLIENTTESTAGENT"), ("client", "CLIENTNAME"),
                                      ("order_id", "STUDYNUMBER")) if not details[key]]
    if blank:
        ctx.warn("Placeholders left for manual entry", ", ".join(blank))
    stats = build_report(template, dest, details, genes)
    if stats["summary_sections_filled"] < 2:
        ctx.warn("Summary gene lines not fully populated",
                 f"{stats['summary_sections_filled']}/2 'XXXX' lines found in Conclusions")
    ctx.register_file("word_report", str(dest))
    ctx.success("Word report generated", f"{dest}  ({stats['placeholders_replaced']} placeholders, "
                                         f"{stats['table3_rows']} Table 3 rows)")
    return {"report": str(dest), **stats, "summary": f"Report saved to {dest.name}"}

"""Step 2 - run the OncoPanel clustering R script against this project's data.

The user selects the clustering R script and, optionally, the GenerateClusteringFile.R
helper it sources and the tab-delimited assay data file. A missing helper falls back
to the bundled dummy; missing assay data is built from the Mutation report. The master script is
never edited in place; a patched copy is written to the Clustering folder with:

* working_directory / client_data_fn  -> this project's Clustering folder + data file
* source("...GenerateClusteringFile.R") -> the helper the user selected
* (optional) a bootstrap that installs missing CRAN packages into the user's
  personal R library, so non-technical users never have to open R.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from pathlib import Path

import openpyxl

from .common import NeedsInput, StepContext, StepError, safe_name, validate_file
from .oncopredictor import guess_compound

WORKDIR_RE = re.compile(r'^(\s*working_directory\s*<-\s*)".*?"', re.M)
DATAFN_RE = re.compile(r'^(\s*client_data_fn\s*<-\s*paste0\(\s*working_directory\s*,\s*)".*?"', re.M)
SOURCE_RE = re.compile(r'source\(\s*(["\'])(?P<path>[^"\']+)\1\s*\)')
PACKAGE_RE = re.compile(r'\b(?:library|require|requireNamespace)\(\s*["\']?([A-Za-z][A-Za-z0-9.]*)["\']?')
R_SAFE_PKG = re.compile(r"^[A-Za-z][A-Za-z0-9.]*$")
BASE_PACKAGES = {"base", "stats", "utils", "graphics", "grDevices", "methods", "tools", "datasets", "grid", "parallel"}

# Kills the child process tree on cancel (Rscript can spawn helpers).
_running: dict[int, subprocess.Popen] = {}


def _r_string(path: Path | str) -> str:
    """Forward-slash path, safe inside an R double-quoted string."""
    text = Path(path).as_posix() if not isinstance(path, str) else path
    if any(c in text for c in '"\\\n\r'):
        raise StepError(f"Unsupported character in path: {text}")
    return text


def patch_script(source: str, workdir: Path, data_file: str, helper: Path) -> tuple[str, int]:
    workdir_r = _r_string(workdir).rstrip("/") + "/"
    patched, n1 = WORKDIR_RE.subn(lambda m: f'{m.group(1)}"{workdir_r}"', source, count=1)
    patched, n2 = DATAFN_RE.subn(lambda m: f'{m.group(1)}"{_r_string(data_file)}"', patched, count=1)
    if not (n1 and n2):
        raise StepError(
            "Could not find the input path lines in the R script.",
            'Expected: working_directory <- "..." and client_data_fn <- paste0(working_directory, "...")',
        )

    helper_r = _r_string(helper)
    sources = list(SOURCE_RE.finditer(patched))
    targets = [m for m in sources if Path(m.group("path")).name.lower() == helper.name.lower()]
    if not targets and len(sources) == 1:
        targets = sources  # single source() line: it must be the helper
    if not targets:
        raise StepError(
            f"Could not find a source(\"...{helper.name}\") line in the R script.",
            "The selected helper's file name must match the one the script sources.",
        )
    for m in reversed(targets):
        patched = patched[: m.start()] + f'source("{helper_r}")' + patched[m.end():]
    return patched, len(targets)


def bootstrap(packages: list[str]) -> str:
    pkgs = ", ".join(f'"{p}"' for p in packages)
    return (
        "# --- added by Genomic Report Generation: install missing packages ---\n"
        "local({\n"
        '  lib <- Sys.getenv("R_LIBS_USER")\n'
        "  dir.create(lib, recursive = TRUE, showWarnings = FALSE)\n"
        "  .libPaths(c(lib, .libPaths()))\n"
        f"  for (p in c({pkgs})) if (!requireNamespace(p, quietly = TRUE)) {{\n"
        '    message("Installing R package: ", p)\n'
        '    install.packages(p, lib = lib, repos = "https://cloud.r-project.org", quiet = TRUE)\n'
        "  }\n"
        "})\n"
        "# ---------------------------------------------------------------------\n\n"
    )


def required_packages(*scripts: str) -> list[str]:
    found: list[str] = []
    for text in scripts:
        code = "\n".join(line.split("#", 1)[0] for line in text.splitlines())
        for name in PACKAGE_RE.findall(code):
            if name not in BASE_PACKAGES and R_SAFE_PKG.match(name) and name not in found:
                found.append(name)
    return found


def cancel(project_id: int) -> None:
    proc = _running.get(project_id)
    if proc and proc.poll() is None:
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def _snapshot(folder: Path) -> dict[str, float]:
    return {str(p): p.stat().st_mtime for p in folder.rglob("*") if p.is_file()}


def _find_rscript(configured: str) -> Path:
    from ..config import detect_rscript

    for candidate in (configured, detect_rscript()):
        if candidate and Path(candidate).is_file():
            return Path(candidate)
    raise StepError(
        "R is not installed on this computer (Rscript.exe not found).",
        "Install R from https://cran.r-project.org/bin/windows/base/ (default options), "
        "then run this step again - or skip it.",
    )


def bundled_helper() -> Path:
    """The dummy GenerateClusteringFile.R shipped with the app (exe or source checkout)."""
    from ..config import resource_dir

    for base in (resource_dir(), resource_dir().parent):
        candidate = base / "R" / "GenerateClusteringFile.R"
        if candidate.is_file():
            return candidate
    raise StepError("The built-in dummy GenerateClusteringFile.R is missing.",
                    "Select a GenerateClusteringFile.R file instead.")


def build_dummy_assay(mutation_path: str, workdir: Path) -> Path:
    """Write the Mutation report's 'OncoPanel Results' sheet as a tab-delimited assay file."""
    if not mutation_path:
        raise NeedsInput("Select the assay data file (.tab), or import the Mutation report in step 1 "
                         "so a dummy one can be generated from it.", "clustering_input_path")
    source = validate_file(mutation_path, "Mutation report", (".xlsx", ".xlsm"))
    wb = openpyxl.load_workbook(source, read_only=True, data_only=True)
    try:
        if "OncoPanel Results" not in wb.sheetnames:
            raise StepError(f"{source.name} has no 'OncoPanel Results' sheet to build the assay data from.",
                            "Select an assay data file (.tab) instead.")
        rows = [r for r in wb["OncoPanel Results"].iter_rows(values_only=True) if any(v is not None for v in r)]
    finally:
        wb.close()
    if len(rows) < 4:
        raise StepError("The Mutation report has too few cell lines to build assay data.",
                        "Select an assay data file (.tab) instead.")
    width = max(i + 1 for i, v in enumerate(rows[0]) if v not in (None, ""))
    compound = guess_compound(source.name) or "Study"
    dest = workdir / f"{safe_name(compound)}_assay_data_DUMMY.tab"
    with open(dest, "w", encoding="utf-8", newline="") as fh:
        for row in rows:
            cells = ["" if v is None else str(v).replace("\t", " ").replace("\n", " ") for v in row[:width]]
            fh.write("\t".join(cells) + "\n")
    return dest


def run(ctx: StepContext) -> dict:
    settings = ctx.settings
    if not ctx.inputs.get("r_script_path"):
        raise NeedsInput("Select the clustering R script.", "r_script_path")

    script = validate_file(ctx.inputs["r_script_path"], "Clustering R script", (".r",))
    rscript = _find_rscript(settings.rscript_exe)
    workdir = ctx.path / "Clustering"
    workdir.mkdir(parents=True, exist_ok=True)

    # Optional inputs fall back to built-in dummies until the real files are available.
    dummies = []
    if ctx.inputs.get("r_helper_path"):
        helper = validate_file(ctx.inputs["r_helper_path"], "GenerateClusteringFile helper", (".r",))
    else:
        helper = bundled_helper()
        dummies.append("GenerateClusteringFile.R")
        ctx.warn("Using the built-in DUMMY GenerateClusteringFile.R", "Select the real helper when it is available")
    if ctx.inputs.get("clustering_input_path"):
        data_file = validate_file(ctx.inputs["clustering_input_path"], "Assay data file",
                                  (".tab", ".txt", ".tsv", ".csv"))
    else:
        data_file = build_dummy_assay(ctx.inputs.get("mutation_path", ""), workdir)
        dummies.append("assay data")
        ctx.warn("Using a DUMMY assay data file built from the Mutation report", str(data_file))

    staged = workdir / data_file.name
    if data_file.resolve() != staged.resolve():
        shutil.copy2(data_file, staged)
        ctx.info("Assay data staged", str(staged))
    ctx.register_file("clustering_input", str(staged))

    script_text = script.read_text(encoding="utf-8", errors="replace")
    patched, replaced = patch_script(script_text, workdir, data_file.name, helper)
    packages = required_packages(script_text, helper.read_text(encoding="utf-8", errors="replace"))
    if settings.r_auto_install_packages and packages:
        patched = bootstrap(packages) + patched
    patched_path = workdir / f"{script.stem}_{ctx.file_prefix}.r"
    patched_path.write_text(patched, encoding="utf-8")
    ctx.info("R script paths updated",
             f"working_directory={workdir.as_posix()}/ | data={data_file.name} | "
             f"source -> {helper} ({replaced} line) | packages: {', '.join(packages) or 'none'}")

    before = _snapshot(workdir)
    log_path = ctx.path / "Logs" / "clustering_R_console.log"
    ctx.info("R script started", f"{rscript} {patched_path.name}")
    ctx.progress(20, "Running clustering...")
    started = time.time()
    timeout = settings.r_timeout_minutes * 60

    with open(log_path, "w", encoding="utf-8") as log_fh:
        proc = subprocess.Popen(
            [str(rscript), "--vanilla", str(patched_path)],
            cwd=workdir, stdout=log_fh, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        _running[ctx.project["id"]] = proc
        try:
            while proc.poll() is None:
                ctx.check_cancel()
                elapsed = time.time() - started
                if elapsed > timeout:
                    cancel(ctx.project["id"])
                    raise StepError(f"R script exceeded the {settings.r_timeout_minutes} minute timeout.")
                # Asymptotic progress: R gives no progress signal.
                ctx.progress(20 + 70 * (1 - 1 / (1 + elapsed / 60)), f"Running clustering... {int(elapsed)}s")
                time.sleep(1)
        except BaseException:
            cancel(ctx.project["id"])
            raise
        finally:
            _running.pop(ctx.project["id"], None)

    duration = time.time() - started
    ctx.register_file("log", str(log_path))
    if proc.returncode != 0:
        tail = log_path.read_text(encoding="utf-8", errors="replace").strip().splitlines()[-8:]
        raise StepError(f"R script failed (exit code {proc.returncode}).", "\n".join(tail))

    after = _snapshot(workdir)
    skip = {str(patched_path), str(staged)}
    outputs = sorted(p for p, m in after.items() if p not in skip and before.get(p) != m)
    if not outputs:
        ctx.warn("R script finished but produced no new files", str(workdir))
    ranked = None
    for out in outputs:
        is_ranked = "rank" in Path(out).name.lower()
        ranked = ranked or (out if is_ranked else None)
        ctx.register_file("ranked_soc" if is_ranked else "clustering_output", out)
    ctx.success("R script completed", f"{len(outputs)} output file(s) in {duration:.0f}s")

    return {
        "output_dir": str(workdir),
        "outputs": outputs,
        "ranked_soc_file": ranked,
        "patched_script": str(patched_path),
        "r_duration_s": round(duration, 1),
        "helper_file": str(helper),
        "assay_file": str(staged),
        "dummies": dummies,
        "summary": f"{len(outputs)} output file(s) generated in {duration:.0f}s",
    }

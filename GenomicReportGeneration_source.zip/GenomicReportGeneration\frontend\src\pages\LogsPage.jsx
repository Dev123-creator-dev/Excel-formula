import { useEffect, useMemo, useState } from "react";
import { Box, Chip, InputAdornment, Stack, TextField, ToggleButton, ToggleButtonGroup, Typography, alpha, useTheme } from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import { GlassCard, SectionTitle } from "../components/ui.jsx";
import { LEVEL_COLOR } from "../components/ActivityFeed.jsx";
import { api, fmtTime } from "../api.js";

export default function LogsPage() {
  const theme = useTheme();
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState("");
  const [level, setLevel] = useState("all");
  useEffect(() => {
    let alive = true;
    const load = () => api.allLogs().then((r) => alive && setRows(r)).catch(() => {});
    load();
    const t = setInterval(load, 4000);
    return () => { alive = false; clearInterval(t); };
  }, []);
  const filtered = useMemo(() => rows.filter((r) =>
    (level === "all" || r.level === level) &&
    (!q || `${r.action} ${r.detail} ${r.study_name} ${r.actor}`.toLowerCase().includes(q.toLowerCase()))), [rows, q, level]);

  return (
    <GlassCard>
      <SectionTitle icon={ReceiptLongRoundedIcon} title="Audit trail" subtitle="All user and system actions across projects (SQLite)" />
      <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} sx={{ mb: 2 }}>
        <TextField placeholder="Search actions, details, projects, users…" value={q} onChange={(e) => setQ(e.target.value)}
          slotProps={{ input: { startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> } }} />
        <ToggleButtonGroup size="small" exclusive value={level} onChange={(_, v) => v && setLevel(v)}>
          {["all", "success", "info", "warning", "error"].map((l) => (
            <ToggleButton key={l} value={l} sx={{ px: 1.75, textTransform: "capitalize", borderRadius: 2.5 }}>{l}</ToggleButton>
          ))}
        </ToggleButtonGroup>
      </Stack>
      <Box sx={{ overflowX: "auto" }}>
        <Box component="table" sx={{
          width: "100%", borderCollapse: "separate", borderSpacing: 0, fontSize: 13,
          "& th": { textAlign: "left", fontWeight: 650, color: "text.secondary", fontSize: 11.5, textTransform: "uppercase",
            letterSpacing: ".08em", py: 1.25, px: 1.5, borderBottom: `1px solid ${theme.palette.divider}`, whiteSpace: "nowrap" },
          "& td": { py: 1.1, px: 1.5, borderBottom: `1px solid ${theme.palette.divider}`, verticalAlign: "top" },
          "& tbody tr:hover td": { bgcolor: alpha("#3BA4FF", 0.04) },
        }}>
          <thead><tr><th>Time</th><th>Level</th><th>Project</th><th>Action</th><th>Detail</th><th>User</th></tr></thead>
          <tbody>
            {filtered.slice(0, 500).map((r) => (
              <tr key={r.id}>
                <td style={{ whiteSpace: "nowrap" }}>{fmtTime(r.ts)}</td>
                <td><Chip size="small" label={r.level} sx={{ height: 22, fontSize: 11, color: LEVEL_COLOR[r.level],
                  bgcolor: alpha(LEVEL_COLOR[r.level] || "#888", 0.12) }} /></td>
                <td style={{ whiteSpace: "nowrap" }}>{r.study_name || "—"}</td>
                <td style={{ fontWeight: 600 }}>{r.action}</td>
                <td><Typography variant="caption" color="text.secondary" sx={{ wordBreak: "break-all", whiteSpace: "pre-wrap",
                  display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{r.detail}</Typography></td>
                <td style={{ whiteSpace: "nowrap" }}>{r.actor}</td>
              </tr>
            ))}
          </tbody>
        </Box>
        {!filtered.length && <Typography color="text.secondary" sx={{ textAlign: "center", py: 6 }}>No matching events.</Typography>}
      </Box>
    </GlassCard>
  );
}

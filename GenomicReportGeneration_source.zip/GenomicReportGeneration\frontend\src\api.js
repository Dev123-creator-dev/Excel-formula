// Per-launch session token: handed over in the URL fragment by the launcher,
// kept for this window only, and sent on every API call (see backend security.py).
function initToken() {
  const m = window.location.hash.match(/token=([\w-]+)/);
  if (m) {
    try { sessionStorage.setItem("grg-token", m[1]); } catch { /* storage unavailable */ }
    history.replaceState(null, "", window.location.pathname);
    return m[1];
  }
  try { return sessionStorage.getItem("grg-token") || ""; } catch { return ""; }
}
const TOKEN = initToken();
export const hasToken = () => !!TOKEN;

async function request(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: { "X-GRG-Token": TOKEN, ...(body ? { "Content-Type": "application/json" } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error("Cannot reach the Genomic Report Generation server. Relaunch GenomicReportGeneration.exe, then try again.");
  }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) window.dispatchEvent(new Event("grg-unauthorized"));
  if (!res.ok) {
    let msg = data.detail || res.statusText;
    if (Array.isArray(msg)) msg = msg.map((d) => `${d.loc?.slice(-1)[0]}: ${d.msg}`).join("; ");
    const err = new Error(msg);
    err.hint = data.hint;
    throw err;
  }
  return data;
}

export const api = {
  health: () => request("GET", "/api/health"),
  settings: () => request("GET", "/api/settings"),
  saveSettings: (v) => request("PUT", "/api/settings", v),
  projects: () => request("GET", "/api/projects"),
  project: (id) => request("GET", `/api/projects/${id}`),
  createProject: (folder) => request("POST", "/api/projects", { folder }),
  previewProject: (folder) => request("POST", "/api/projects/preview", { folder }),
  openOncoPredictor: () => request("POST", "/api/system/oncopredictor"),
  deleteProject: (id) => request("DELETE", `/api/projects/${id}`),
  setInputs: (id, values) => request("PATCH", `/api/projects/${id}/inputs`, { values }),
  runAll: (id) => request("POST", `/api/projects/${id}/run`),
  cancel: (id) => request("POST", `/api/projects/${id}/cancel`),
  step: (id, key, action) => request("POST", `/api/projects/${id}/steps/${key}/${action}`),
  logs: (id, limit = 200) => request("GET", `/api/projects/${id}/logs?limit=${limit}`),
  allLogs: () => request("GET", "/api/logs"),
  pick: (opts) => request("POST", "/api/system/pick", opts),
  open: (path) => request("POST", "/api/system/open", { path }),
  reveal: (path) => request("POST", "/api/system/reveal", { path }),
};

export function fmtDuration(s) {
  if (s == null) return "—";
  if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${Math.round(s % 60)}s`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}

export function fmtBytes(b) {
  if (b == null) return "";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b.toFixed(i ? 1 : 0)} ${u[i]}`;
}

export function fmtTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function basename(p) {
  return (p || "").split(/[\\/]/).pop();
}

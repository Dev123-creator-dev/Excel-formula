import { Box, Chip, Stack, Typography, alpha } from "@mui/material";
import MenuBookRoundedIcon from "@mui/icons-material/MenuBookRounded";
import TipsAndUpdatesRoundedIcon from "@mui/icons-material/TipsAndUpdatesRounded";
import { GlassCard, SectionTitle } from "../components/ui.jsx";
import { brand } from "../theme.js";

const STEPS = [
  {
    title: "Create a project",
    who: "You",
    body: [
      "Click New project (top right).",
      "Click the folder icon and choose where the project should be saved, e.g. D:\\.",
      "Click Create project. All sub-folders (OncoPredictor, Clustering, DiffEx, GProfiler, Reports, Logs) are created for you.",
    ],
  },
  {
    title: "Step 1 · Import the OncoPredictor files",
    who: "You select · app imports",
    body: [
      "Run OncoPredictor (Launch OncoPredictor button) and download the DiffEx and Mutation reports.",
      "In Step 1 click the folder icon next to each field and select the DiffEx report and the Mutation report.",
      "Click Import files. Both files are checked and moved into the project's OncoPredictor folder.",
    ],
  },
  {
    title: "Step 2 · Run the clustering R script",
    who: "You select · app runs R",
    body: [
      "Select the clustering R script (.r).",
      "Optional: select GenerateClusteringFile.R — the file the script sources. It replaces the fixed K:\\LabOperations\\… path. Leave it empty to use the built-in dummy.",
      "Optional: select the assay data file (.tab). Leave it empty and a dummy one is generated from the Mutation report.",
      "Click Run R script. Paths are written into a copy of the script, missing R packages are installed, and the outputs are saved in Clustering.",
      "No R on this computer? Click Skip to continue without clustering.",
    ],
  },
  {
    title: "Steps 3 – 7 · Automatic",
    who: "App",
    body: [
      "Step 3 asks once for the Excel template (Mutations & Hotspots), then fills 'Table 3 for DiffEx'.",
      "Step 4 extracts the top-60 sensitivity and resistance genes.",
      "Step 5 runs g:Profiler for both gene lists (needs internet) and saves the CSVs.",
      "Step 6 asks once for the Word report template, fills Table 3, the gene summary and the report details.",
      "Step 7 zips every deliverable with a checksum manifest into Reports.",
      "Tip: after Step 1 & 2, click Resume workflow at the top to run the rest in one go.",
    ],
  },
  {
    title: "Get the results",
    who: "You",
    body: [
      "Every file appears under Deliverables on the right — click to open or show it in its folder.",
      "Something failed? Read the red message on the step, fix it, then click Retry. Finished steps are never repeated.",
      "Your selections (R files, templates) are remembered for the next project.",
    ],
  },
];

export default function GuidePage() {
  return (
    <Box sx={{ display: "grid", gap: 2.5, gridTemplateColumns: { xs: "1fr", lg: "minmax(0,1.7fr) minmax(0,1fr)" }, alignItems: "start" }}>
      <GlassCard>
        <SectionTitle icon={MenuBookRoundedIcon} title="How to use the application" subtitle="Five simple stages — the app does the rest" />
        <Stack spacing={2}>
          {STEPS.map((s, i) => (
            <Stack key={s.title} direction="row" spacing={2} className="grg-rise" sx={{ animationDelay: `${i * 60}ms` }}>
              <Box sx={{ width: 36, height: 36, borderRadius: "50%", display: "grid", placeItems: "center", flexShrink: 0,
                fontWeight: 800, color: "#fff", background: brand.gradient }}>{i + 1}</Box>
              <Box sx={{ flex: 1, minWidth: 0, p: 2, borderRadius: 4, border: "1px solid", borderColor: "divider" }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }} flexWrap="wrap" useFlexGap>
                  <Typography variant="subtitle1">{s.title}</Typography>
                  <Chip size="small" label={s.who} sx={{ height: 22, fontSize: 11, bgcolor: alpha(brand.teal, 0.12), color: brand.teal }} />
                </Stack>
                <Box component="ol" sx={{ m: 0, pl: 2.5, color: "text.secondary", "& li": { mb: 0.5, lineHeight: 1.55 } }}>
                  {s.body.map((b) => <li key={b}><Typography variant="body2" component="span">{b}</Typography></li>)}
                </Box>
              </Box>
            </Stack>
          ))}
        </Stack>
      </GlassCard>
      <GlassCard sx={{ position: { lg: "sticky" }, top: 96 }}>
        <SectionTitle icon={TipsAndUpdatesRoundedIcon} title="Good to know" />
        <Stack spacing={1.5} sx={{ color: "text.secondary", "& b": { color: "text.primary" } }}>
          <Typography variant="body2"><b>Nothing to install.</b> Just run GenomicReportGeneration.exe — it opens in Chrome or Microsoft Edge.</Typography>
          <Typography variant="body2"><b>Step 2 needs R</b> on the computer (free: cran.r-project.org). Missing R packages are installed automatically.</Typography>
          <Typography variant="body2"><b>Step 5 needs internet</b> to reach g:Profiler.</Typography>
          <Typography variant="body2"><b>Private by design.</b> The app only runs on this computer (127.0.0.1); no data is uploaded except the gene lists sent to g:Profiler.</Typography>
          <Typography variant="body2"><b>Closing the window</b> stops the app automatically a few minutes later (never while a step is running).</Typography>
          <Typography variant="body2"><b>Every action is logged</b> — see Activity Log, or the Logs folder inside each project.</Typography>
        </Stack>
      </GlassCard>
    </Box>
  );
}

import { Box, useTheme } from "@mui/material";

/** Ambient mesh-gradient backdrop with slowly drifting light blobs and a faint helix grid. */
export default function Background() {
  const dark = useTheme().custom.dark;
  const blob = (color, size, top, left, delay, opacity) => (
    <Box
      sx={{
        position: "absolute", top, left, width: size, height: size, borderRadius: "50%",
        background: color, filter: "blur(90px)", opacity,
        animation: `grg-float 26s ease-in-out ${delay}s infinite`,
      }}
    />
  );
  return (
    <Box aria-hidden sx={{ position: "fixed", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
      {blob("#19E3C5", "38vw", "-12vh", "-8vw", 0, dark ? 0.16 : 0.22)}
      {blob("#7C5CFF", "42vw", "40vh", "62vw", -8, dark ? 0.2 : 0.18)}
      {blob("#3BA4FF", "30vw", "62vh", "8vw", -16, dark ? 0.12 : 0.14)}
      <Box
        component="svg"
        sx={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: dark ? 0.06 : 0.07 }}
      >
        <defs>
          <pattern id="grg-grid" width="44" height="44" patternUnits="userSpaceOnUse">
            <path d="M44 0H0V44" fill="none" stroke={dark ? "#fff" : "#0F172A"} strokeWidth="0.6" />
          </pattern>
          <radialGradient id="grg-fade" cx="50%" cy="30%" r="75%">
            <stop offset="0" stopColor="#fff" stopOpacity="1" />
            <stop offset="1" stopColor="#fff" stopOpacity="0" />
          </radialGradient>
          <mask id="grg-mask"><rect width="100%" height="100%" fill="url(#grg-fade)" /></mask>
        </defs>
        <rect width="100%" height="100%" fill="url(#grg-grid)" mask="url(#grg-mask)" />
      </Box>
    </Box>
  );
}

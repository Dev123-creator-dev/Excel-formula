import { Box, ButtonBase, Stack, Tooltip, Typography, alpha, useTheme } from "@mui/material";
import SpaceDashboardRoundedIcon from "@mui/icons-material/SpaceDashboardRounded";
import FolderCopyRoundedIcon from "@mui/icons-material/FolderCopyRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";
import MenuBookRoundedIcon from "@mui/icons-material/MenuBookRounded";
import DarkModeRoundedIcon from "@mui/icons-material/DarkModeRounded";
import LightModeRoundedIcon from "@mui/icons-material/LightModeRounded";
import Logo from "./Logo.jsx";
import { brand } from "../theme.js";

const NAV = [
  { key: "dashboard", label: "Dashboard", icon: SpaceDashboardRoundedIcon },
  { key: "projects", label: "Projects", icon: FolderCopyRoundedIcon },
  { key: "logs", label: "Activity Log", icon: ReceiptLongRoundedIcon },
  { key: "guide", label: "User Guide", icon: MenuBookRoundedIcon },
  { key: "settings", label: "Settings", icon: TuneRoundedIcon },
];

export const SIDEBAR_WIDTH = 248;

export default function Sidebar({ page, onNavigate, mode, onToggleMode, health }) {
  const theme = useTheme();
  const healthy = health && Object.values(health.checks).every((c) => c.ok);
  return (
    <Box
      component="nav"
      sx={{
        width: { xs: 76, lg: SIDEBAR_WIDTH }, flexShrink: 0, position: "sticky", top: 0, height: "100vh",
        p: { xs: 1.5, lg: 2.5 }, display: "flex", flexDirection: "column", gap: 3, zIndex: 2,
        borderRight: `1px solid ${theme.palette.divider}`,
        background: theme.custom.dark ? "rgba(6,10,20,.55)" : "rgba(255,255,255,.5)",
        backdropFilter: "blur(20px)",
      }}
    >
      <Stack direction="row" alignItems="center" spacing={1.5} sx={{ px: { lg: 0.5 }, pt: 0.5 }}>
        <Logo size={42} />
        <Box sx={{ display: { xs: "none", lg: "block" }, minWidth: 0 }}>
          <Typography sx={{ fontWeight: 800, lineHeight: 1.15, fontSize: 15, letterSpacing: "-0.01em" }}>
            Genomic Report
          </Typography>
          <Typography sx={{
            fontWeight: 800, lineHeight: 1.15, fontSize: 15, letterSpacing: "-0.01em",
            background: brand.gradient, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            Generation
          </Typography>
        </Box>
      </Stack>

      <Stack spacing={0.75}>
        <Typography variant="overline" color="text.secondary" sx={{ px: 1.5, display: { xs: "none", lg: "block" } }}>
          Workspace
        </Typography>
        {NAV.map(({ key, label, icon: Icon }) => {
          const active = page === key;
          return (
            <Tooltip key={key} title={label} placement="right" disableHoverListener={window.innerWidth >= 1200}>
              <ButtonBase
                onClick={() => onNavigate(key)}
                sx={{
                  justifyContent: { xs: "center", lg: "flex-start" }, gap: 1.5, px: 1.5, py: 1.25,
                  borderRadius: 3, position: "relative", color: active ? "text.primary" : "text.secondary",
                  fontWeight: 600, fontSize: 14, transition: "all .2s",
                  background: active ? alpha(brand.violet, theme.custom.dark ? 0.16 : 0.1) : "transparent",
                  "&:hover": { background: alpha(brand.teal, 0.08), color: "text.primary" },
                  "&::before": active ? {
                    content: '""', position: "absolute", left: -10, top: 10, bottom: 10, width: 4,
                    borderRadius: 4, background: brand.gradient,
                  } : {},
                }}
              >
                <Icon sx={{ fontSize: 21, color: active ? brand.teal : "inherit" }} />
                <Box component="span" sx={{ display: { xs: "none", lg: "inline" } }}>{label}</Box>
              </ButtonBase>
            </Tooltip>
          );
        })}
      </Stack>

      <Box sx={{ flex: 1 }} />

      <Box
        sx={{
          display: { xs: "none", lg: "block" }, p: 2, borderRadius: 4,
          background: brand.gradientSoft, border: `1px solid ${theme.palette.divider}`,
        }}
      >
        <Stack direction="row" alignItems="center" spacing={1}>
          <Box sx={{
            width: 8, height: 8, borderRadius: "50%", bgcolor: healthy ? brand.green : brand.amber,
            boxShadow: `0 0 0 4px ${alpha(healthy ? brand.green : brand.amber, 0.2)}`,
          }} />
          <Typography variant="subtitle2">{healthy ? "All systems ready" : "Attention needed"}</Typography>
        </Stack>
        <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 0.75 }}>
          Local mode · 127.0.0.1 · v{health?.version || "1.0.0"}
        </Typography>
      </Box>

      <ButtonBase
        onClick={onToggleMode}
        sx={{
          gap: 1.25, px: 1.5, py: 1.1, borderRadius: 3, justifyContent: { xs: "center", lg: "flex-start" },
          color: "text.secondary", fontSize: 14, fontWeight: 600, border: `1px solid ${theme.palette.divider}`,
          "&:hover": { color: "text.primary" },
        }}
      >
        {mode === "dark" ? <LightModeRoundedIcon fontSize="small" /> : <DarkModeRoundedIcon fontSize="small" />}
        <Box component="span" sx={{ display: { xs: "none", lg: "inline" } }}>
          {mode === "dark" ? "Light theme" : "Dark theme"}
        </Box>
      </ButtonBase>
    </Box>
  );
}

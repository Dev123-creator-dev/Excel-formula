"""Genomic Report Generation - local automation platform."""

APP_NAME = "Genomic Report Generation"
APP_VERSION = "1.0.0"

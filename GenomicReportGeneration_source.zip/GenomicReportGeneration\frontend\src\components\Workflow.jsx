import { useEffect, useState } from "react";
import {
  Alert, Box, Button, Chip, Collapse, Divider, Stack, TextField, Tooltip, Typography, alpha, useTheme,
} from "@mui/material";
import AccountTreeRoundedIcon from "@mui/icons-material/AccountTreeRounded";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import ReplayRoundedIcon from "@mui/icons-material/ReplayRounded";
import SkipNextRoundedIcon from "@mui/icons-material/SkipNextRounded";
import RestartAltRoundedIcon from "@mui/icons-material/RestartAltRounded";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import RadioButtonUncheckedRoundedIcon from "@mui/icons-material/RadioButtonUncheckedRounded";
import OpenInNewRoundedIcon from "@mui/icons-material/OpenInNewRounded";
import LockRoundedIcon from "@mui/icons-material/LockRounded";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import TimerOutlinedIcon from "@mui/icons-material/TimerOutlined";
import { GlassCard, PathField, SectionTitle, ShimmerBar, StatusChip, StepNode } from "./ui.jsx";
import { brand, statusColor } from "../theme.js";
import { api, basename, fmtDuration } from "../api.js";
import { useAction } from "../context.jsx";

const DONE = ["completed", "skipped"];

function Check({ ok, label }) {
  return (
    <Stack direction="row" spacing={1} alignItems="center">
      {ok ? <CheckCircleRoundedIcon sx={{ fontSize: 19, color: brand.green }} />
        : <RadioButtonUncheckedRoundedIcon sx={{ fontSize: 19, color: "text.disabled" }} />}
      <Typography variant="body2" sx={{ fontWeight: ok ? 650 : 500, color: ok ? "text.primary" : "text.secondary" }}>{label}</Typography>
    </Stack>
  );
}

function KV({ k, v, mono, onClick }) {
  return (
    <Stack direction="row" spacing={1.5} sx={{ py: 0.4, minWidth: 0 }}>
      <Typography variant="body2" color="text.secondary" sx={{ minWidth: 128, flexShrink: 0 }}>{k}</Typography>
      <Typography variant="body2" onClick={onClick} title={typeof v === "string" ? v : undefined} sx={{
        fontWeight: 600, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        fontFamily: mono ? '"Cascadia Code", Consolas, monospace' : undefined, fontSize: mono ? 12.5 : undefined,
        cursor: onClick ? "pointer" : undefined, "&:hover": onClick ? { color: brand.teal } : undefined,
      }}>{v}</Typography>
    </Stack>
  );
}

function GeneChips({ title, genes, color }) {
  const [all, setAll] = useState(false);
  if (!genes?.length) return null;
  const shown = all ? genes : genes.slice(0, 10);
  return (
    <Box sx={{ flex: 1, minWidth: 0 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
        <Typography variant="overline" sx={{ color }}>{title}</Typography>
        <Button size="small" onClick={() => setAll(!all)} sx={{ minWidth: 0, fontSize: 12 }}>
          {all ? "Top 10" : `All ${genes.length}`}
        </Button>
      </Stack>
      <Stack direction="row" flexWrap="wrap" useFlexGap spacing={0.75}>
        {shown.map((g, i) => (
          <Chip key={g + i} size="small" label={<><Box component="span" sx={{ opacity: 0.55, mr: 0.6 }}>{i + 1}</Box>{g}</>}
            sx={{ bgcolor: alpha(color, 0.1), border: `1px solid ${alpha(color, 0.25)}`, fontFamily: '"Cascadia Code", Consolas, monospace', fontSize: 12 }} />
        ))}
      </Stack>
    </Box>
  );
}

function useInput(project, key) {
  const [v, setV] = useState(project.inputs?.[key] || "");
  useEffect(() => { setV(project.inputs?.[key] || ""); }, [project.id, project.inputs?.[key]]);
  return [v, setV];
}

function StepBody({ step, project, settings, steps, onChanged }) {
  const act = useAction();
  const d = step.data || {};
  const commit = (key) => async (value) => {
    if ((project.inputs?.[key] || "") === (value || "")) return;
    await act(() => api.setInputs(project.id, { [key]: value || "" }), "Saved");
    onChanged();
  };
  const [excel, setExcel] = useInput(project, "excel_template");
  const [word, setWord] = useInput(project, "word_template");
  const [tab, setTab] = useInput(project, "clustering_input_path");
  const [rScript, setRScript] = useInput(project, "r_script_path");
  const [rHelper, setRHelper] = useInput(project, "r_helper_path");
  const [diffexPath, setDiffexPath] = useInput(project, "diffex_path");
  const [mutPath, setMutPath] = useInput(project, "mutation_path");
  const [param, setParam] = useInput(project, "analysis_parameter");
  const [compound, setCompound] = useInput(project, "report_compound");
  const [client, setClient] = useInput(project, "report_client");
  const [orderId, setOrderId] = useInput(project, "report_order_id");
  const byKey = Object.fromEntries(steps.map((s) => [s.key, s]));
  const open = (p) => act(() => api.open(p));
  const locked = DONE.includes(step.status) || step.status === "running";

  switch (step.key) {
    case "import": {
      const c = d.checks || {};
      return (
        <Stack spacing={2}>
          <Stack direction={{ xs: "column", sm: "row" }} spacing={3}>
            <Check ok={c.diffex_found || !!diffexPath} label="DiffEx Selected" />
            <Check ok={c.mutation_found || !!mutPath} label="Mutation Report Selected" />
            <Check ok={c.imported} label="Files Imported" />
          </Stack>
          {!locked && (
            <Stack spacing={1.5}>
              <PathField label="DiffEx report (.xlsx) from OncoPredictor" value={diffexPath} onChange={setDiffexPath}
                onCommit={commit("diffex_path")} extensions={[".xlsx", ".xlsm"]} required />
              <PathField label="Mutation report (.xlsx) from OncoPredictor" value={mutPath} onChange={setMutPath}
                onCommit={commit("mutation_path")} extensions={[".xlsx", ".xlsm"]} required />
              <Typography variant="caption" color="text.secondary">
                On import both files are checked and {settings?.move_files ? "moved" : "copied"} into <b>{project.project_path}\OncoPredictor</b>.
              </Typography>
            </Stack>
          )}
          {d.diffex_file && (
            <Box>
              <KV k="DiffEx report" v={basename(d.diffex_file)} mono onClick={() => open(d.diffex_file)} />
              <KV k="Mutation report" v={basename(d.mutation_file)} mono onClick={() => open(d.mutation_file)} />
              <KV k="Analysis parameter" v={d.analysis_parameter || "—"} />
            </Box>
          )}
          <Box>
            <Button size="small" variant="outlined" startIcon={<OpenInNewRoundedIcon />}
              onClick={() => act(() => api.openOncoPredictor())}>Launch OncoPredictor</Button>
          </Box>
        </Stack>
      );
    }
    case "clustering":
      return (
        <Stack spacing={1.75}>
          {!locked && (
            <>
              <PathField label="1 · Clustering R script (.r)" value={rScript} onChange={setRScript}
                onCommit={commit("r_script_path")} extensions={[".r"]} required />
              <PathField label="2 · GenerateClusteringFile.R (optional)" value={rHelper} onChange={setRHelper}
                onCommit={commit("r_helper_path")} extensions={[".r"]}
                helperText={'Replaces the fixed source("K:/LabOperations/.../GenerateClusteringFile.R") line. Leave empty to use the built-in dummy.'} />
              <PathField label="3 · Assay data file (.tab) (optional)" value={tab} onChange={setTab}
                onCommit={commit("clustering_input_path")} extensions={[".tab", ".txt", ".tsv", ".csv"]}
                helperText="Leave empty to generate a dummy one from the Mutation report imported in step 1." />
              <Typography variant="caption" color="text.secondary">
                R: {settings?.rscript_exe || "not found — install R or skip this step"}
                {settings?.r_auto_install_packages ? " · missing R packages are installed automatically" : ""}
              </Typography>
            </>
          )}
          {d.output_dir && (
            <Box>
              <KV k="Duration" v={fmtDuration(d.r_duration_s)} />
              {d.helper_file && <KV k="Helper used" v={d.dummies?.includes("GenerateClusteringFile.R") ? "Built-in DUMMY" : basename(d.helper_file)} mono />}
              {d.assay_file && <KV k="Assay data used" v={basename(d.assay_file)} mono onClick={() => open(d.assay_file)} />}
              <KV k="Output location" v={d.output_dir} mono onClick={() => open(d.output_dir)} />
              <KV k="Ranked SOC file" v={d.ranked_soc_file ? basename(d.ranked_soc_file) : "—"} mono />
              <KV k="Outputs" v={`${d.outputs?.length || 0} file(s)`} />
            </Box>
          )}
        </Stack>
      );
    case "diffex": {
      const unlocked = DONE.includes(byKey.import?.status) && DONE.includes(byKey.clustering?.status);
      if (!unlocked) {
        return (
          <Stack direction="row" spacing={1} alignItems="center" sx={{ color: "text.secondary" }}>
            <LockRoundedIcon sx={{ fontSize: 18 }} />
            <Typography variant="body2">The Excel template is requested once Steps 1 and 2 have completed successfully.</Typography>
          </Stack>
        );
      }
      return (
        <Stack spacing={1.75}>
          <PathField label="Mutations & Hotspots Excel template" value={excel} onChange={setExcel}
            onCommit={commit("excel_template")} extensions={[".xlsx", ".xlsm"]} required />
          {d.workbook && (
            <Box>
              <KV k="Workbook" v={basename(d.workbook)} mono onClick={() => open(d.workbook)} />
              <KV k="Rows copied" v={`${d.rows?.toLocaleString()} (A:P → Table 3 for DiffEx)`} />
            </Box>
          )}
        </Stack>
      );
    }
    case "genes":
      return d.top60_sensitive ? (
        <Stack direction={{ xs: "column", md: "row" }} spacing={3}>
          <GeneChips title="Sensitivity · AE2:AE61" genes={d.top60_sensitive} color={brand.teal} />
          <GeneChips title="Resistance · AF2:AF61" genes={d.top60_resistant} color={brand.pink} />
        </Stack>
      ) : <Typography variant="body2" color="text.secondary">Top-60 gene lists will appear here.</Typography>;
    case "gprofiler":
      return d.sensitivity ? (
        <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
          {[["Sensitivity", d.sensitivity, brand.teal], ["Resistance", d.resistance, brand.pink]].map(([name, r, c]) => (
            <Box key={name} onClick={() => open(r.csv)} sx={{
              flex: 1, p: 2, borderRadius: 3, cursor: "pointer", border: `1px solid ${alpha(c, 0.3)}`,
              background: `linear-gradient(135deg, ${alpha(c, 0.1)}, transparent)`, transition: ".2s",
              "&:hover": { transform: "translateY(-2px)", boxShadow: `0 10px 30px -12px ${alpha(c, 0.6)}` },
            }}>
              <Typography variant="overline" sx={{ color: c }}>{name}</Typography>
              <Typography sx={{ fontSize: 28, fontWeight: 800, lineHeight: 1.1 }}>{r.terms}</Typography>
              <Typography variant="caption" color="text.secondary">
                enriched terms · {r.engine === "api" ? "API" : "Selenium"}{r.all_results ? " · all results" : ""}
              </Typography>
            </Box>
          ))}
        </Stack>
      ) : (
        <Typography variant="body2" color="text.secondary">
          Homo sapiens · ordered query · CSV export. Sensitivity and resistance queries run in parallel; empty results re-run with "All results".
        </Typography>
      );
    case "report":
      return (
        <Stack spacing={1.75}>
          <PathField label="Word report template (.docx)" value={word} onChange={setWord}
            onCommit={commit("word_template")} extensions={[".docx"]} required />
          <Typography variant="overline" color="text.secondary" sx={{ pt: 0.5 }}>Report details (optional)</Typography>
          <Box sx={{ display: "grid", gap: 1.5, gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" } }}>
            <TextField label="Compound (CLIENTTESTAGENT)" value={compound} onChange={(e) => setCompound(e.target.value)}
              onBlur={(e) => commit("report_compound")(e.target.value)}
              placeholder={byKey.import?.data?.compound_guess || ""}
              helperText={byKey.import?.data?.compound_guess ? `Blank = ${byKey.import.data.compound_guess} (from file name)` : "Blank = left for manual entry"} />
            <TextField label="Analysis parameter" value={param} onChange={(e) => setParam(e.target.value)}
              onBlur={(e) => commit("analysis_parameter")(e.target.value)}
              placeholder={byKey.import?.data?.analysis_parameter || "IC50"}
              helperText={`Blank = ${byKey.import?.data?.analysis_parameter || "IC50"} (from Mutation report)`} />
            <TextField label="Client (CLIENTNAME)" value={client} onChange={(e) => setClient(e.target.value)}
              onBlur={(e) => commit("report_client")(e.target.value)} helperText="Blank = left for manual entry" />
            <TextField label="Order ID (STUDYNUMBER)" value={orderId} onChange={(e) => setOrderId(e.target.value)}
              onBlur={(e) => commit("report_order_id")(e.target.value)} helperText="Blank = left for manual entry" />
          </Box>
          {d.report && (
            <Box>
              <KV k="Report" v={basename(d.report)} mono onClick={() => open(d.report)} />
              <KV k="Populated" v={`${d.placeholders_replaced} placeholders · ${d.table3_rows} Table 3 rows · ${d.summary_sections_filled}/2 summary lists`} />
            </Box>
          )}
        </Stack>
      );
    case "package":
      return d.package ? (
        <KV k="Package" v={basename(d.package)} mono onClick={() => api.reveal(d.package)} />
      ) : <Typography variant="body2" color="text.secondary">Zip of all deliverables with a SHA-256 manifest, saved in Reports\</Typography>;
    default:
      return null;
  }
}

function StepCard({ step, project, settings, steps, last, onChanged }) {
  const theme = useTheme();
  const act = useAction();
  const prevDone = steps.slice(0, step.index - 1).every((s) => DONE.includes(s.status));
  const busy = project.running;
  const c = statusColor[step.status];
  const action = async (a, msg) => { await act(() => api.step(project.id, step.key, a), msg); onChanged(); };
  const [expanded, setExpanded] = useState(null);
  // Only the step that needs attention opens by default; finished steps show their summary line.
  const isOpen = expanded ?? (["running", "failed", "waiting_input", "interrupted"].includes(step.status)
    || (step.status === "pending" && prevDone));

  return (
    <Stack direction="row" spacing={2}>
      <Stack alignItems="center" sx={{ pt: 2.25 }}>
        <StepNode status={step.status} index={step.index} />
        {!last && (
          <Box sx={{
            width: 2, flex: 1, mt: 1, borderRadius: 2, minHeight: 24,
            background: DONE.includes(step.status)
              ? `linear-gradient(${brand.green}, ${alpha(brand.teal, 0.4)})`
              : theme.palette.divider,
          }} />
        )}
      </Stack>
      <Box sx={{
        flex: 1, minWidth: 0, mb: 2, p: 2.25, borderRadius: 4, transition: "all .3s",
        border: `1px solid ${step.status === "running" ? alpha(brand.blue, 0.45) : theme.palette.divider}`,
        bgcolor: step.status === "running" ? alpha(brand.blue, 0.05) : theme.custom.dark ? "rgba(2,6,23,.25)" : "rgba(255,255,255,.45)",
        boxShadow: step.status === "running" ? `0 0 0 4px ${alpha(brand.blue, 0.08)}` : "none",
      }}>
        <Stack direction="row" alignItems="flex-start" spacing={1.5} onClick={() => setExpanded(!isOpen)} sx={{ cursor: "pointer" }}>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Stack direction="row" alignItems="center" spacing={1.25} flexWrap="wrap" useFlexGap>
              <Typography variant="overline" color="text.secondary">Step {step.index}</Typography>
              <StatusChip status={step.status} />
              {step.duration_s != null && DONE.includes(step.status) && (
                <Stack direction="row" spacing={0.5} alignItems="center" sx={{ color: "text.secondary" }}>
                  <TimerOutlinedIcon sx={{ fontSize: 15 }} />
                  <Typography variant="caption">{fmtDuration(step.duration_s)}</Typography>
                </Stack>
              )}
            </Stack>
            <Typography variant="h6" sx={{ fontSize: 17, mt: 0.25 }}>{step.title}</Typography>
            <Typography variant="body2" color="text.secondary">{step.description}</Typography>
          </Box>
          <ExpandMoreRoundedIcon sx={{ color: "text.secondary", transform: isOpen ? "rotate(180deg)" : "none", transition: ".2s", mt: 0.5 }} />
        </Stack>

        {step.status === "running" && (
          <Box sx={{ mt: 2 }}>
            <ShimmerBar value={step.progress} active />
            <Typography variant="caption" sx={{ display: "block", mt: 0.75, color: brand.blue, fontWeight: 600 }}>{step.message}</Typography>
          </Box>
        )}
        {step.status === "failed" && (
          <Alert severity="error" variant="outlined" sx={{ mt: 2, borderRadius: 3, "& .MuiAlert-message": { minWidth: 0 } }}>
            <Typography variant="body2" sx={{ fontWeight: 650 }}>{step.message}</Typography>
            {step.error && step.error !== step.message && (
              <Typography component="pre" variant="caption" sx={{ m: 0, mt: 0.5, whiteSpace: "pre-wrap", wordBreak: "break-word", opacity: 0.85 }}>
                {step.error}
              </Typography>
            )}
          </Alert>
        )}
        {(step.status === "waiting_input" || step.status === "interrupted") && (
          <Alert severity="warning" variant="outlined" sx={{ mt: 2, borderRadius: 3 }}>{step.message}</Alert>
        )}
        {DONE.includes(step.status) && step.message && (
          <Typography variant="body2" sx={{ mt: 1.25, color: c, fontWeight: 600 }}>{step.message}</Typography>
        )}

        <Collapse in={isOpen} unmountOnExit>
          <Divider sx={{ my: 2 }} />
          <StepBody step={step} project={project} settings={settings} steps={steps} onChanged={onChanged} />
          <Stack direction="row" spacing={1} sx={{ mt: 2 }} flexWrap="wrap" useFlexGap>
            {!DONE.includes(step.status) && step.status !== "running" && (
              <Tooltip title={prevDone ? "" : "Complete the previous steps first"}>
                <span>
                  <Button size="small" variant="contained" disabled={!prevDone || busy}
                    startIcon={step.status === "failed" || step.status === "interrupted" ? <ReplayRoundedIcon /> : <PlayArrowRoundedIcon />}
                    onClick={() => action("run")}>
                    {step.status === "failed" ? "Retry" : step.status === "interrupted" ? "Resume" : step.key === "import" ? "Import files" : step.key === "clustering" ? "Run R script" : "Run step"}
                  </Button>
                </span>
              </Tooltip>
            )}
            {step.skippable && !DONE.includes(step.status) && step.status !== "running" && (
              <Button size="small" color="inherit" startIcon={<SkipNextRoundedIcon />} disabled={!prevDone || busy}
                onClick={() => action("skip", "Step skipped")}>Skip</Button>
            )}
            {DONE.includes(step.status) && (
              <Button size="small" color="inherit" startIcon={<RestartAltRoundedIcon />} disabled={busy}
                onClick={() => action("reset", "Step re-opened")}>Re-run from here</Button>
            )}
          </Stack>
        </Collapse>
      </Box>
    </Stack>
  );
}

export default function Workflow({ project, settings, onChanged }) {
  return (
    <GlassCard>
      <SectionTitle icon={AccountTreeRoundedIcon} title="Workflow"
        subtitle="One-click pipeline · resumable at any step"
        action={<Chip size="small" label={`${project.metrics.completed_steps}/${project.metrics.total_steps}`} />} />
      <Box>
        {project.steps.map((s, i) => (
          <StepCard key={s.key} step={s} project={project} settings={settings} steps={project.steps}
            last={i === project.steps.length - 1} onChanged={onChanged} />
        ))}
      </Box>
    </GlassCard>
  );
}
